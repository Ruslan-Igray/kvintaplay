const HOSTS=new Set(['amdm.ru','www.amdm.ru','897.amdm.ru','1368.amdm.ru','mytabs.ru','www.mytabs.ru']);
export class SongError extends Error{constructor(message,status=422){super(message);this.status=status;}}
export function sourceUrl(value,songOnly=true){
 let u;try{u=new URL(value);}catch{throw new SongError('Вставьте полную ссылку на песню с AmDm или MyTabs.');}
 if(u.protocol!=='https:'||u.username||u.password||u.port||!HOSTS.has(u.hostname))throw new SongError('Поддерживаются только ссылки https на AmDm и MyTabs.');
 if(songOnly&&!(u.hostname.endsWith('amdm.ru')?/^\/akkordi\/[^/]+\/\d+\/[^/]+\/?$/.test(u.pathname):/^\/akkordy\/.+_\d+\.html$/.test(u.pathname)))throw new SongError('Нужна ссылка на саму песню, а не на исполнителя или главную страницу.');
 u.hash='';if(songOnly)u.search='';return u;
}
export function decode(text){
 const names={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' ',ndash:'–',mdash:'—',laquo:'«',raquo:'»',hellip:'…',shy:''};
 return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi,(all,k)=>{if(k[0]!=='#')return names[k]??all;const n=k[1].toLowerCase()==='x'?parseInt(k.slice(2),16):Number(k.slice(1));return n>0&&n<=0x10ffff&&!(n>=0xd800&&n<=0xdfff)?String.fromCodePoint(n):'';});
}
function plain(html){return decode(html.replace(/<!--[\s\S]*?-->/g,'').replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/<br\s*\/?\s*>/gi,'\n').replace(/<[^>]*>/g,''));}
export function elementContent(html,tag,attr){
 const token=new RegExp('<\\/?'+tag+'\\b[^>]*>','gi');let m,start=-1,depth=0;
 while((m=token.exec(html))){if(start<0){if(!m[0].startsWith('</')&&attr.test(m[0])){start=token.lastIndex;depth=1;}}else{depth+=m[0].startsWith('</')?-1:1;if(!depth)return html.slice(start,m.index);}}
 return null;
}
const CHORD=/^[A-H](?:#{1,2}|b{1,2}|♯|♭)?(?:(?:maj|min|dim|aug|sus|add|omit|no|m|M|Δ|°|ø|\+|-)?\d*(?:sus[24]|add\d+|(?:b|#)\d+|\([^)]{1,16}\))*)?(?:\/[A-H](?:#|b|♯|♭)?)?$/;
export function isChord(text){return text.length<=32&&CHORD.test(text);}
function chordRow(text){const words=[...text.matchAll(/\S+/g)],cs=words.filter(m=>isChord(m[0])),rest=words.filter(m=>!isChord(m[0])&&!/^[|:/\\\-–—×x0-9.,]+$/.test(m[0]));return cs.length&&!rest.length?cs.map(m=>({symbol:m[0],column:m.index})):null;}
export function parseText(value){
 if(typeof value!=='string'||value.length>100000)throw new SongError('Текст слишком большой. Максимум — 100 000 знаков.');
 const parts=[];let part={name:'Песня',lines:[]},pending=null;
 const add=(text,chords)=>part.lines.push({text:text.trimEnd(),chords:chords||[]});
 const flush=()=>{if(part.lines.length)parts.push(part);};
 for(const raw of value.replace(/\r\n?/g,'\n').replace(/\t/g,'    ').split('\n')){
  const row=raw.trim();if(!row){if(pending){add('',pending);pending=null;}continue;}
  const h=row.match(/^\[?((?:куплет|припев|проигрыш|вступление|кода|бридж|verse|chorus|bridge|intro|outro|interlude)(?:\s*\d+)?)[\]:.!]?$/i);
  if(h){if(pending){add('',pending);pending=null;}flush();part={name:h[1],lines:[]};continue;}
  if(/^[eBGDAE1-6]?\s*\|[-\d|hHpPbBrR/\\~x.\s]+$/.test(row)){if(pending){add('',pending);pending=null;}add(raw,[]);part.lines.at(-1).kind='tab';continue;}
  const cs=chordRow(raw);if(cs){if(pending)add('',pending);pending=cs;continue;}
  const inline=[...raw.matchAll(/\[([^\]\n]+)\]/g)].filter(m=>isChord(m[1]));
  if(inline.length){if(pending){add('',pending);pending=null;}let text='',at=0;const chords=[];for(const m of inline){text+=raw.slice(at,m.index);chords.push({symbol:m[1],column:text.length});at=m.index+m[0].length;}text+=raw.slice(at);add(text,chords);}
  else{add(raw,pending);pending=null;}
 }
 if(pending)add('',pending);flush();const count=parts.reduce((n,p)=>n+p.lines.length,0);
 if(!count||count>400)throw new SongError(count?'В песне больше 400 строк. Разделите её на части.':'Не удалось найти текст песни.');return parts;
}
export function parseSong(html,value){
 const url=sourceUrl(value),amdm=url.hostname.endsWith('amdm.ru');
 const block=amdm?elementContent(html,'pre',/(?:itemprop=["']chordsBlock["']|class=["'][^"']*podbor__text)/i):elementContent(html,'div',/\bid=["']song["']/i);
 if(!block)throw new SongError('На странице не найден текст с аккордами. Можно вставить текст вручную.');
 const h=html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1]||html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'Песня';
 const name=plain(h).replace(/\s+/g,' ').replace(/,?\s*аккорды.*$/i,'').trim(),sep=name.indexOf(' - '),text=plain(block).trim();
 return {schema:1,title:(sep>=0?name.slice(sep+3):name).trim().slice(0,180),artist:(sep>=0?name.slice(0,sep):'').trim().slice(0,180),source:{name:amdm?'AmDm':'MyTabs',url:url.href},parts:parseText(text),rawText:text,timing:'manual',bpm:null,meter:null};
}
export function parseSearch(html,base){
 const results=[],seen=new Set();for(const row of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){
  let artist='';for(const a of row[1].matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)){
   let u;try{u=new URL(decode(a[1]),base);}catch{continue;}const name=plain(a[2]).replace(/\s+/g,' ').trim();if(/^\/akkordi\/[^/]+\/$/.test(u.pathname))artist=name;
   try{u=sourceUrl(u.href);if(seen.has(u.pathname)||!name)continue;seen.add(u.pathname);results.push({title:name.slice(0,180),artist:artist.slice(0,180),url:u.href,source:'AmDm'});}catch{}
   if(results.length===30)return results;
  }
 }return results;
}
async function remote(url,fetcher){
 let next=sourceUrl(url.href||url,false);for(let hop=0;hop<3;hop++){
  let r;try{r=await fetcher(next.href,{redirect:'manual',signal:AbortSignal.timeout(13000),headers:{Accept:'text/html','User-Agent':'Kvinta-Songs/0.1 (+personal rehearsal reader)'}});}catch{throw new SongError('Источник не ответил. Попробуйте ещё раз или вставьте текст песни.',502);}
  if([301,302,303,307,308].includes(r.status)){const l=r.headers.get('location');if(!l)break;next=sourceUrl(new URL(l,next).href,false);continue;}
  if(!r.ok)throw new SongError('Источник временно не разрешил загрузку ('+r.status+'). Откройте его на сайте или вставьте текст.',502);
  if(!/text\/html|application\/xhtml/.test(r.headers.get('content-type')||''))throw new SongError('Источник вернул неподдерживаемый формат.');
  if(Number(r.headers.get('content-length'))>1800000)throw new SongError('Страница слишком большая.');
  const reader=r.body.getReader(),chunks=[];let size=0;while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>1800000){await reader.cancel();throw new SongError('Страница слишком большая.');}chunks.push(value);}
  const data=new Uint8Array(size);let offset=0;for(const c of chunks){data.set(c,offset);offset+=c.length;}return {html:new TextDecoder().decode(data),url:next};
 }throw new SongError('Сайт перенаправляет запрос. Попробуйте прямую ссылку на песню.',502);
}
const searchWords=value=>plain(String(value)).toLocaleLowerCase('ru').replaceAll('ё','е').match(/[\p{L}\p{N}]+/gu)||[];
const searchText=value=>searchWords(value).join(' ');
export function rankSearchResults(rows,query){
 const words=searchWords(query),phrase=words.join(' '),seen=new Set();
 const scored=rows.filter(row=>{const key=row.url;if(seen.has(key))return false;seen.add(key);return true;}).map((row,index)=>{
  const title=searchWords(row.title),artist=searchWords(row.artist),all=[...title,...artist];
  const exact=words.filter(w=>all.includes(w)).length,partial=words.filter(w=>all.some(s=>s.startsWith(w))).length;
  return {row,index,exact,partial,score:exact*30+partial*5+(exact===words.length?120:0)+(searchText(row.title)===phrase?50:0)+(row.kind==='artist'&&words.every(w=>title.includes(w))?100:0)};
 });
 const exact=scored.some(r=>r.exact===words.length),matching=scored.filter(r=>exact?r.exact===words.length:r.partial===words.length);
 return matching.sort((a,b)=>b.score-a.score||a.index-b.index).slice(0,60).map(x=>x.row);
}
export function artistUrl(value){const u=sourceUrl(value,false);if(!(u.hostname.endsWith('amdm.ru')?/^\/akkordi\/[^/]+\/?$/.test(u.pathname):/^\/akkordy\/[^/]+\/[^/]+\/?$/.test(u.pathname)))throw new SongError('Нужна ссылка на страницу исполнителя.');u.search='';return u;}
export function parseArtistLinks(html,base){
 const out=[],seen=new Set();for(const m of html.matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)){
  let u;try{u=artistUrl(new URL(decode(m[1]),base).href);}catch{continue;}const title=plain(m[2]).replace(/\s+/g,' ').trim();if(!title||seen.has(u.href))continue;seen.add(u.href);out.push({title:title.slice(0,180),artist:'',url:u.href,source:u.hostname.includes('mytabs')?'MyTabs':'AmDm',kind:'artist'});
 }return out.slice(0,20);
}
export function parseArtistSongs(html,base,artist=''){
 const rows=[],seen=new Set(),prefix=new URL(base).pathname.replace(/\/$/,'')+'/';for(const m of html.matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)){
  let u;try{u=sourceUrl(new URL(decode(m[1]),base).href);}catch{continue;}const title=plain(elementContent(m[2],'div',/class=["'][^"']*song-row__title/i)||m[2]).replace(/\s+/g,' ').trim();if(!title||!u.pathname.startsWith(prefix)||seen.has(u.href))continue;seen.add(u.href);rows.push({title:title.slice(0,180),artist:artist.slice(0,180),url:u.href,source:u.hostname.includes('mytabs')?'MyTabs':'AmDm'});
 }return rows.slice(0,100);
}
function providerCookieLines(headers){return headers.getSetCookie?.()||headers.getAll?.('Set-Cookie')||String(headers.get('set-cookie')||'').split(/,(?=\s*[^;,\s]+=)/);}
const mytabsSessions=new WeakMap();
async function mytabsSession(fetcher){
 let cached=mytabsSessions.get(fetcher);if(cached&&cached.expires>Date.now())return cached.pending;
 const pending=(async()=>{let response;try{response=await fetcher('https://mytabs.ru/',{signal:AbortSignal.timeout(8000),redirect:'manual',headers:{Accept:'text/html'}});}catch{throw new SongError('MyTabs не ответил.',502);}
  if(!response.ok)throw new SongError('MyTabs временно недоступен ('+response.status+').',502);
  const cookies=providerCookieLines(response.headers).map(c=>c.trim().split(';')[0]).filter(c=>/^(?:XSRF-TOKEN|mytabsru_session)=/.test(c));
  const token=cookies.find(c=>c.startsWith('XSRF-TOKEN='))?.slice(11);await response.body?.cancel();if(!token)throw new SongError('MyTabs временно не разрешил поиск.',502);
  return {cookie:cookies.join('; '),token:decodeURIComponent(token)};
 })();mytabsSessions.set(fetcher,{expires:Date.now()+10*60000,pending});try{return await pending;}catch(e){mytabsSessions.delete(fetcher);throw e;}
}
export function parseMyTabsSearch(data){
 if(!Array.isArray(data?.data))throw new SongError('MyTabs вернул неизвестный формат поиска.',502);
 return data.data.slice(0,60).flatMap(row=>{if(typeof row?.title!=='string'||typeof row.url!=='string')return [];let url;try{url=row.type==='artist'?artistUrl(row.url):sourceUrl(row.url);}catch{return [];}if(!url.hostname.endsWith('mytabs.ru'))return [];
  const full=plain(row.title).replace(/\s+/g,' ').trim(),sep=full.indexOf(' - ');return [{title:(row.type==='artist'||sep<0?full:full.slice(sep+3)).slice(0,180),artist:row.type==='artist'||sep<0?'':full.slice(0,sep).slice(0,180),url:url.href,source:'MyTabs',...(row.type==='artist'?{kind:'artist'}:{})}];
 });
}
async function searchMyTabs(query,fetcher){
 for(let attempt=0;attempt<2;attempt++){
  const session=await mytabsSession(fetcher);let r;try{r=await fetcher('https://mytabs.ru/search',{method:'POST',redirect:'manual',signal:AbortSignal.timeout(8000),headers:{Accept:'application/json','Content-Type':'application/json',Cookie:session.cookie,'X-XSRF-TOKEN':session.token},body:JSON.stringify({query})});}catch{throw new SongError('MyTabs не ответил.',502);}
  if(r.status===419&&attempt===0){await r.body?.cancel();mytabsSessions.delete(fetcher);continue;}
  if(!r.ok)throw new SongError('MyTabs временно не разрешил поиск ('+r.status+').',502);
  if(Number(r.headers.get('content-length'))>200000)throw new SongError('Слишком большой ответ MyTabs.',502);
  const text=await r.text();if(text.length>200000)throw new SongError('Слишком большой ответ MyTabs.',502);let data;try{data=JSON.parse(text);}catch{throw new SongError('MyTabs вернул неизвестный формат поиска.',502);}return parseMyTabsSearch(data);
 }return [];
}
export async function searchSources(query,fetcher=fetch){
 const providers=[['AmDm',async()=>{const e=new URL('https://897.amdm.ru/search/');e.searchParams.set('q',query);const {html,url}=await remote(e,fetcher);return [...parseSearch(html,url.href),...parseArtistLinks(html,url.href)];}],['MyTabs',()=>searchMyTabs(query,fetcher)]];
 const settled=await Promise.allSettled(providers.map(([,search])=>search())),sources=settled.map((result,i)=>({name:providers[i][0],status:result.status==='fulfilled'?'ok':'unavailable',...(result.status==='rejected'?{error:result.reason instanceof SongError?result.reason.message:'Источник не ответил.'}:{})}));
 const results=rankSearchResults(settled.flatMap(r=>r.status==='fulfilled'?r.value:[]),query);
 if(sources.every(s=>s.status!=='ok'))throw new SongError('Оба сайта сейчас не ответили. Повторите поиск немного позже или вставьте текст песни.',502);
 return {results,sources};
}
export async function songsRequest(request,fetcher=fetch){
 const u=new URL(request.url);if(!u.pathname.startsWith('/api/songs/'))return null;
 const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 if(request.method!=='GET')return json({error:'Method not allowed'},405);
 try{
  if(u.pathname==='/api/songs/search'){const q=(u.searchParams.get('q')||'').trim();if(q.length<2||q.length>100)throw new SongError('Введите от 2 до 100 знаков: название песни или исполнителя.');return json(await searchSources(q,fetcher));}
  if(u.pathname==='/api/songs/artist'){const selected=artistUrl(u.searchParams.get('url')||''),{html,url}=await remote(selected,fetcher);artistUrl(url.href);const title=plain(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1]||'').replace(/\s*[-—,:]?\s*аккорды.*$/i,'').trim();return json({results:parseArtistSongs(html,url.href,title),sources:[{name:url.hostname.includes('mytabs')?'MyTabs':'AmDm',status:'ok'}]});}
  if(u.pathname==='/api/songs/import'){const selected=sourceUrl(u.searchParams.get('url')||''),{html,url}=await remote(selected,fetcher);sourceUrl(url.href);return json({song:parseSong(html,url.href)});}
  return json({error:'Not found'},404);
 }catch(e){return json({error:e instanceof SongError?e.message:'Не удалось обработать подбор. Вставьте его текст вручную.'},e instanceof SongError?e.status:500);}
}
