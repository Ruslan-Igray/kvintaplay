const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));

// Keep a complete lyric/chord row in a reading band below the header. The band
// adapts to a small screen and to wrapped rows instead of assuming a 12px gap.
export function readingInsets(viewportHeight,fontSize=22){
 const height=Math.max(1,Number(viewportHeight)||1),font=Math.max(10,Number(fontSize)||22);
 const safety=Math.min(18,Math.max(8,height*.05));
 return {top:Math.min(112,Math.max(font*2.4,height*.22),height*.34),bottom:Math.min(42,Math.max(font*.9,height*.08)),safety};
}
export function lyricCursor(position,lines){
 if(!lines.length)return {index:0,phase:0};
 let index=0;for(let i=0;i<lines.length;i++)if(position>=lines[i].top)index=i;
 const start=lines[index].top,end=lines[index+1]?.top??start+lines[index].height;
 return {index,phase:clamp((position-start)/Math.max(1,end-start),0,1)};
}
export function lyricPosition({index,phase},lines){
 const line=lines[index];if(!line)return 0;
 return line.top+clamp(phase,0,1)*Math.max(1,(lines[index+1]?.top??line.top+line.height)-line.top);
}
export function followReadingScroll(position,target,seconds){
 return position+(target-position)*(-Math.expm1(-Math.max(0,Math.min(.1,seconds))*7));
}
export function readingScrollTarget({lines,index,phase=0,viewportHeight,fontSize=22,maxScroll=Infinity}){
 const line=lines[index];if(!line)return 0;
 const height=Math.max(1,viewportHeight),inset=readingInsets(height,fontSize),available=Math.max(1,height-inset.safety-inset.bottom);
 let target;
 if(line.height>available){
  // A long wrapped row is read through gradually, while some of that same row
  // remains visible. Its start must not be forced above the screen immediately.
  target=line.top-inset.safety+clamp(phase,0,1)*(line.height-available);
 }else{
  const anchor=Math.min(inset.top,Math.max(inset.safety,height-inset.bottom-line.height));
  const previous=lines[index-1],floor=previous?previous.top-inset.safety+Math.max(0,previous.height-available):-Infinity;
  const begin=Math.max(floor,clamp(line.top-anchor,line.top+line.height-height+inset.bottom,line.top-inset.safety));
  target=begin+(line.top-inset.safety-begin)*clamp(phase,0,1);
 }
 return clamp(target,0,Math.max(0,maxScroll));
}

// Keep subpixel state separate from scrollTop: some engines quantize its getter.
export function createReadingFollower(position=0){
 let precise=position;
 return {reset(value=0){precise=value;},step(target,seconds,max=Infinity){precise=followReadingScroll(precise,target,seconds);precise=clamp(precise,0,max);return precise;},get position(){return precise;}};
}
