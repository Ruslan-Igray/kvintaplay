// Set only after a replacement HTTPS search service has been deployed and verified.
// Sharing and statistics continue to use the original service.
export const SEARCH_SERVICE_ORIGIN='';
