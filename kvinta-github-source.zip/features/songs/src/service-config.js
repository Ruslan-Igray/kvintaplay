// Public endpoint for the AmDm and MyTabs lookup service.
export const SEARCH_SERVICE_ORIGIN='https://888410.cloud4box.ru';
