// Keep a normal click intact; a completed hold consumes its release click.
export function bindLongPress(element,onHold,{delay=600}={}){
 const win=element.ownerDocument.defaultView;let pointer=null,timer=null,skipUntil=0;
 function cancel(){win.clearTimeout(timer);timer=null;if(pointer?.fired||pointer?.cancelled)skipUntil=win.performance.now()+600;pointer=null;}
 function release(event){if(pointer?.id===event.pointerId)cancel();}
 function down(event){if(event.button!==0||event.isPrimary===false)return;cancel();skipUntil=0;pointer={id:event.pointerId,x:event.clientX,y:event.clientY,fired:false,cancelled:false};timer=win.setTimeout(()=>{if(!pointer||pointer.cancelled)return;pointer.fired=true;skipUntil=Infinity;timer=null;onHold();},delay);}
 function move(event){if(pointer?.id===event.pointerId&&Math.hypot(event.clientX-pointer.x,event.clientY-pointer.y)>9){win.clearTimeout(timer);timer=null;pointer.cancelled=true;}}
 function click(event){if(pointer?.fired||win.performance.now()<skipUntil){event.preventDefault();event.stopImmediatePropagation();}}
 function context(event){event.preventDefault();}
 function key(event){if(event.key==='ContextMenu'||event.key==='F10'&&event.shiftKey){event.preventDefault();cancel();onHold();}}
 element.addEventListener('pointerdown',down,true);element.addEventListener('pointermove',move,true);element.addEventListener('click',click,true);element.addEventListener('contextmenu',context);element.addEventListener('keydown',key);
 win.addEventListener('pointerup',release,true);win.addEventListener('pointercancel',release,true);win.addEventListener('blur',cancel);win.addEventListener('pagehide',cancel);
 return {destroy(){cancel();element.removeEventListener('pointerdown',down,true);element.removeEventListener('pointermove',move,true);element.removeEventListener('click',click,true);element.removeEventListener('contextmenu',context);element.removeEventListener('keydown',key);win.removeEventListener('pointerup',release,true);win.removeEventListener('pointercancel',release,true);win.removeEventListener('blur',cancel);win.removeEventListener('pagehide',cancel);}};
}
