export const SAVED_SONGS_KEY='kvinta-song-saved',CURRENT_SONG_KEY='kvinta-song-current',DRAFT_PREFIX='kvinta-song-draft.v1:';
const copy=value=>JSON.parse(JSON.stringify(value));
export function songContent(song){return JSON.stringify([song.title,song.artist,song.baseChord,song.parts,song.recording||null,...['bpm','meter','key'].map(key=>song.rehearsal?.[key]??null)]);}
export function createSongStore(storage){
 try{storage??=globalThis.localStorage;}catch{}
 const key=id=>DRAFT_PREFIX+encodeURIComponent(id);
 const write=(name,value)=>storage.setItem(name,JSON.stringify(value));
 function saved(){const rows=JSON.parse(storage.getItem(SAVED_SONGS_KEY)||'[]');if(!Array.isArray(rows))throw Error('invalid-song-library');return rows;}
 function draft(id){try{const value=JSON.parse(storage.getItem(key(id))||'null');return value?.schema===1&&value.dirty===true&&value.song?.id===id?copy(value):null;}catch{return null;}}
 function drafts(){const out=[];try{for(let i=0;i<storage.length;i++){const name=storage.key(i);if(!name?.startsWith(DRAFT_PREFIX))continue;try{const value=draft(decodeURIComponent(name.slice(DRAFT_PREFIX.length)));if(value)out.push(value);}catch{}}}catch{}return out;}
 function remember(song,{dirty=false}={}){try{if(dirty)write(key(song.id),{schema:1,dirty:true,song,at:Date.now()});write(CURRENT_SONG_KEY,song);return true;}catch{return false;}}
 function forgetDraft(id){try{storage.removeItem(key(id));return true;}catch{return false;}}
 function save(song){try{
  // Read before writing: a malformed library is never replaced by an empty one.
  const rows=saved().filter(row=>row?.id!==song.id);
  if(!remember(song,{dirty:true}))return false;
  write(SAVED_SONGS_KEY,[song,...rows]);forgetDraft(song.id);return true;
 }catch{return false;}}
 function activate(song){try{const next=draft(song.id)?.song||song;write(CURRENT_SONG_KEY,next);return copy(next);}catch{return null;}}
 return {saved,draft,drafts,remember,save,activate,forgetDraft,writeSaved(rows){try{write(SAVED_SONGS_KEY,rows);return true;}catch{return false;}},restoreDraft(value){try{write(key(value.song.id),value);return true;}catch{return false;}}};
}
