import '../modules/backup-recovery.js';
import {componentLicenseHelp} from '../modules/component-licenses.js';
import {editSafety} from '../modules/edit-safety.js';
import {createSongStore,songContent} from './song-store.js';
import {organizeRehearsalMenu} from './rehearsal-menu.js';
import './integration.js';
import {fetchSongApi,isKvintaSongUrl} from './api.js';
import {createCountIn} from './count-in.js';
window.kvintaCreateCountIn=createCountIn;
import {recentSearches} from './editor-controls.js';
import {parseText} from './song-model.js';
import {normalizeSong,normalizeRehearsal,linesOf,lineBeats,CUE_PRESETS,snapshot,SONG_METERS,songMeter} from './score-model.js';
import {mountEditor} from './editor.js';
import {SETTINGS_KEY,sharedSongSettings,mergeSongSettings,quickActions} from './song-settings.js';
import {mountQuickActions} from './quick-actions.js';
import {mountSongWorkspace} from './workspace.js';
import {mountSearchHistory} from './search-history.js';
import {mountPinchZoom} from './pinch-zoom.js';
window.kvintaMountPinch=mountPinchZoom;
import {mountSongTorch} from './torch-control.js';
import {audibleAudioTime} from '../modules/audio-clock.js';
import {createSongSync} from './song-sync.js';
import {flashOnBeat} from '../modules/metronome-engine.js';
import {createVisualRhythm,showVisualRhythmSettings} from '../modules/visual-rhythm.js';
import {appSound,savePreferences} from '../modules/preferences.js';
window.kvintaVisualRhythm={create:host=>createVisualRhythm({host})};
import {mountRecording} from './recording.js';
import {createClickFeedback} from '../modules/feedback.js';
import {makeSoundBuffer} from '../modules/ui-sounds.js';
import {playbackContext,preparePlayback} from '../modules/playback-audio.js';
import {setupSwipeDelete,SONG_SWIPE_OPTIONS} from '../modules/swipe-delete.js';
import * as readingGeometry from './reading-geometry.js';
window.kvintaSongScroll=readingGeometry;
import {readSharedSong,showSongShare} from './sharing.js';
const get=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}};
const put=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}};
const songStore=createSongStore();let editor=null,draftDirty=false,readyToNotify=false,pendingStorageError=false;
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const timingClicks=createClickFeedback({getSound:()=>appSound()});
window.kvintaCreateSongSync=options=>createSongSync({...options,getSettings:()=>({...options.getSettings(),sound:appSound()})});
window.kvintaSongTiming={flashOnBeat,audioOutputTime:audibleAudioTime,audioContext:playbackContext,unlockAudio:preparePlayback,meters:SONG_METERS,meter:songMeter,click:()=>timingClicks.play(),soundBuffer:(context,accent)=>makeSoundBuffer(context,appSound(),accent?'accent':'beat')};
const example={schema:1,id:'teaching',title:'Тихий вечер',artist:'Учебный пример',source:null,parts:parseText('[Куплет 1]\nAm           F\nТихий вечер гасит окна,\nC             G\nГород медленно молчит.\nAm             Fmaj7\nЯ возьму гитару с полки —\nDm             E7\nПусть знакомый строй звучит.\n[Припев]\nF           G\nМы сыграем эту песню,\nC           Am\nНе торопимся никуда.\nDm             E7\nПусть сегодня будет слышно:\nAm                  Am\nМузыка с тобою навсегда.')};
function migrate(raw){const legacyId=raw.id||raw.source?.url||'teaching',prefs=get('kvinta-song-prefs:'+legacyId,{}),old=prefs.privateContent?.screens?.bottom||prefs.modelContent?.screens?.bottom||{};return normalizeSong({...raw,rehearsal:raw.schema===2?raw.rehearsal:{...old,...raw.rehearsal}});}
function savedSongs(){let values;try{values=songStore.saved();}catch{return [];}return values.flatMap(raw=>{try{return [migrate(raw)];}catch{return [];}});}
let song,wasExample=false;try{song=migrate(get('kvinta-song-current',example));}catch{song=migrate(example);wasExample=true;}
const initialDraft=songStore.draft(song.id);if(initialDraft){try{song=migrate(initialDraft.song);draftDirty=true;}catch{}}
if(!draftDirty&&song.id!=='teaching'){const saved=savedSongs().find(item=>item.id===song.id);draftDirty=!saved||songContent(saved)!==songContent(song);}
if(song.id==='teaching'&&!draftDirty)wasExample=true;
let shared=false,sharedError='';const shareId=new URLSearchParams(location.hash.slice(1)).get('song');
window.addEventListener('hashchange',()=>{if(new URLSearchParams(location.hash.slice(1)).get('song')!==shareId)location.reload();});
if(shareId){try{song=await readSharedSong(shareId);song.id=crypto.randomUUID();shared=true;draftDirty=false;}catch(e){sharedError=e.message;}}
else persistSong();
function persistSong(){if(shared&&!draftDirty)return true;const ok=songStore.remember(song,{dirty:draftDirty});editSafety.set('song-draft',!ok);if(!ok){if(readyToNotify)notify('Не удалось сохранить черновик. Правки пока только в памяти; обновление отложено.');else pendingStorageError=true;}return ok;}
const savedKey=()=> 'kvinta-song-prefs:'+song.id;
const noteNames=['A','B♭','B','C','C♯','D','E♭','E','F','F♯','G','G♯'],semitone={C:0,D:2,E:4,F:5,G:7,A:9,B:11,H:11};
const pitch=note=>{const m=note.match(/^([A-H])([#b♭♯]*)/);if(!m)return null;return ((semitone[m[1]]+[...m[2]].reduce((n,c)=>n+('#♯'.includes(c)?1:-1),0))%12+12)%12;};
const initialKey=Math.max(0,noteNames.findIndex(n=>pitch(n)===pitch(song.baseChord))),minor=/^[A-H][#b♯♭]*m(?!aj)/.test(song.baseChord),flat=/[b♭]/.test(song.baseChord);
function shift(symbol,delta){
 delta=((delta%12)+12)%12;if(!delta||!symbol)return symbol;
 const names=flat?['C','D♭','D','E♭','E','F','G♭','G','A♭','A','B♭','B']:['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
 return symbol.replace(/(^|\/)([A-H][#b♭♯]*)/g,(_,prefix,note)=>prefix+names[(pitch(note)+delta)%12]);
}
function transpose(symbol,key){return shift(symbol,key-initialKey);}
let scoreLines=linesOf(song);
function previewParts(){return song.parts.map(p=>({name:p.name,lines:p.lines.map(l=>l.chords.length?l.chords.map(c=>[c.symbol,l.text]):[['',l.text]])}));}
window.kvintaSongPreview={title:song.title,subtitle:(song.artist||song.source?.name||'Своя песня'),initialKey,keyNames:noteNames.map(n=>n+(minor?'m':'')),parts:previewParts(),transpose,lineBeats:index=>lineBeats(scoreLines[index]),chordBeats:index=>scoreLines[index].chords.map(c=>c.beats)};
window.kvintaSongPreview.renderLine=(line,index)=>{
 const entry=scoreLines[index];line.dataset.lineId=entry.id;
 const chords=entry.chords,end=Math.max(entry.text.length,...chords.map(c=>c.column+1),...entry.cues.map(c=>(c.column||0)+1)),text=entry.text.padEnd(end||1,' '),rowHeight=window.kvintaEditing?48:31;
 let words=[...text.matchAll(/\S+\s*|\s+/g)];
 if(!entry.text.trim()&&(chords.length||entry.cues.length)){const positions=[...new Set([...chords.map(c=>c.column),...entry.cues.map(c=>c.column||0)])].sort((a,b)=>a-b);words=positions.map((col,i)=>({0:text.slice(col,positions[i+1]??text.length)||' ',index:col}));}
 const cuesAt=(word,i)=>entry.cues.filter(c=>(c.column||0)>=word.index&&(c.column||0)<(words[i+1]?.index??Infinity));
 const cueHeight=Math.max(0,...words.map((w,i)=>cuesAt(w,i).length))*40;
 for(let i=0;i<words.length;i++){
  const word=words[i],next=words[i+1]?.index??Infinity,span=document.createElement('span');span.className='qs-fragment';span.style.paddingTop=(rowHeight+cueHeight)+'px';
  const label=document.createElement('span');label.className='qs-words';label.dataset.start=word.index;label.textContent=word[0];span.append(label);
  const cues=cuesAt(word,i);let cueWidth=0;
  cues.forEach((cue,j)=>{const mark=document.createElement(window.kvintaEditing?'button':'span');if(window.kvintaEditing)mark.type='button';mark.dataset.cueId=cue.id;mark.dataset.color=cue.color;mark.style.top=(j*40)+'px';mark.style.left=Math.max(0,(cue.column||0)-word.index)+'ch';
   if(cue.type==='line'){mark.className='ke-divider ke-anchored';mark.setAttribute('aria-label','Цветная линия');cueWidth=Math.max(cueWidth,8);}
   else{mark.className='ke-cue ke-anchored';const preset=CUE_PRESETS.find(p=>p.id===cue.preset),icon=document.createElement('i'),label=document.createElement('span');icon.dataset.lucide=preset.icon;icon.setAttribute('aria-hidden','true');label.textContent=cue.label||preset.label;mark.append(icon,label);cueWidth=Math.max(cueWidth,Math.min(15,(cue.label||preset.label).length*.67+3));}span.append(mark);
  });
  let chordEnd=0,glyphEnd=cueWidth+Math.max(0,...cues.map(c=>(c.column||0)-word.index));
  for(const chord of chords.filter(c=>c.column>=word.index&&c.column<next)){
   const left=Math.max(chord.column-word.index,chordEnd),mark=document.createElement(window.kvintaEditing?'button':'span');if(window.kvintaEditing)mark.type='button';mark.className='qs-chord';mark.dataset.chord=chord.symbol;mark.dataset.chordId=chord.id;if(chord.color)mark.dataset.color=chord.color;mark.style.left=left+'ch';mark.style.top=cueHeight+'px';mark.setAttribute('aria-label','Аккорд '+chord.symbol+', '+chord.beats+' доли');span.append(mark);chordEnd=left+Math.max(3,chord.symbol.length+1)+1;glyphEnd=Math.max(glyphEnd,left+chord.symbol.length+.3);
  }
  if(glyphEnd>word[0].length)span.style.minWidth='min(100%, '+glyphEnd+'ch)';line.append(span);
 }
 line.setAttribute('aria-label','Строка '+(index+1)+': '+entry.text);
};
const globalPrefs=get('kvinta.preferences.v1',{}),theme=['light','dark'].includes(globalPrefs.theme)?globalPrefs.theme:'auto';
function setTheme(value){savePreferences({theme:value==='auto'?null:value});const resolved=value==='auto'?(matchMedia('(prefers-color-scheme:light)').matches?'light':'dark'):value;document.documentElement.dataset.theme=resolved;document.documentElement.style.colorScheme=resolved;document.querySelector('meta[name="theme-color"]').content=resolved==='light'?'#edf3f7':'#181b22';}
setTheme(theme);
const initialState={...mergeSongSettings(song.rehearsal,get(SETTINGS_KEY,{})),key:song.rehearsal.key??initialKey,theme,saved:savedSongs().some(s=>s.id===song.id)};
if(!get(SETTINGS_KEY,null))put(SETTINGS_KEY,{...sharedSongSettings(initialState),quickActions:quickActions()});
window.openai={widgetState:{privateContent:{screens:{bottom:initialState}}},setWidgetState:async value=>{
 const prefs=value.privateContent?.screens?.bottom||value.modelContent?.screens?.bottom;
 if(prefs){put(SETTINGS_KEY,{...get(SETTINGS_KEY,{}),...sharedSongSettings(prefs)});song.rehearsal=normalizeRehearsal(prefs);persistSong();}
 put(savedKey(),value);
}};
await import('./song.js');
const phone=document.querySelector('.qs-phone'),library=document.createElement('section');library.className='kl-library';library.setAttribute('aria-label','Песни');library.hidden=true;phone.append(library);
phone.querySelector('.qs-appearance').setAttribute('aria-label','Общие настройки');
library.innerHTML=`<div class="kl-heading"><div><h2>Песни</h2><small>Текст, аккорды и ваши версии</small></div><button class="qs-icon kl-close" aria-label="Вернуться к песне"><i data-lucide="x" aria-hidden="true"></i></button></div>
<div class="kl-tabs" role="group" aria-label="Открыть песню"><button data-tab="search" aria-pressed="true">Поиск</button><button data-tab="link" aria-pressed="false">Ссылка</button><button data-tab="saved" aria-pressed="false">Мои песни</button></div>
<div class="kl-scroll"><section data-panel="search"><form class="kl-search-form"><label for="kl-query">Песня или исполнитель</label><div class="kl-input-row"><div class="kl-query-wrap"><input id="kl-query" name="q" type="search" maxlength="100" placeholder="Например: Легенда Кино" required minlength="2"><button class="kl-clear-query" type="button" aria-label="Очистить строку поиска" hidden>×</button></div><button class="kl-primary" type="submit">Найти</button></div></form><div class="kl-search-source"><span>AmDm + MyTabs</span><a class="kl-mytabs" href="https://mytabs.ru/" target="_blank" rel="noopener noreferrer">Искать на MyTabs ↗</a></div><div class="kl-history"></div><div class="kl-results"></div></section>
<section data-panel="link" hidden><form class="kl-import-form"><label for="kl-url">Ссылка на песню</label><input id="kl-url" name="url" type="url" placeholder="https://…" required><p>AmDm, MyTabs или сохранённая версия из Квинты.</p><button class="kl-primary" type="submit">Открыть в Квинте</button></form><button class="kl-text-mode">Вставить свой текст с аккордами</button><form class="kl-text-form" hidden><label for="kl-title">Название</label><input id="kl-title" maxlength="180" required placeholder="Моя песня"><label for="kl-text">Текст с аккордами</label><textarea id="kl-text" rows="8" maxlength="100000" required placeholder="[Куплет 1]&#10;Am       F&#10;Текст песни…"></textarea><button class="kl-primary" type="submit">Открыть текст</button></form></section>
<section data-panel="saved" hidden><div class="kl-saved"></div></section><p class="kl-status" role="status" aria-live="polite"></p></div>`;
const $=s=>library.querySelector(s);let notifyTimer,workspace;
function notify(text,{action,actionLabel}={}){const status=phone.querySelector('.qs-status');status.textContent=text;let toast=phone.querySelector('.ke-toast');if(!toast){toast=document.createElement('div');toast.className='ke-toast';toast.setAttribute('role','status');phone.append(toast);}toast.textContent=text;toast.style.pointerEvents=action?'auto':'none';if(action){const button=document.createElement('button');button.type='button';button.textContent=actionLabel||'Вернуть';button.onclick=()=>{if(action()!==false)toast.hidden=true;};toast.append(button);}toast.hidden=false;clearTimeout(notifyTimer);notifyTimer=setTimeout(()=>toast.hidden=true,action?6000:2400);}
window.addEventListener('kvinta:editor-notice',e=>notify(e.detail));
readyToNotify=true;if(pendingStorageError)notify('Не удалось сохранить черновик. Правки пока только в памяти; обновление отложено.');
function status(text){$('.kl-status').textContent=text;}
function openLibrary(tab='search'){if(workspace&&workspace.show('tracks','text')===false)return;window.kvintaPlayer.stop();library.hidden=false;setTab(tab);$('#kl-query').focus({preventScroll:true});}
function closeLibrary(){if(workspace)workspace.show('rehearsal');else library.hidden=true;phone.querySelector('.ke-view')?.focus({preventScroll:true});}
function setTab(tab){library.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.tab===tab)));library.querySelectorAll('[data-panel]').forEach(p=>p.hidden=p.dataset.panel!==tab);status('');if(tab==='saved')renderSaved();}
$('.kl-close').onclick=closeLibrary;library.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
window.addEventListener('kvinta:library',e=>openLibrary(e.detail?.saved?'saved':'search'));
window.addEventListener('kvinta:theme',e=>setTheme(e.detail));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!library.hidden)closeLibrary();});
let busy=false;
async function request(url,message){
 if(busy)return null;busy=true;status(message);library.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=true);library.setAttribute('aria-busy','true');
 try{const data=await fetchSongApi(url);status('');return data;}
 catch(e){status(e.name==='TimeoutError'?'Загрузка затянулась. Попробуйте ещё раз или вставьте текст.':e.message);return null;}
 finally{busy=false;library.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=false);library.removeAttribute('aria-busy');}
}
function loadSong(next){
 try{next=normalizeSong(next);}catch(e){status(e.message);return;}
 if(next.id===song.id){closeLibrary();return;}
 const open=()=>{if(!songStore.activate(next)){status('Не хватает памяти браузера для песни. Текущие правки сохранены в черновике.');return false;}if(location.hash)history.replaceState(null,'',location.pathname);location.reload();return true;};
 if(!draftDirty&&!editor?.dirty){open();return;}
 if(document.querySelector('.ks-leave-song'))return;
 const dialog=document.createElement('dialog');dialog.className='ks-leave-song';dialog.setAttribute('aria-label','Несохранённые изменения');
 const title=document.createElement('h2');title.textContent='Есть несохранённые изменения';const text=document.createElement('p');text.textContent='«'+song.title+'»: сохраните песню или оставьте черновик, чтобы вернуться к правкам позже.';const message=document.createElement('p');message.setAttribute('role','status');const actions=document.createElement('div');actions.className='ks-leave-actions';
 for(const [label,action]of [['Сохранить и открыть',()=>saveSong()],['Оставить черновик',()=>{song=snapshot(song,getPrefs());draftDirty=true;return persistSong();}],['Остаться',null]]){const button=document.createElement('button');button.type='button';button.textContent=label;button.onclick=()=>{if(!action){dialog.close();return;}if(!action()){message.textContent='Не удалось записать изменения. Переход отменён; ваши правки остаются открытыми.';return;}dialog.close();open();};actions.append(button);}
 dialog.append(title,text,actions,message);dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
}
async function importUrl(value){
 let u;try{u=new URL(value);}catch{status('Вставьте полную ссылку.');return;}
 const sharedId=new URLSearchParams(u.hash.slice(1)).get('song');
 if(sharedId&&isKvintaSongUrl(u)){try{const next=await readSharedSong(sharedId);next.id=crypto.randomUUID();loadSong(next);}catch(e){status(e.message);}return;}
 const data=await request('/api/songs/import?url='+encodeURIComponent(value),'Открываю текст и аккорды…');if(data?.song)loadSong(data.song);
}
const HISTORY_KEY='kvinta-song-search-history',CONTEXT_KEY='kvinta-song-search-context';
let searchContext=get(CONTEXT_KEY,null);if(!Array.isArray(searchContext?.data?.results))searchContext=null;
function updateQuery(){const query=$('#kl-query').value.trim();$('.kl-clear-query').hidden=!query;$('.kl-mytabs').href='https://mytabs.ru/searchsite?text='+encodeURIComponent(query)+'&searchid=2308090&web=0';}
$('#kl-query').oninput=updateQuery;
$('.kl-clear-query').onclick=()=>{$('#kl-query').value='';updateQuery();$('#kl-query').focus();};
let historyView;
function renderHistory(){historyView?.destroy();historyView=mountSearchHistory({host:$('.kl-history'),queries:recentSearches(get(HISTORY_KEY,[]),''),onSelect:query=>{$('#kl-query').value=query;void search(query);},onClear:()=>{put(HISTORY_KEY,[]);renderHistory();}});}
async function search(query){query=query.trim();if(query.length<2||busy)return;$('.kl-results').replaceChildren();put(HISTORY_KEY,recentSearches(get(HISTORY_KEY,[]),query));renderHistory();updateQuery();const data=await request('/api/songs/search?q='+encodeURIComponent(query),'Ищу на AmDm и MyTabs…');if(data){searchContext={query,data,selectedUrl:null};put(CONTEXT_KEY,searchContext);renderResults(data);}}
$('.kl-search-form').onsubmit=e=>{e.preventDefault();void search($('#kl-query').value);};
function returnToResults(){openLibrary('search');if(searchContext&&song.source?.url===searchContext.selectedUrl){$('#kl-query').value=searchContext.query;updateQuery();renderResults(searchContext.data);}else{const query=[song.title,song.artist].filter(Boolean).join(' ').slice(0,100);$('#kl-query').value=query;void search(query);}}
renderHistory();if(searchContext){$('#kl-query').value=searchContext.query;updateQuery();renderResults(searchContext.data);}
function renderResults(data){
 const results=$('.kl-results');results.replaceChildren();
 const missing=(data.sources||[]).filter(s=>s.status!=='ok').map(s=>s.name),warning=missing.length?' · '+missing.join(', ')+' пока не отвечает':'';
 if(!data.results.length){status('Ничего не найдено. Попробуйте название вместе с исполнителем'+warning+'.');return;}
 for(const row of data.results){const card=document.createElement('article');card.className='kl-result';card.innerHTML='<div><h3>'+esc(row.title)+'</h3><p>'+esc(row.kind==='artist'?'Исполнитель':row.artist)+'</p><small class="kl-source-badge">'+esc(row.source)+'</small> <a target="_blank" rel="noopener noreferrer">На сайте ↗</a></div><button type="button">'+(row.kind==='artist'?'Песни':'Открыть')+'</button>';card.querySelector('a').href=row.url;card.querySelector('button').onclick=async()=>{if(row.kind==='artist'){const next=await request('/api/songs/artist?url='+encodeURIComponent(row.url),'Открываю песни исполнителя…');if(next){searchContext={query:$('#kl-query').value,data:next,selectedUrl:null};put(CONTEXT_KEY,searchContext);renderResults(next);}}else{if(searchContext){searchContext.selectedUrl=row.url;put(CONTEXT_KEY,searchContext);}void importUrl(row.url);}};results.append(card);}status('Найдено: '+data.results.length+warning);
}
$('.kl-import-form').onsubmit=e=>{e.preventDefault();void importUrl($('#kl-url').value.trim());};
$('.kl-text-mode').onclick=()=>$('.kl-text-form').hidden=!$('.kl-text-form').hidden;
$('.kl-text-form').onsubmit=e=>{e.preventDefault();try{loadSong({schema:1,title:$('#kl-title').value.trim(),artist:'Свой текст',parts:parseText($('#kl-text').value),source:null});}catch(error){status(error.message);}};
function renderSaved(){
 const box=$('.kl-saved'),saved=savedSongs(),items=new Map(saved.map(item=>[item.id,item]));box.replaceChildren();
 for(const record of songStore.drafts())try{const draft=migrate(record.song),base=items.get(draft.id);if(!base||songContent(base)!==songContent(draft))items.set(draft.id,draft);}catch{}
 if(!items.size){box.textContent='Откройте песню и нажмите «Сохранить». Здесь также появятся ваши черновики.';return;}
 for(const item of items.values()){
  const original=saved.find(s=>s.id===item.id),draft=songStore.draft(item.id),hasDraft=!!draft&&(!original||songContent(original)!==songContent(item));
  const row=document.createElement('article'),card=document.createElement('button');row.className='ks-saved-swipe';card.className='ks-saved-card';card.type='button';card.setAttribute('aria-label','Открыть '+(hasDraft?'черновик':'песню')+' «'+item.title+'»');card.innerHTML='<strong>'+esc(item.title)+'</strong><span>'+esc(item.artist||'')+'</span>';
  if(hasDraft){const badge=document.createElement('small');badge.className='ks-draft-label';badge.textContent='Черновик';card.append(badge);}
  card.onclick=()=>loadSong(item);row.append(card);
  setupSwipeDelete({row,content:card,gestureOptions:SONG_SWIPE_OPTIONS,onDelete:()=>{
   let oldRows;try{oldRows=songStore.saved();}catch{notify('Не удалось прочитать библиотеку. Песни не изменены.');return;}
   if(!songStore.writeSaved(oldRows.filter(s=>s?.id!==item.id))||!songStore.forgetDraft(item.id)){notify('Не удалось удалить песню. Попробуйте ещё раз.');renderSaved();return;}
   if(item.id===song.id){draftDirty=false;editor?.markSaved();editSafety.set('song-draft',false);window.kvintaPlayer.change({saved:false});}renderSaved();
   notify('Песня удалена',{action:()=>{let rows;try{rows=songStore.saved();}catch{return false;}if(original&&!rows.some(s=>s?.id===item.id)&&!songStore.writeSaved([original,...rows])){notify('Не удалось вернуть песню. Повторите после освобождения памяти.');return false;}if(draft&&!songStore.restoreDraft(draft)){notify('Не удалось вернуть черновик. Повторите после освобождения памяти.');return false;}if(item.id===song.id){draftDirty=!!draft;if(draft)editor?.markDirty();window.kvintaPlayer.change({saved:!!original});}renderSaved();},actionLabel:'Вернуть'});
  },onShare:()=>showSongShare({getSong:()=>item,getPrefs:()=>item.rehearsal,save:()=>true,privateTrial:false})});box.append(row);
 }
}
function getPrefs(){return window.kvintaPlayer.getState();}
function saveSong(){
 const next=snapshot(song,getPrefs());
 if(!songStore.save(next)){editSafety.set('song-draft',!songStore.remember(next,{dirty:true}));notify('Не удалось сохранить песню. Черновик остаётся открытым; проверьте доступное место и память браузера.');return false;}
 song=next;shared=false;draftDirty=false;editSafety.set('song-draft',false);if(location.hash)history.replaceState(null,'',location.pathname);phone.querySelector('.ke-shared-banner')?.remove();window.kvintaPlayer.change({saved:true});editor?.markSaved();notify('Композиция сохранена');return true;
}
function applySong(next,{recording=false}={}){
 song=normalizeSong({...next,recording:recording?next.recording:song.recording,rehearsal:getPrefs()});shared=false;draftDirty=true;if(location.hash)history.replaceState(null,'',location.pathname);scoreLines=linesOf(song);window.kvintaSongPreview.parts=previewParts();window.kvintaSongPreview.title=song.title;
 const stored=persistSong();window.kvintaPlayer.refresh();return stored;
}
editor=mountEditor({phone,getSong:()=>song,onChange:applySong,onSave:saveSong,onShare:()=>showSongShare({getSong:()=>song,getPrefs,save:saveSong,privateTrial:false}),toDisplay:s=>transpose(s,getPrefs().key),toStored:s=>shift(s,initialKey-getPrefs().key)});
// The star saves the complete current version; editing never toggles it off accidentally.
if(draftDirty)editor.markDirty();
const star=phone.querySelector('.qs-save');star.replaceWith(star.cloneNode(true));phone.querySelector('.qs-save').onclick=saveSong;
phone.querySelector('.qs-nav').hidden=true;
const titleBlock=phone.querySelector('.qs-title-block');titleBlock.setAttribute('role','button');titleBlock.tabIndex=0;titleBlock.setAttribute('aria-label','Вернуться к результатам поиска этой песни');titleBlock.onclick=returnToResults;titleBlock.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();returnToResults();}};
phone.querySelector('.qs-about').hidden=true;
function openHelp(){window.kvintaPlayer.openModal('Песня и редактор','<p><strong>Равномерно</strong> — текст движется с постоянной скоростью. Удерживайте «Равномерно», чтобы открыть ползунок «Скорость»; BPM задаёт щелчки метронома.</p><p><strong>В такт</strong> — прокрутка следует BPM и длительности строк и аккордов. Проверьте доли после импорта. При включённой записи оба режима следуют её позиции и вашим отметкам вступлений.</p><p>Нажмите на название песни, чтобы вернуться к найденным вариантам. «Треки → Текст» открывает поиск и ваши сохранённые песни.</p><p><strong>Редактор:</strong> удерживайте аккорд или метку и переносите на нужное слово. Возле края текст прокрутится. Короткое нажатие открывает замену, цвет, доли и удаление.</p><p>«Над каким словом» выбирает место в строке. Метки могут находиться над аккордами, аккорды друг над другом — нет.</p><p>Доли — длительность аккорда: при размере 4/4 четыре доли составляют такт, при 3/4 — три. В 6/8 две основные доли по три восьмых, как в отдельном метрономе. Размер выбирается рядом с темпом. При разметке записи доли рассчитываются по времени между сменами и подтверждённому BPM с округлением до половины доли. Строки без аккордов внутри интервала получают часть этой длительности для плавной прокрутки. Ручная длительность блока распределяется пропорционально.</p><p><strong>Настройки общие:</strong> «Звук и ритм», «Экран и свет», «Репетиция», «Инструменты», «Приложение». В разделе «Репетиция» можно выбрать до пяти быстрых кнопок и их порядок. Удерживайте саму панель, чтобы изменить её состав. Линия под текущим аккордом видна только «В такт» или с записью и показывает длительность конкретного аккорда, а не обязательно целого такта.</p><p>В настройках включаются четыре удара палочками перед началом, метроном и подсветка. Двойной тап по тексту — полный экран; один тап в полном экране — пауза или продолжение. Темп и исходную тональность импортированной песни проверьте на слух. «Треки → Аудио» открывает запись с телефона. Сначала проверьте исходный BPM или настучите его: «Слушать» → «Настучать темп» → «Применить». Затем отмечайте смены аккордов: первый тап — начало первого аккорда, каждый следующий — начало следующего. В конце нажмите «Конец фрагмента» и «Применить». Доли рассчитываются автоматически, а точные моменты смен сохраняются для репетиции с записью. Можно начать с любого аккорда и разметить только фрагмент. Последний незавершённый аккорд не меняется. Ручные доли и отметки вступлений строк находятся в «Треки → Аудио → Дополнительные настройки». Файл хранится в памяти браузера; при её очистке его потребуется выбрать снова.</p><p>Нажмите значок дискеты «Сохранить песню», чтобы оставить на этом устройстве свою расстановку, метки, цвета и настройки. Кнопка обмена создаёт ссылку на вашу версию.</p><p><strong>Черновики:</strong> правки запоминаются отдельно для каждой песни. При переходе можно сохранить песню, оставить черновик или остаться. Черновики отмечены в «Мои песни» и восстанавливаются при открытии.</p><p><strong>Копия данных:</strong> «Настройки → Приложение → Резервная копия» сохраняет песни, наборы, черновики и настройки в ZIP-файл. Аудио можно включить. При восстановлении отличающиеся версии добавятся отдельно. Сохраните файл в «Файлы» или облако: очистка памяти браузера удаляет локальные данные.</p><p>В полном экране разведите или сведите два пальца, чтобы изменить размер текста. Репетиция продолжится. Один палец прокручивает текст; один тап ставит на паузу, двойной — переключает полный экран.</p><h3>Лицензии компонентов</h3>'+componentLicenseHelp());}
const recording=mountRecording({phone,player:window.kvintaPlayer,getSong:()=>song,onTiming:next=>{const stored=applySong(next,{recording:true});editor.syncExternal();return stored;},onRecord:value=>{song.recording=value;song.updatedAt=Date.now();shared=false;draftDirty=true;if(location.hash)history.replaceState(null,'',location.pathname);const stored=persistSong();editor.markDirty();return stored;},notify});window.kvintaRecording=recording;window.kvintaPlayer.change({});
window.addEventListener('kvinta:backup-capture',event=>{event.detail.currentSong=snapshot(song,getPrefs());event.detail.songDirty=draftDirty||editor.dirty;});
const songTorch=mountSongTorch({phone,player:window.kvintaPlayer,notify});window.kvintaSongEffects=songTorch;
const toolbar=mountQuickActions({phone,player:window.kvintaPlayer,initial:get(SETTINGS_KEY,{}).quickActions,onChange:actions=>put(SETTINGS_KEY,{...get(SETTINGS_KEY,{}),quickActions:actions}),onTorch:value=>{if(value)songTorch.open();else songTorch.stop();},notify});
workspace=mountSongWorkspace({phone,editor,recording,library,player:window.kvintaPlayer});
window.addEventListener('kvinta:torch-setting',e=>{if(e.detail)songTorch.open();else songTorch.stop();});
window.addEventListener('pagehide',()=>songTorch.stop());
if(shared){const banner=document.createElement('div');banner.className='ke-shared-banner';banner.innerHTML='<span>Версия по ссылке</span><button>Сохранить себе</button>';banner.querySelector('button').onclick=saveSong;phone.querySelector('.qs-song-heading').after(banner);}
if(globalThis.lucide)lucide.createIcons();
if(wasExample&&!shared&&!new URLSearchParams(location.search).has('recording'))openLibrary();if(sharedError){openLibrary('link');status(sharedError);}

phone.querySelector('.qs-appearance').addEventListener('click',()=>organizeRehearsalMenu({phone,player:window.kvintaPlayer,toolbar,songTorch,openHelp}));
window.addEventListener('kvinta-before-update',()=>{song.rehearsal=normalizeRehearsal(window.kvintaPlayer.getState());persistSong();});
if(new URLSearchParams(location.search).has('recording'))window.kvintaRecording.open();
const queryFromLink=new URLSearchParams(location.search).get('q')?.trim().slice(0,100);if(queryFromLink?.length>=2){openLibrary();$('#kl-query').value=queryFromLink;void search(queryFromLink);}
document.documentElement.dataset.kvintaReady='true';
