export function pinchFontSize(initial,initialDistance,distance){
 return Math.max(10,Math.min(28,Math.round(initial*distance/Math.max(1,initialDistance))));
}
// Zoom only the score. The audio clock and beat scheduler keep running.
export function mountPinchZoom({phone,reader,getSize,onSize,onStart,onEnd}){
 const doc=phone.ownerDocument,win=doc.defaultView;
 let active=false,consumed=false,startDistance=0,startSize=22,frame=0,nextSize=22,blockedUntil=0;
 const distance=touches=>Math.hypot(touches[0].clientX-touches[1].clientX,touches[0].clientY-touches[1].clientY);
 function apply(){frame=0;if(!active||nextSize===getSize())return;
  const box=reader.getBoundingClientRect(),y=box.top+box.height*.4;
  const lines=[...reader.querySelectorAll('.qs-line')],anchor=lines.find(line=>line.getBoundingClientRect().bottom>=y)||lines.at(-1);
  const before=anchor?.getBoundingClientRect().top;onSize(nextSize);
  if(anchor)reader.scrollTop+=anchor.getBoundingClientRect().top-before;
 }
 win.addEventListener('touchstart',event=>{
  if(phone.dataset.fullscreen!=='true'||phone.dataset.editing==='true'||!reader.contains(event.target)||event.touches.length!==2)return;
  active=consumed=true;startDistance=distance(event.touches);startSize=getSize();nextSize=startSize;phone.dataset.pinching='true';onStart?.();
 },{capture:true,passive:true});
 win.addEventListener('touchmove',event=>{
  if(!consumed)return;event.preventDefault();event.stopImmediatePropagation();
  if(active&&event.touches.length===2){nextSize=pinchFontSize(startSize,startDistance,distance(event.touches));if(!frame)frame=win.requestAnimationFrame(apply);}
 },{capture:true,passive:false});
 function finish(event){if(!consumed)return;event.stopImmediatePropagation();if(active&&event.touches.length<2){apply();active=false;delete phone.dataset.pinching;onEnd?.();}if(!event.touches.length){consumed=false;blockedUntil=performance.now()+450;}}
 win.addEventListener('touchend',finish,{capture:true,passive:true});win.addEventListener('touchcancel',finish,{capture:true,passive:true});
 for(const type of ['pointermove','pointerup','click'])win.addEventListener(type,event=>{if(consumed||performance.now()<blockedUntil&&reader.contains(event.target)){event.stopImmediatePropagation();}},{capture:true});
 return {get active(){return active;},get blocked(){return consumed||performance.now()<blockedUntil;}};
}
