import {normalizeSong,linesOf,allocate,lineBeats} from './score-model.js';

export function orderedChords(song){
 return song.parts.flatMap(part=>part.lines.flatMap(line=>line.chords.map(chord=>({
  id:chord.id,symbol:chord.symbol,lineId:line.id,text:line.text,part:part.name
 }))));
}
const identity=song=>JSON.stringify([song.id,song.recording?.localId,song.recording?.name,song.recording?.duration,song.recording?.referenceBpm,orderedChords(song).map(c=>c.id)]);

// Taps measure time, not tempo. BPM is confirmed separately; exact audio times
// survive the half-beat rounding used by the score editor.
export function applyChordTiming(song,{start=0,boundaries,bpm=song.recording?.referenceBpm}){
 const next=normalizeSong(song),record=next.recording,refs=orderedChords(next);
 if(!record||!Number.isFinite(bpm)||bpm<40||bpm>220||!Number.isInteger(start)||start<0||start>=refs.length||!Array.isArray(boundaries)||boundaries.length<2||boundaries.length>refs.length-start+1)throw Error('Отметьте начало и конец хотя бы одного аккорда.');
 const times=boundaries.map(at=>Math.round(at*1000)/1000);
 if(times.some((at,i)=>!Number.isFinite(at)||at<0||at>record.duration||(i&&at-times[i-1]<.08)))throw Error('Отметки должны идти по порядку во время звучания записи.');
 const lines=linesOf(next),durations=[],stamps=[];let rounding=0;
 for(let i=0;i<times.length-1;i++){
  const ref=refs[start+i],lineIndex=lines.findIndex(l=>l.id===ref.lineId),line=lines[lineIndex],chord=line.chords.find(c=>c.id===ref.id);
  const targets=[chord];
  if(line.chords.at(-1).id===ref.id){for(let j=lineIndex+1;j<lines.length&&!lines[j].chords.length;j++)targets.push(lines[j]);}
  const raw=(times[i+1]-times[i])*bpm/60,beats=Math.max(targets.length/2,Math.round((raw+rounding)*2)/2);
  if(beats>8192)throw Error('Слишком длинный промежуток. Проверьте отметки или темп записи.');
  rounding+=raw-beats;
  const values=allocate(beats,targets.map(target=>target===chord?Math.max(1,line.text.length):Math.max(1,target.text.length)));
  targets.forEach((target,j)=>target.beats=values[j]);
  durations.push({chordId:ref.id,symbol:ref.symbol,beats,at:times[i],endAt:times[i+1]});
  stamps.push({chordId:ref.id,at:times[i],endAt:times[i+1]});
 }
 // Re-marking a fragment replaces its anchors. Old anchors crossing the new
 // fragment are discarded rather than producing a backwards audio clock.
 const ids=new Set(stamps.map(t=>t.chordId)),first=start,last=start+stamps.length-1,positions=new Map(refs.map((c,i)=>[c.id,i]));
 const kept=(record.chordTimes||[]).filter(t=>!ids.has(t.chordId)&&(positions.get(t.chordId)<first?t.endAt<=times[0]:positions.get(t.chordId)>last&&t.at>=times.at(-1)));
 next.recording={...record,referenceBpm:bpm,tempoVerified:true,enabled:true,chordTimes:[...kept,...stamps]};
 // Chord anchors supersede older line taps in the marked region. The timing
 // map interpolates lyric-only lines inside the measured interval as well.
 next.updatedAt=Date.now();
 return {song:normalizeSong(next),durations};
}

export function createChordTimingSession({getSong,getTime,isPlaying,getRate=()=>1}){
 let key=null,start=0,boundaries=[],finished=false,message='';
 function sync(){const next=identity(getSong());if(next!==key){key=next;start=0;boundaries=[];finished=false;message='';}}
 function state(){
  sync();const song=getSong(),chords=orderedChords(song),count=Math.max(0,boundaries.length-1),nextIndex=start+boundaries.length;
  return {chords,start,boundaries:[...boundaries],finished,count,dirty:!!boundaries.length,message,
   current:boundaries.length?chords[start+boundaries.length-1]:null,next:chords[nextIndex],
   canTap:!!song.recording?.tempoVerified&&!!chords.length&&!finished&&isPlaying()&&Math.abs(getRate()-1)<.0001,
   canApply:count>0,canUndo:!!boundaries.length};
 }
 function reset(index=0){sync();start=Number.isInteger(index)&&index>=0&&index<orderedChords(getSong()).length?index:0;boundaries=[];finished=false;message='';return state();}
 function mark(finish=false){
  const current=state();message='';if(!current.canTap)return {...state(),ignored:true};
  const at=Math.round(getTime()*1000)/1000,previous=boundaries.at(-1),duration=getSong().recording.duration;
  if(!Number.isFinite(at)||at<0||at>duration||(previous!==undefined&&at-previous<.08)){message='После перемотки вернитесь за последнюю отметку или отмените её.';return {...state(),ignored:true};}
  if(finish&&!boundaries.length)return {...state(),ignored:true};
  boundaries.push(at);finished=finish||boundaries.length===current.chords.length-start+1;return state();
 }
 function undo(){sync();boundaries.pop();finished=false;message='';return state();}
 function result(){const value=state();return applyChordTiming(getSong(),{start,boundaries:value.boundaries});}
 return {state,reset,tap:()=>mark(false),finish:()=>mark(true),undo,result};
}

export function chordAnchorOffsets(song){
 const result=new Map();let beat=0;const lines=linesOf(song);
 for(let i=0;i<lines.length;i++){
  const line=lines[i];
  for(const chord of line.chords){result.set(chord.id,{start:beat,end:beat+chord.beats});beat+=chord.beats;}
  if(!line.chords.length)beat+=lineBeats(line);
  else if(result.has(line.chords.at(-1).id)){
   let after=beat;for(let j=i+1;j<lines.length&&!lines[j].chords.length;j++)after+=lineBeats(lines[j]);
   result.get(line.chords.at(-1).id).end=after;
  }
 }
 return result;
}
