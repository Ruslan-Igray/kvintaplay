import {CUE_PRESETS,COLORS,linesOf,findLine,findChord,moveChord,addChord,setPartBeats,partBeats,songMeter,splitPart,createHistory,canPlaceChord,nextFreeChordColumn} from './score-model.js';
import {dragScrollVelocity,visibleEditorLine} from './editor-motion.js';
import {createSelectWheel} from './select-wheel.js';
import {wordPositions,chordWordPositions} from './editor-controls.js';
import {createChordPlayer} from '../modules/chord-player.js';
import {songChordNotes} from './chord-audition.js';
import {mountDurationControl} from './number-control.js';
import {showChordDiagram} from './chord-viewer.js';
import {EDITOR_KEY,editorDefaults} from './song-settings.js';
const copy=value=>JSON.parse(JSON.stringify(value));
const number=value=>String(Number(value.toFixed(2))).replace('.',',');
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function mountEditor({phone,getSong,onChange,onSave,onShare,toDisplay=s=>s,toStored=s=>s}){
 let editing=false,dirty=false,history=createHistory(getSong()),selected=null,pointer=null,hold=null,drag=null,swallowUntil=0,scrollFrame=0,lastFrame=0;
 let defaults;try{defaults=editorDefaults(JSON.parse(localStorage.getItem(EDITOR_KEY)||'{}'));}catch{defaults=editorDefaults();}
 function remember(patch){defaults=editorDefaults({...defaults,...patch});try{localStorage.setItem(EDITOR_KEY,JSON.stringify(defaults));}catch{}}
 const reader=phone.querySelector('.qs-reader');
 const bar=document.createElement('div');bar.className='ke-editbar';
 bar.innerHTML='<div class="ke-edit-switch" role="group" aria-label="Работа с песней"><button class="ke-view" aria-pressed="true">Репетиция</button><button class="ke-edit" aria-pressed="false">Редактор</button></div><button class="ke-undo qs-icon" aria-label="Отменить правку" disabled><i data-lucide="undo-2" aria-hidden="true"></i></button><button class="ke-save qs-icon kv-line-action" type="button" aria-label="Сохранить песню" title="Сохранить песню"><i data-lucide="save" aria-hidden="true"></i></button><button class="ke-share qs-icon kv-line-action" aria-label="Поделиться композицией"><i data-lucide="share-2" aria-hidden="true"></i></button>';
 phone.querySelector('.qs-song-heading').after(bar);
 const editTools=document.createElement('div');editTools.className='ke-addbar';editTools.hidden=true;
 editTools.innerHTML='<button class="ke-add-chord">+ Аккорд</button><button class="ke-add-cue">Метка</button><button class="ke-part">Блок</button><span class="ke-dirty" role="status" aria-live="polite"></span>';
 bar.after(editTools);
 editTools.append(bar.querySelector('.ke-undo'));
 const overlay=document.createElement('div');overlay.className='ke-overlay';overlay.hidden=true;
 overlay.innerHTML='<section class="ke-dialog" role="dialog" aria-modal="true" aria-label="Редактирование"><header><h2></h2><button class="qs-icon ke-modal-close" aria-label="Закрыть редактирование"><i data-lucide="x" aria-hidden="true"></i></button></header><div class="ke-dialog-body"></div><div class="ke-dialog-actions"></div></section>';
 phone.append(overlay);
 const ghost=document.createElement('div');ghost.className='ke-drag-ghost';ghost.hidden=true;ghost.setAttribute('aria-hidden','true');
 const caret=document.createElement('div');caret.className='ke-drop-caret';caret.hidden=true;caret.setAttribute('aria-hidden','true');phone.append(ghost,caret);
 const $=s=>phone.querySelector(s),$$=s=>[...phone.querySelectorAll(s)];
 let previousFocus=null,inertBefore=[],wheels=[],extras=[];
 const chordAudio=createChordPlayer({onState:state=>{const preview=$('.ke-chord-preview');if(preview)preview.dataset.playing=String(state==='playing');}});
 function clearWheels(){chordAudio.stop();for(const wheel of [...wheels,...extras])wheel.destroy();wheels=[];extras=[];}
 function mountWheels(){for(const select of overlay.querySelectorAll('.ke-root,.ke-quality,.ke-cue-preset'))wheels.push(createSelectWheel(select,{label:select.getAttribute('aria-label')}));}
 function icons(){globalThis.lucide?.createIcons();}
 function show(title,body,actions){clearWheels();delete $('.ke-dialog').dataset.kind;$('.ke-chord-view')?.remove();window.kvintaPlayer.stop();previousFocus=document.activeElement;overlay.querySelector('h2').textContent=title;$('.ke-dialog-body').innerHTML=body;$('.ke-dialog-actions').innerHTML=actions;inertBefore=[...phone.children].filter(el=>el!==overlay).map(el=>[el,el.inert]);for(const [el]of inertBefore)el.inert=true;overlay.hidden=false;icons();$('.ke-modal-close').focus();}
 function close(){clearWheels();overlay.hidden=true;for(const [el,value]of inertBefore)el.inert=value;inertBefore=[];if(previousFocus?.isConnected)previousFocus.focus?.({preventScroll:true});else $(editing?'.ke-edit':'.ke-view').focus({preventScroll:true});}
 $('.ke-modal-close').onclick=close;overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
 function updateBar(){
  phone.dataset.editing=String(editing);window.kvintaEditing=editing;editTools.hidden=!editing;
  $('.ke-view').setAttribute('aria-pressed',String(!editing&&phone.dataset.workspace!=='tracks'));$('.ke-edit').setAttribute('aria-pressed',String(editing));
  $('.ke-undo').disabled=!history.canUndo;$('.ke-dirty').textContent=dirty?'Есть правки':'';
  $('.ke-save').classList.toggle('is-dirty',dirty);
 }
 function setEditing(value){if(editing===value)return;cancel();window.kvintaPlayer.stop();editing=!!value;window.kvintaEditing=editing;window.kvintaPlayer.refresh();updateBar();}
 function notice(text){$('.ke-dirty').textContent=text;window.dispatchEvent(new CustomEvent('kvinta:editor-notice',{detail:text}));}
 function reveal(lineId,itemId){
  selected={lineId,column:selected?.column||0};const line=$$('.qs-line').find(el=>el.dataset.lineId===lineId);if(!line)return;
  $$('.ke-selected-line').forEach(el=>el.classList.remove('ke-selected-line'));line.classList.add('ke-selected-line');
  const item=itemId?[...line.querySelectorAll('[data-chord-id],[data-cue-id]')].find(el=>el.dataset.chordId===itemId||el.dataset.cueId===itemId):line,r=(item||line).getBoundingClientRect(),box=reader.getBoundingClientRect();
  if(r.top<box.top+12)reader.scrollTop-=box.top+12-r.top;else if(r.bottom>box.bottom-12)reader.scrollTop+=r.bottom-(box.bottom-12);
  if(item)item.classList.add('ke-just-added');
 }
 function mutate(fn){try{const next=copy(getSong());if(fn(next)===false)return false;next.updatedAt=Date.now();history.commit(next);dirty=true;onChange(next);updateBar();return true;}catch(error){notice(error.message||'Не удалось сохранить правку.');return false;}}
 function decorate(){
  const song=getSong();$$('.qs-part').forEach((el,i)=>{const part=song.parts[i],h=el.querySelector('h2');el.dataset.partId=part.id;h.replaceChildren();const button=document.createElement('button');button.type='button';button.className='ke-part-title';button.textContent=part.name;button.setAttribute('aria-label','Настроить блок '+part.name);button.disabled=!editing;button.onclick=()=>openPart(part.id);h.append(button);});
  $$('.qs-line').forEach((el,i)=>{el.dataset.lineId=linesOf(song)[i].id;});icons();
 }
 window.addEventListener('kvinta:score-rendered',decorate);
 function context(){const box=reader.getBoundingClientRect(),id=visibleEditorLine($$('.qs-line').map(el=>{const r=el.getBoundingClientRect();return {id:el.dataset.lineId,top:r.top,bottom:r.bottom};}),box.top,box.bottom,selected?.lineId);return {lineId:id||linesOf(getSong())[0].id,column:id===selected?.lineId?selected.column:0};}
 $('.ke-edit').onclick=()=>setEditing(true);$('.ke-view').onclick=()=>setEditing(false);
 $('.ke-undo').onclick=()=>{const next=history.undo();dirty=true;onChange(next);updateBar();};
 $('.ke-save').onclick=()=>{if(onSave()){dirty=false;updateBar();}};
 $('.ke-share').onclick=()=>{window.kvintaPlayer.stop();onShare();};
 $('.ke-add-chord').onclick=()=>{const c=context();openChord(null,c.lineId,c.column);};
 $('.ke-add-cue').onclick=()=>{const c=context();openCue(c.lineId,null,'cue',c.column);};
 $('.ke-part').onclick=()=>{const c=context(),p=getSong().parts.find(p=>p.lines.some(l=>l.id===c.lineId));openPart(p.id);};
 window.addEventListener('kvinta:finish-edit',()=>{if(editing)setEditing(false);});
 window.addEventListener('kvinta:edit-block',e=>{const line=linesOf(getSong())[e.detail.line],part=getSong().parts.find(p=>p.lines.includes(line));if(part)openPart(part.id);});
 function chordFields(symbol){
  const match=symbol.match(/^([A-H][#b♯♭]*)(.*)$/),root=match?.[1]||'Am',quality=match?.[2]||'';
  const notes=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];if(!notes.includes(root))notes.push(root);
  const types=[['','Мажор'],['m','Минор'],['7','7'],['maj7','maj7'],['m7','m7'],['sus2','sus2'],['sus4','sus4'],['5','5'],['dim','dim'],['aug','aug'],['add9','add9'],['9','9'],['m7b5','m7b5']];if(!types.some(x=>x[0]===quality))types.push([quality,quality]);
  return '<div class="ke-chord-fields"><label>Основной тон<select class="ke-root">'+notes.map(n=>'<option '+(n===root?'selected':'')+'>'+esc(n)+'</option>').join('')+'</select></label><label>Тип аккорда<select class="ke-quality">'+types.map(([v,label])=>'<option value="'+esc(v)+'" '+(v===quality?'selected':'')+'>'+esc(label)+'</option>').join('')+'</select></label></div><button type="button" class="ke-chord-preview" title="Нажмите, чтобы послушать">'+esc(symbol)+'</button>';
 }
 function positionControl(line,column){
  return '<p class="ke-field-title">Над словом</p><div class="ke-word-positions" role="group" aria-label="Положение над текстом">'+wordPositions(line.text,column).map(w=>'<button type="button" data-column="'+w.column+'" aria-pressed="'+String(w.column===column)+'">'+esc(w.label)+'</button>').join('')+'</div>';
 }
 function bindPosition(column,onChange=()=>{}){let current=column;$$('[data-column]').forEach(b=>b.onclick=()=>{current=Number(b.dataset.column);$$('[data-column]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));onChange();});return ()=>current;}
 function colors(current){return '<div class="ke-colors" role="group" aria-label="Цвет">'+COLORS.map((c,i)=>'<button type="button" class="ke-color" data-color="'+c+'" aria-label="'+['Жёлтый','Зелёный','Синий','Фиолетовый','Розовый','Красный'][i]+'" aria-pressed="'+String(c===(current||'amber'))+'"><span></span></button>').join('')+'</div>';}
 function bindColor(current){let color=current;$$('.ke-color').forEach(b=>b.onclick=()=>{color=b.dataset.color;$$('.ke-color').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));});return ()=>color;}
 function openChord(chordId,lineId,column=0){
  const found=chordId?findChord(getSong(),chordId):null,line=found?.line||findLine(getSong(),lineId);if(!line)return;
  const chord=found?.chord||{symbol:toStored(defaults.symbol),beats:defaults.beats,color:defaults.color,column:nextFreeChordColumn(line,column,toStored(defaults.symbol))??0};selected={lineId:line.id,column:chord.column};
  show(chordId?'Аккорд':'Добавить аккорд',chordFields(toDisplay(chord.symbol))+'<div class="ke-duration-row"><span>Доли</span><div class="ke-duration-mount"></div></div><p class="ke-field-title">Цвет</p>'+colors(chord.color)+positionControl(line,chord.column),(chordId?'<button class="ke-delete">Удалить</button>':'')+'<button class="ke-apply kl-primary">Готово</button>');
  const dialog=$('.ke-dialog');dialog.dataset.kind='chord';const preview=$('.ke-chord-preview');dialog.querySelector('h2').append(preview);const view=document.createElement('button');view.type='button';view.className='ke-chord-view';view.textContent='На грифе';dialog.querySelector('.ke-modal-close').before(view);view.onclick=()=>{for(const wheel of wheels)wheel.flush();showChordDiagram(overlay,dialog,readSymbol());};
  const duration=mountDurationControl($('.ke-duration-mount'),chord.beats);extras.push(duration);
  $('.ke-root').id='ke-root';$('.ke-quality').id='ke-quality';$('.ke-root').setAttribute('aria-label','Основной тон');$('.ke-quality').setAttribute('aria-label','Тип аккорда');
  const error=document.createElement('p');error.className='ke-form-error';error.setAttribute('role','status');$('.ke-dialog-body').append(error);
  const readSymbol=()=>$('.ke-root').value+$('.ke-quality').value,readPosition=bindPosition(chord.column,validate),readColor=bindColor(chord.color);
  function validate(){const symbol=readSymbol(),valid=canPlaceChord(line,readPosition(),toStored(symbol),chordId);preview.textContent=symbol;preview.setAttribute('aria-label','Проиграть аккорд '+symbol);preview.disabled=!songChordNotes(symbol).length;for(const word of chordWordPositions(line,chord.column,toStored(symbol),chordId)){const button=$$('[data-column]').find(b=>Number(b.dataset.column)===word.column);if(button){button.disabled=word.occupied;button.dataset.occupied=String(word.occupied);button.title=word.occupied?'Место занято другим аккордом':'';}}error.hidden=valid;error.textContent=valid?'':'Это место занято. Выберите соседнее слово.';$('.ke-apply').disabled=!valid;return valid;}
  preview.onclick=()=>{for(const wheel of wheels)wheel.flush();validate();void chordAudio.play(songChordNotes(readSymbol()));};
  for(const name of ['.ke-root','.ke-quality'])$(name).onchange=validate;
  mountWheels();validate();
  $('.ke-apply').onclick=()=>{for(const wheel of wheels)wheel.flush();if(!validate())return;const symbol=toStored(readSymbol()),beats=duration.read(),col=readPosition(),color=readColor();if(!Number.isFinite(beats)||beats<.5||beats>8192){error.textContent='Укажите от 0,5 до 8192 долей.';return;}let id=chordId;
   const saved=mutate(song=>{let c;if(chordId){const f=findChord(song,chordId);if(!f)return false;c=f.chord;c.symbol=symbol;c.beats=Math.round(beats*2)/2;if(!moveChord(song,chordId,line.id,col))return false;}else{c=addChord(song,line.id,col,symbol,beats);id=c.id;}if(COLORS.includes(color))c.color=color;else delete c.color;});if(saved){remember({symbol:readSymbol(),beats,color});close();selected={lineId:line.id,column:col};reveal(line.id,id);}};
  if(chordId)$('.ke-delete').onclick=()=>{mutate(song=>{const f=findChord(song,chordId);f.line.chords=f.line.chords.filter(c=>c.id!==chordId);});close();};
 }
 function openCue(lineId,cueId=null,type='cue',column=0){
  const line=findLine(getSong(),lineId);if(!line)return;const cue=line.cues.find(c=>c.id===cueId)||{preset:defaults.preset,label:CUE_PRESETS.find(p=>p.id===defaults.preset)?.label||'Метка',color:defaults.cueColor,type,column};
  show(cue.type==='line'?'Цветная линия':'Метка для игры',(cue.type==='cue'?'<label class="ke-field-title">Действие<select class="ke-cue-preset" id="ke-cue-action" aria-label="Действие метки">'+CUE_PRESETS.map(p=>'<option value="'+p.id+'" '+(p.id===cue.preset?'selected':'')+'>'+p.label+'</option>').join('')+'</select></label><label class="ke-field-title">Подпись<input class="ke-cue-label" maxlength="50" value="'+esc(cue.label)+'" placeholder="Например: Delay"></label>':'')+'<p class="ke-field-title">Цвет</p>'+colors(cue.color)+positionControl(line,cue.column||0),(cueId?'<button class="ke-delete">Удалить</button>':'')+'<button class="ke-apply kl-primary">Готово</button>');
  $('.ke-dialog').dataset.kind='cue';const readPosition=bindPosition(cue.column||0),readColor=bindColor(cue.color);mountWheels();if(cue.type==='cue'){$$('#ke-cue-action-wheel .drum-value').forEach((row,i)=>{row.innerHTML='<i data-lucide="'+CUE_PRESETS[i].icon+'" aria-hidden="true"></i><span>'+esc(CUE_PRESETS[i].label)+'</span>';});icons();}
  if(cue.type==='cue')$('.ke-cue-preset').onchange=e=>{$('.ke-cue-label').value=CUE_PRESETS.find(p=>p.id===e.target.value).label;};
  $('.ke-apply').onclick=()=>{for(const wheel of wheels)wheel.flush();const preset=cue.type==='cue'?$('.ke-cue-preset').value:'custom',label=cue.type==='cue'?$('.ke-cue-label').value.trim():'',id=cueId||crypto.randomUUID();const saved=mutate(song=>{const target=findLine(song,lineId);if(!cueId&&target.cues.length>=16)throw Error('В строке уже 16 меток. Выберите другую строку.');const next={id,type:cue.type,preset,label,color:readColor(),column:readPosition()};const i=target.cues.findIndex(c=>c.id===cueId);if(i<0)target.cues.push(next);else target.cues[i]=next;});if(saved){remember({preset,cueColor:readColor()});close();selected={lineId,column:readPosition()};reveal(lineId,id);}};
  if(cueId)$('.ke-delete').onclick=()=>{mutate(song=>{const target=findLine(song,lineId);target.cues=target.cues.filter(c=>c.id!==cueId);});close();};
 }
 function openPart(partId){
  const part=getSong().parts.find(p=>p.id===partId);if(!part)return;const minimum=part.lines.reduce((n,l)=>n+Math.max(1,l.chords.length),0)/2,total=partBeats(part);
  show('Длительность блока','<label class="ke-field-title">Название<input class="ke-part-name" maxlength="80" value="'+esc(part.name)+'"></label><div class="ke-part-presets"><button data-part-name="Куплет">Куплет</button><button data-part-name="Припев">Припев</button><button data-part-name="Проигрыш">Проигрыш</button></div><div class="ke-duration-row"><span>Всего долей в блоке</span><div class="ke-block-duration"></div></div><p class="ke-block-summary ke-small" role="status"></p><p class="ke-small">Доля — один основной щелчок метронома. Например, в размере 4/4: Am — 4, F — 4, C — 4, G — 4. Вместе 16 долей, или 4 такта. Здесь задаётся время всего блока; оно распределится между аккордами пропорционально.</p><p class="ke-small">Проведите по числу вверх или вниз либо нажмите и введите значение. После импорта число — предварительная сумма всех аккордов, поэтому оно может быть большим. Для одного аккорда: вернитесь в редактор, нажмите этот аккорд и измените его длительность.</p>','<button class="ke-apply kl-primary">Сохранить блок</button>');
  const meter=songMeter(window.kvintaPlayer.getState().meter||getSong().rehearsal.meter),format=n=>String(Number(n.toFixed(2))).replace('.',','),summary=value=>{$('.ke-block-summary').textContent=format(value)+' долей · '+format(value/meter.beats)+' такт. ('+meter.id+') · '+part.lines.reduce((n,l)=>n+l.chords.length,0)+' аккордов';};
  const control=mountDurationControl($('.ke-block-duration'),total,{min:minimum,max:Math.max(128,total*2,minimum),label:'Длительность блока, доли',onChange:summary});extras.push(control);summary(total);const readBeats=()=>control.read();$$('[data-part-name]').forEach(b=>b.onclick=()=>$('.ke-part-name').value=b.dataset.partName);
  $('.ke-apply').onclick=()=>{const name=$('.ke-part-name').value.trim()||part.name,total=readBeats();mutate(song=>{const p=song.parts.find(p=>p.id===partId);p.name=name;setPartBeats(p,total);});close();};
 }
 function openPosition(lineId,column){
  selected={lineId,column};
  show('В этом месте','<div class="ke-position-actions"><button data-add="chord"><i data-lucide="music-2" aria-hidden="true"></i>Аккорд</button><button data-add="cue"><i data-lucide="flag" aria-hidden="true"></i>Метка для игры</button><button data-add="line"><i data-lucide="minus" aria-hidden="true"></i>Цветная линия</button><button data-add="block"><i data-lucide="list-music" aria-hidden="true"></i>Начать новый блок</button></div>','');icons();
  $$('[data-add]').forEach(b=>b.onclick=()=>{close();if(b.dataset.add==='chord')openChord(null,lineId,column);else if(b.dataset.add==='block'){show('Новый блок','<div class="ke-position-actions"><button data-split="Куплет">Куплет</button><button data-split="Припев">Припев</button><button data-split="Проигрыш">Проигрыш</button></div>','');$$('[data-split]').forEach(x=>x.onclick=()=>{mutate(song=>splitPart(song,lineId,x.dataset.split));close();});}else openCue(lineId,null,b.dataset.add==='line'?'line':'cue',column);});
 }
 function locate(x,y){
  const node=document.elementFromPoint(x,y),line=node?.closest('.qs-line');if(!line||!reader.contains(line))return null;
  const model=findLine(getSong(),line.dataset.lineId);if(!model)return null;
  let textNode=null,offset=0;const pos=document.caretPositionFromPoint?.(x,y);if(pos){textNode=pos.offsetNode;offset=pos.offset;}else{const range=document.caretRangeFromPoint?.(x,y);if(range){textNode=range.startContainer;offset=range.startOffset;}}
  let word=textNode?.parentElement?.closest('.qs-words');
  if(!word||!line.contains(word)){const words=[...line.querySelectorAll('.qs-words')];word=words.reduce((best,w)=>{const r=w.getBoundingClientRect(),distance=Math.abs(y-(r.top+r.height/2))+Math.max(r.left-x,0,x-r.right);return !best||distance<best.d?{w,d:distance}:best;},null)?.w;if(word){const r=word.getBoundingClientRect(),char=r.width/Math.max(1,word.textContent.length);offset=Math.round((x-r.left)/Math.max(1,char));}}
  const start=Number(word?.dataset.start)||0,column=Math.max(0,Math.min(Math.max(model.text.length,32,...model.chords.map(c=>c.column+8)),start+Math.max(0,offset)));
  let rect=word?.getBoundingClientRect()||line.getBoundingClientRect(),left=rect.left;
  if(word?.firstChild){try{const range=document.createRange();range.setStart(word.firstChild,Math.min(word.textContent.length,Math.max(0,column-start)));range.collapse(true);const r=range.getBoundingClientRect();if(r.height){rect=r;left=r.left;}}catch{}}
  return {lineId:model.id,column,line,x:left,y:rect.top,height:Math.max(20,rect.height)};
 }
 function positionDrag(){
  if(!drag)return;const box=phone.getBoundingClientRect(),bounds=reader.getBoundingClientRect(),target=locate(Math.max(bounds.left+4,Math.min(bounds.right-8,drag.x)),Math.max(bounds.top+3,Math.min(bounds.bottom-3,drag.y)));
  drag.target=target;
  const chord=drag.chordId?findChord(getSong(),drag.chordId)?.chord:null;
  drag.valid=!!target&&(!chord||canPlaceChord(findLine(getSong(),target.lineId),target.column,chord.symbol,drag.chordId));
  ghost.style.transform='translate('+Math.max(0,Math.min(box.width-70,drag.x-box.left-26))+'px,'+Math.max(0,Math.min(box.height-48,drag.y-box.top-55))+'px)';
  $$('.ke-drop-target').forEach(el=>el.classList.remove('ke-drop-target'));
  caret.hidden=!target;ghost.classList.toggle('invalid',!drag.valid);caret.classList.toggle('invalid',!drag.valid);
  if(target){target.line.classList.add('ke-drop-target');caret.style.left=(target.x-box.left)+'px';caret.style.top=(target.y-box.top-24)+'px';caret.style.height=(target.height+24)+'px';}
 }
 function autoScroll(now){
  if(!drag)return;const dt=Math.min(.04,(now-lastFrame)/1000||0);lastFrame=now;const rect=reader.getBoundingClientRect(),velocity=dragScrollVelocity(drag.y,rect.top,rect.bottom,drag.direction);
  if(velocity)reader.scrollTop+=velocity*dt;positionDrag();scrollFrame=requestAnimationFrame(autoScroll);
 }
 function take(){
  if(hold)clearTimeout(hold);hold=null;if(!pointer?.element||drag)return;
  drag={...pointer,target:null,valid:false,direction:Math.sign(pointer.y-pointer.startY)};ghost.textContent=pointer.label;ghost.hidden=false;pointer.element.classList.add('ke-picked');phone.dataset.editorDragging='true';
  if(!phone.hasPointerCapture(pointer.id))phone.setPointerCapture(pointer.id);positionDrag();lastFrame=performance.now();scrollFrame=requestAnimationFrame(autoScroll);
 }
 function cancel(){
  if(hold)clearTimeout(hold);hold=null;cancelAnimationFrame(scrollFrame);scrollFrame=0;ghost.hidden=true;caret.hidden=true;delete phone.dataset.editorDragging;
  $$('.ke-picked,.ke-drop-target').forEach(el=>el.classList.remove('ke-picked','ke-drop-target'));
  const id=pointer?.id;pointer=null;drag=null;if(id!==undefined&&phone.hasPointerCapture(id))phone.releasePointerCapture(id);
 }
 phone.addEventListener('pointerdown',e=>{
  if(!editing||!overlay.hidden||e.button!==0||e.isPrimary===false||!reader.contains(e.target))return;
  cancel();const element=e.target.closest('.qs-chord,.ke-cue,.ke-divider'),line=e.target.closest('.qs-line');
  pointer={id:e.pointerId,type:e.pointerType,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,element,lineId:line?.dataset.lineId,top:reader.scrollTop,pan:false,chordId:element?.dataset.chordId,cueId:element?.dataset.cueId,label:element?.textContent.trim()||'Линия'};
  e.preventDefault();phone.setPointerCapture(e.pointerId);if(element)hold=setTimeout(take,420);
 },true);
 phone.addEventListener('pointermove',e=>{
  if(!pointer||e.pointerId!==pointer.id)return;e.preventDefault();
  const dy=e.clientY-pointer.y;pointer.x=e.clientX;pointer.y=e.clientY;
  if(drag){if(Math.abs(dy)>1)drag.direction=Math.sign(dy);drag.x=e.clientX;drag.y=e.clientY;positionDrag();return;}
  if(Math.hypot(e.clientX-pointer.startX,e.clientY-pointer.startY)>8){
   if(pointer.element&&pointer.type==='mouse'){take();positionDrag();return;}
   if(hold)clearTimeout(hold);hold=null;pointer.pan=true;reader.scrollTop=pointer.top-(e.clientY-pointer.startY);
  }
 },{capture:true,passive:false});
 phone.addEventListener('pointerup',e=>{
  if(!pointer||pointer.id!==e.pointerId)return;e.preventDefault();e.stopPropagation();
  const p=pointer,d=drag,target=d?.target,valid=d?.valid;swallowUntil=performance.now()+450;
  if(d){
   cancel();if(target&&valid){
    const saved=mutate(song=>{if(d.chordId)return moveChord(song,d.chordId,target.lineId,target.column);const from=findLine(song,d.lineId),to=findLine(song,target.lineId),cue=from.cues.find(c=>c.id===d.cueId);if(!cue)return false;from.cues=from.cues.filter(c=>c.id!==cue.id);cue.column=target.column;to.cues.push(cue);});
    if(saved){selected={lineId:target.lineId,column:target.column};reveal(target.lineId,d.chordId||d.cueId);}
   }else if(target)notice('Это место занято другим аккордом.');return;
  }
  const point=!p.pan&&!p.element?locate(e.clientX,e.clientY):null;cancel();
  if(p.pan)return;
  if(p.chordId)openChord(p.chordId);else if(p.cueId)openCue(p.lineId,p.cueId);else if(point)openPosition(point.lineId,point.column);
 },true);
 phone.addEventListener('pointercancel',cancel,true);
 reader.addEventListener('touchmove',e=>{if(editing&&pointer)e.preventDefault();},{passive:false});
 window.addEventListener('pagehide',cancel);
 phone.addEventListener('contextmenu',e=>{if(editing&&e.target.closest('.qs-chord,.ke-cue,.ke-divider'))e.preventDefault();});
 phone.addEventListener('click',e=>{
  if(!editing||!overlay.hidden)return;
  if(performance.now()<swallowUntil){if(e.target.closest('.qs-reader')){e.preventDefault();e.stopImmediatePropagation();}return;}
  const chord=e.target.closest('[data-chord-id]'),cue=e.target.closest('[data-cue-id]');
  if(chord){e.preventDefault();e.stopPropagation();openChord(chord.dataset.chordId);}
  if(cue){e.preventDefault();e.stopPropagation();openCue(cue.closest('.qs-line').dataset.lineId,cue.dataset.cueId);}
 },true);
 document.addEventListener('keydown',e=>{
  if(!overlay.hidden){if(e.key==='Escape'){e.preventDefault();close();}if(e.key==='Tab'){const elements=[...overlay.querySelectorAll('button,input,select')].filter(e=>!e.disabled&&e.getClientRects().length),first=elements[0],last=elements.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}return;}
  if(editing&&(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!e.target.closest('input,textarea')){e.preventDefault();if(history.canUndo)$('.ke-undo').click();}
 });
 decorate();updateBar();icons();
 return {setEditing,openPart,syncExternal(){history=createHistory(getSong());dirty=true;updateBar();},markSaved(){dirty=false;updateBar();},markDirty(){dirty=true;updateBar();},get dirty(){return dirty;},get editing(){return editing;}};
}
