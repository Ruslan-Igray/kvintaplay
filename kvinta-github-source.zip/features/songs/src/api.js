import {SEARCH_SERVICE_ORIGIN} from './service-config.js';
export const SERVICE_ORIGIN='https://kvinta-guitar-circle.sappy-mule-8607.chatgpt.site';
const pagesHosts=new Set(['kvintaplay.ru','ruslan-igray.github.io']);
const searchRoutes=new Set(['/api/songs/search','/api/songs/artist','/api/songs/import']);
export function apiUrl(path,loc=globalThis.location){
 if(!pagesHosts.has(loc?.hostname))return path;
 const route=path.split('?',1)[0];
 if(searchRoutes.has(route)&&SEARCH_SERVICE_ORIGIN)return SEARCH_SERVICE_ORIGIN+path;
 return SERVICE_ORIGIN+path;
}
export function isKvintaSongUrl(url,loc=globalThis.location){return url.origin===loc.origin||url.origin===SERVICE_ORIGIN||['https://ruslan-igray.github.io','https://kvintaplay.ru'].includes(url.origin);}
export async function fetchSongApi(path,{fetcher=globalThis.fetch,loc=globalThis.location,timeout=24000,retries=1,method='GET',body}={}){
 for(let attempt=0;attempt<=retries;attempt++){
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),timeout);
  try{
   const response=await fetcher(apiUrl(path,loc),{method,body,credentials:'omit',cache:'no-store',referrerPolicy:'no-referrer',headers:{Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},signal:abort.signal});
   let data;try{data=await response.json();}catch{throw new Error('Поисковый сервер вернул непонятный ответ. Повторите запрос.');}
   if(!response.ok)throw Object.assign(new Error(data.error||'Сервис временно недоступен. Попробуйте позже.'),{responseStatus:response.status});return data;
  }catch(error){
   const network=error?.name==='TypeError'||error?.name==='AbortError'||error?.name==='TimeoutError';
   if(network&&method==='GET'&&attempt<retries){await new Promise(resolve=>setTimeout(resolve,300));continue;}
   if(network)throw new Error('Не удалось связаться с поисковым сервером. Проверьте интернет и повторите запрос.');throw error;
  }finally{clearTimeout(timer);}
 }
}
