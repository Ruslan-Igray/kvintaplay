import {bindLongPress} from './long-press.js';
// Keep one set of controls and listeners when switching song workspaces.
export function mountSongWorkspace({phone,editor,recording,library,player}){
 const doc=phone.ownerDocument,$=selector=>phone.querySelector(selector);
 let mode='rehearsal',track='text';
 const heading=$('.qs-song-heading'),actions=doc.createElement('div');actions.className='kw-song-actions';
 actions.setAttribute('role','group');actions.setAttribute('aria-label','Действия с песней');
 actions.append($('.ke-save'),$('.qs-save'),$('.ke-share'));heading.insertBefore(actions,$('.qs-fullscreen-exit'));
 $('.qs-save').setAttribute('title','В избранное');$('.qs-save').setAttribute('aria-label','В избранное');
 const modes=$('.ke-edit-switch'),tracksButton=doc.createElement('button');tracksButton.type='button';tracksButton.className='kw-tracks-button';tracksButton.textContent='Треки';modes.append(tracksButton);
 const pane=doc.createElement('section');pane.className='kw-tracks';pane.hidden=true;pane.setAttribute('aria-label','Треки песни');
 pane.innerHTML='<div class="kw-track-tabs" role="group" aria-label="Содержимое треков"><button type="button" data-track="text" aria-pressed="true">Текст</button><button type="button" data-track="audio" aria-pressed="false">Аудио</button></div><div class="kw-text"></div><div class="kw-audio" hidden></div>';
 $('.ke-addbar').after(pane);pane.querySelector('.kw-text').append(library);
 recording.embed(pane.querySelector('.kw-audio'),{onOpen:()=>show('tracks','audio'),onClose:()=>show('rehearsal')});
 function show(next,nextTrack=track){
  if(next===mode&&(next!=='tracks'||nextTrack===track))return true;
  if(mode==='tracks'&&track==='audio'&&!recording.leave())return false;
  player.stop();editor.setEditing(next==='editor');mode=next;track=nextTrack;phone.dataset.workspace=mode;pane.hidden=mode!=='tracks';
  library.hidden=mode!=='tracks'||track!=='text';
  pane.querySelector('.kw-text').hidden=track!=='text';pane.querySelector('.kw-audio').hidden=track!=='audio';
  for(const [selector,value]of [['.ke-view','rehearsal'],['.ke-edit','editor'],['.kw-tracks-button','tracks']])$(selector).setAttribute('aria-pressed',String(value===mode));
  pane.querySelectorAll('[data-track]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.track===track)));
  if(mode==='tracks'&&track==='audio')recording.open();
  return true;
 }
 $('.ke-view').onclick=()=>show('rehearsal');$('.ke-edit').onclick=()=>show('editor');tracksButton.onclick=()=>show('tracks');
 pane.querySelectorAll('[data-track]').forEach(button=>button.onclick=()=>show('tracks',button.dataset.track));
 const oldHelp=$('.qs-header .qs-help');if(oldHelp)oldHelp.hidden=true;
 const scrollSettings=doc.createElement('dialog');scrollSettings.className='kw-scroll-dialog';scrollSettings.setAttribute('aria-label','Прокрутка текста');
 scrollSettings.innerHTML='<header><h2>Прокрутка текста</h2><button type="button" aria-label="Закрыть прокрутку">×</button></header><p><strong>Равномерно</strong> — постоянная скорость. <strong>В такт</strong> — по темпу и длительности аккордов. С записью текст следует вашим отметкам.</p>';
 scrollSettings.append($('.qs-mode-detail'));phone.append(scrollSettings);scrollSettings.querySelector('button').onclick=()=>scrollSettings.close();
 let outsideScrollPointer=false;
 const outsideScroll=event=>{const r=scrollSettings.getBoundingClientRect();return event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom;};
 scrollSettings.addEventListener('pointerdown',event=>{outsideScrollPointer=event.target===scrollSettings&&outsideScroll(event);});
 scrollSettings.addEventListener('click',event=>{if(event.target===scrollSettings&&outsideScrollPointer&&outsideScroll(event))scrollSettings.close();outsideScrollPointer=false;});
 scrollSettings.addEventListener('close',()=>{outsideScrollPointer=false;});
 const uniform=$('[data-mode=uniform]');uniform.title='Удерживайте, чтобы настроить скорость прокрутки';uniform.setAttribute('aria-haspopup','dialog');uniform.setAttribute('aria-description','Удерживайте для настройки скорости. С клавиатуры: Shift и F10.');bindLongPress(uniform,()=>{if(!scrollSettings.open)scrollSettings.showModal();});
 const durations=doc.createElement('button');durations.type='button';durations.className='kw-durations';durations.textContent='Доли';durations.setAttribute('aria-label','Доли текущего блока');durations.onclick=()=>$('.qs-chord-timing').click();$('.qs-scroll-mode-row').append(durations);
 phone.dataset.workspace=mode;
 window.addEventListener('kvinta:finish-edit',()=>{if(mode==='editor')show('rehearsal');});
 return {show,get mode(){return mode;},get track(){return track;}};
}
