import {bindLongPress} from './long-press.js';
// Keep one set of controls and listeners when switching song workspaces.
export function mountSongWorkspace({phone,editor,library,player}){
 const doc=phone.ownerDocument,$=selector=>phone.querySelector(selector);
 let mode='rehearsal';
 const heading=$('.qs-song-heading'),actions=doc.createElement('div');actions.className='kw-song-actions';
 actions.setAttribute('role','group');actions.setAttribute('aria-label','Действия с песней');
 actions.append($('.ke-save'),$('.qs-save'),$('.ke-share'));heading.insertBefore(actions,$('.qs-fullscreen-exit'));
 $('.qs-save').setAttribute('title','В избранное');$('.qs-save').setAttribute('aria-label','В избранное');
 const modes=$('.ke-edit-switch'),tracksButton=doc.createElement('button');tracksButton.type='button';tracksButton.className='kw-tracks-button';tracksButton.textContent='Треки';modes.append(tracksButton);
 $('.ke-addbar').after(library);
 library.hidden=true;
 function show(next){
  if(next===mode)return;
  player.stop();editor.setEditing(next==='editor');mode=next;phone.dataset.workspace=mode;
  library.hidden=mode!=='tracks';
  for(const [selector,value]of [['.ke-view','rehearsal'],['.ke-edit','editor'],['.kw-tracks-button','tracks']])$(selector).setAttribute('aria-pressed',String(value===mode));
 }
 $('.ke-view').onclick=()=>show('rehearsal');$('.ke-edit').onclick=()=>show('editor');tracksButton.onclick=()=>show('tracks');
 const oldHelp=$('.qs-header .qs-help');if(oldHelp)oldHelp.hidden=true;
 const scrollSettings=doc.createElement('dialog');scrollSettings.className='kw-scroll-dialog';scrollSettings.setAttribute('aria-label','Прокрутка текста');
 scrollSettings.innerHTML='<header><h2>Прокрутка текста</h2><button type="button" aria-label="Закрыть прокрутку">×</button></header><p><strong>Равномерно</strong> — постоянная скорость. <strong>В такт</strong> — по темпу и длительности аккордов. С записью текст следует вашим отметкам.</p>';
 scrollSettings.append($('.qs-mode-detail'));phone.append(scrollSettings);scrollSettings.querySelector('button').onclick=()=>scrollSettings.close();
 let outsideScrollPointer=false;
 const outsideScroll=event=>{const r=scrollSettings.getBoundingClientRect();return event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom;};
 scrollSettings.addEventListener('pointerdown',event=>{outsideScrollPointer=event.target===scrollSettings&&outsideScroll(event);});
 scrollSettings.addEventListener('click',event=>{if(event.target===scrollSettings&&outsideScrollPointer&&outsideScroll(event))scrollSettings.close();outsideScrollPointer=false;});
 scrollSettings.addEventListener('close',()=>{outsideScrollPointer=false;});
 const uniform=$('[data-mode=uniform]');uniform.title='Удерживайте, чтобы настроить скорость прокрутки';uniform.setAttribute('aria-haspopup','dialog');uniform.setAttribute('aria-description','Удерживайте для настройки скорости. С клавиатуры: Shift и F10.');bindLongPress(uniform,()=>{if(!scrollSettings.open)scrollSettings.showModal();});
 const durations=doc.createElement('button');durations.type='button';durations.className='kw-durations';durations.textContent='Доли';durations.setAttribute('aria-label','Доли текущего блока');durations.onclick=()=>$('.qs-chord-timing').click();$('.qs-scroll-mode-row').append(durations);
 phone.dataset.workspace=mode;
 window.addEventListener('kvinta:finish-edit',()=>{if(mode==='editor')show('rehearsal');});
 return {show,get mode(){return mode;}};
}
