// The first two visual rows stay visible, remaining requests go under disclosure.
export function mountSearchHistory({host,queries,onSelect,onClear}){
 const doc=host.ownerDocument,win=doc.defaultView;host.replaceChildren();if(!queries.length)return {destroy(){}};
 const heading=doc.createElement('div');heading.className='kl-history-heading';const title=doc.createElement('span');title.textContent='Недавно искали';const clear=doc.createElement('button');clear.type='button';clear.textContent='Очистить';clear.onclick=onClear;heading.append(title,clear);
 const first=doc.createElement('div');first.className='kh-links';const more=doc.createElement('details');more.className='kh-more';more.hidden=true;const summary=doc.createElement('summary'),rest=doc.createElement('div');rest.className='kh-links';more.append(summary,rest);
 const links=queries.slice(0,10).map(query=>{const a=doc.createElement('a');a.href='?q='+encodeURIComponent(query);a.textContent=query;a.title=query;a.onclick=event=>{if(event.button||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;event.preventDefault();onSelect(query);};return a;});
 host.append(heading,first,more);let width=0,frame=0,destroyed=false;
 function arrange(){frame=0;if(destroyed||!host.clientWidth)return;first.append(...links);more.hidden=true;
  const tops=[];let split=links.length;for(let i=0;i<links.length;i++){const top=links[i].offsetTop;if(!tops.some(t=>Math.abs(t-top)<2))tops.push(top);if(tops.length>2){split=i;break;}}
  if(split<links.length){rest.append(...links.slice(split));summary.textContent='Ещё запросы · '+(links.length-split);more.hidden=false;}
 }
 const resize=new win.ResizeObserver(()=>{if(host.clientWidth!==width){width=host.clientWidth;win.cancelAnimationFrame(frame);frame=win.requestAnimationFrame(arrange);}});resize.observe(host);frame=win.requestAnimationFrame(arrange);
 return {destroy(){destroyed=true;resize.disconnect();win.cancelAnimationFrame(frame);}};
}
