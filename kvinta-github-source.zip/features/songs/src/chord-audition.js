import {ROOTS,voicingsFor,soundingNotes} from '../modules/guitar.js';
import {pitchClass,mod} from '../modules/theory.js';

const qualities={
 '':{type:'major',intervals:[0,4,7]},m:{type:'minor',intervals:[0,3,7]},
 '7':{type:'7',intervals:[0,4,7,10]},maj7:{type:'maj7',intervals:[0,4,7,11]},m7:{type:'m7',intervals:[0,3,7,10]},
 sus2:{type:'sus2',intervals:[0,2,7]},sus4:{type:'sus4',intervals:[0,5,7]},
 '5':{intervals:[0,7,12]},dim:{type:'dim',intervals:[0,3,6]},aug:{intervals:[0,4,8]},
 add9:{intervals:[0,4,7,14]},'9':{intervals:[0,4,7,10,14]},m7b5:{intervals:[0,3,6,10]},
};
export function songChordNotes(symbol){
 const match=String(symbol).replaceAll('♯','#').replaceAll('♭','b').replaceAll('H','B').match(/^([A-G][#b]{0,2})([^/]*)(?:\/([A-G][#b]?))?$/);
 if(!match)return [];
 if(!Object.hasOwn(qualities,match[2]))return [];const quality=qualities[match[2]];
 const root=pitchClass(match[1]),shape=quality.type?voicingsFor(ROOTS[root],quality.type)[0]:null;
 let notes=shape?soundingNotes(shape):quality.intervals.map(interval=>48+root+interval);
 if(!shape)notes=[...notes,...Array(6-notes.length).fill(null)];
 if(match[3]){notes=notes.slice();const first=notes.findIndex(n=>n!==null);notes[first]-=mod(notes[first]-pitchClass(match[3]));}
 return notes;
}
