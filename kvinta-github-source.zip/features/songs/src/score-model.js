import {isChord} from './song-model.js';
export const SONG_METERS=[{id:'2/4',beats:2,unit:'♩'},{id:'3/4',beats:3,unit:'♩'},{id:'4/4',beats:4,unit:'♩'},{id:'5/4',beats:5,unit:'♩'},{id:'7/4',beats:7,unit:'♩'},{id:'3/8',beats:3,unit:'♪'},{id:'5/8',beats:5,unit:'♪'},{id:'6/8',beats:2,unit:'♩.'},{id:'7/8',beats:7,unit:'♪'},{id:'9/8',beats:3,unit:'♩.'},{id:'12/8',beats:4,unit:'♩.'}];
export const songMeter=id=>SONG_METERS.find(m=>m.id===id)||SONG_METERS[2];
export function normalizeRecording(value,parts){
 if(!value||typeof value!=='object')return null;
 const duration=Number(value.duration);if(!Number.isFinite(duration)||duration<.1||duration>14400)return null;
 const lines=parts.flatMap(p=>p.lines),times=new Map((Array.isArray(value.times)?value.times:[]).slice(0,400).filter(v=>v&&typeof v.lineId==='string'&&Number.isFinite(v.at)&&v.at>=0&&v.at<duration).map(v=>[v.lineId,Math.min(duration-.001,Math.round(v.at*1000)/1000)]));
 let previous=-1;const out=[];for(const line of lines){const at=times.get(line.id);if(at!==undefined&&at>previous){out.push({lineId:line.id,at});previous=at;}}
 const chordMap=new Map((Array.isArray(value.chordTimes)?value.chordTimes:[]).slice(0,5000).filter(t=>t&&typeof t.chordId==='string'&&Number.isFinite(t.at)&&Number.isFinite(t.endAt)&&t.at>=0&&t.endAt<=duration&&t.endAt-t.at>=.08).map(t=>[t.chordId,t]));
 const chordTimes=[];let end=-1;
 for(const chord of lines.flatMap(l=>l.chords)){
  const t=chordMap.get(chord.id);if(!t||t.at<end)continue;
  const at=Math.round(t.at*1000)/1000,endAt=Math.min(duration,Math.round(t.endAt*1000)/1000);
  if(endAt-at<.08)continue;chordTimes.push({chordId:chord.id,at,endAt});end=endAt;
 }
 return {localId:typeof value.localId==='string'&&/^[a-zA-Z0-9_-]{1,100}$/.test(value.localId)?value.localId:null,name:typeof value.name==='string'?value.name.slice(0,180):'Запись',duration,referenceBpm:Number.isFinite(value.referenceBpm)&&value.referenceBpm>=40&&value.referenceBpm<=220?value.referenceBpm:120,enabled:value.enabled===true,times:out,...(value.tempoVerified===true?{tempoVerified:true}:{}),...(chordTimes.length?{chordTimes}:{})};
}
export const CUE_PRESETS=[
 {id:'pedal-on',icon:'footprints',label:'Педаль'},{id:'pedal-off',icon:'footprints',label:'Байпас'},
 {id:'clean',icon:'guitar',label:'Чистый'},{id:'drive',icon:'audio-lines',label:'Перегруз'},
 {id:'pause',icon:'pause',label:'Пауза'},{id:'bass',icon:'guitar',label:'Бас'},
 {id:'drums',icon:'drum',label:'Ударные'},{id:'solo',icon:'music-2',label:'Соло'},
 {id:'effect',icon:'sliders-horizontal',label:'Эффект'},{id:'custom',icon:'flag',label:'Своя'}
];
const oldCueLabels={'Педаль вкл.':'Педаль','Педаль выкл.':'Байпас','Чистый звук':'Чистый','Пауза всем':'Пауза','Вступает бас':'Бас','Своя метка':'Своя'};
export function cueLabel(label){return Object.hasOwn(oldCueLabels,label)?oldCueLabels[label]:label;}
export const COLORS=['amber','teal','blue','purple','rose','red'];
const clone=value=>JSON.parse(JSON.stringify(value));
const id=()=>crypto.randomUUID();
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const safeId=value=>typeof value==='string'&&/^[a-zA-Z0-9_:-]{1,100}$/.test(value)?value:id();
export const linesOf=song=>song.parts.flatMap(p=>p.lines);
export function lineBeats(line){return line.chords.length?line.chords.reduce((n,c)=>n+c.beats,0):line.beats;}
export const partBeats=part=>part.lines.reduce((n,l)=>n+lineBeats(l),0);
export const songBeats=song=>song.parts.reduce((n,p)=>n+partBeats(p),0);
export function allocate(total,values){
 const count=values.length;if(!count)return [];
 total=Math.max(count/2,Math.round(total*2)/2);
 const units=Math.round(total*2),sum=values.reduce((n,v)=>n+Math.max(.5,v),0);
 const exact=values.map(v=>units*Math.max(.5,v)/sum),out=exact.map(v=>Math.max(1,Math.floor(v)));
 let difference=units-out.reduce((a,b)=>a+b,0);
 while(difference!==0){let best=-1,score=-Infinity;for(let i=0;i<count;i++){if(difference<0&&out[i]<=1)continue;const weight=difference>0?exact[i]-out[i]:out[i]-exact[i];if(weight>score){score=weight;best=i;}}if(best<0)break;out[best]+=difference>0?1:-1;difference+=difference>0?-1:1;}
 return out.map(v=>v/2);
}
export function normalizeSong(input){
 if(!input||![1,2].includes(input.schema)||typeof input.title!=='string'||!input.title.trim()||!Array.isArray(input.parts)||!input.parts.length||input.parts.length>100)throw Error('Неверный формат композиции.');
 const ids=new Set();const unique=value=>{let result=safeId(value);if(ids.has(result))result=id();ids.add(result);return result;};
 let count=0,chars=0,chordCount=0;
 const legacy=input.rehearsal||{},defaultBeats=songMeter(legacy.meter).beats;
 const parts=input.parts.map((p,pi)=>{
  if(!p||!Array.isArray(p.lines)||!p.lines.length||typeof p.name!=='string')throw Error('Не удалось прочитать блок композиции.');
  const lines=p.lines.map(l=>{
   const index=count++;if(count>400||typeof l?.text!=='string'||l.text.length>5000||!Array.isArray(l.chords)||l.chords.length>64)throw Error('Композиция слишком большая или повреждена.');
   chars+=l.text.length;if(chars>100000)throw Error('В композиции больше 100 000 знаков.');
   const oldTotal=[1,2,3,4].includes(legacy.bars?.[index])?legacy.bars[index]*defaultBeats:defaultBeats*2;
   const oldValues=legacy.weights?.[index];
   const fallback=allocate(Math.max(oldTotal,l.chords.length/2),Array(l.chords.length).fill(1));
   const chords=l.chords.map((c,i)=>{
    if(!c||typeof c.symbol!=='string'||!isChord(c.symbol)||!Number.isInteger(c.column)||c.column<0||c.column>5000)throw Error('Не удалось прочитать аккорд.');
    chordCount++;if(chordCount>5000)throw Error('В композиции слишком много аккордов.');
    const beats=finite(c.beats,.5,8192)?Math.round(c.beats*2)/2:finite(oldValues?.[i],.5,8192)?Math.round(oldValues[i]*2)/2:fallback[i];
    return {id:unique(c.id),symbol:c.symbol,column:c.column,beats,...(COLORS.includes(c.color)?{color:c.color}:{})};
   }).sort((a,b)=>a.column-b.column);
   const cues=(Array.isArray(l.cues)?l.cues:[]).slice(0,16).map(c=>({id:unique(c.id),type:c.type==='line'?'line':'cue',preset:CUE_PRESETS.some(p=>p.id===c.preset)?c.preset:'custom',label:typeof c.label==='string'?cueLabel(c.label).slice(0,50):'',color:COLORS.includes(c.color)?c.color:'amber',...(Number.isInteger(c.column)&&c.column>0&&c.column<=5000?{column:c.column}:{})}));
   return {id:unique(l.id),text:l.text,chords,beats:finite(l.beats,.5,8192)?Math.round(l.beats*2)/2:oldTotal,cues,...(l.kind==='tab'?{kind:'tab'}:{})};
  });
  return {id:unique(p.id),name:p.name.slice(0,80)||'Блок '+(pi+1),lines};
 });
 let source=null;
 if(input.source?.url){try{const u=new URL(input.source.url);if(u.protocol==='https:'&&!u.username&&!u.password&&(/^(?:(?:897|1368|www)\.)?amdm\.ru$/.test(u.hostname)||/^(?:www\.)?mytabs\.ru$/.test(u.hostname)))source={name:u.hostname.includes('mytabs')?'MyTabs':'AmDm',url:u.href};}catch{}}
 const first=parts.flatMap(p=>p.lines).flatMap(l=>l.chords)[0]?.symbol||'Am';
 return {schema:2,id:safeId(input.id),title:input.title.trim().slice(0,180),artist:typeof input.artist==='string'?input.artist.slice(0,180):'',source,parts,baseChord:typeof input.baseChord==='string'&&isChord(input.baseChord)?input.baseChord:first,recording:normalizeRecording(input.recording,parts),rehearsal:normalizeRehearsal(input.rehearsal),updatedAt:finite(input.updatedAt,0,1e14)?input.updatedAt:Date.now()};
}
export function normalizeRehearsal(value={}){
 return {meter:songMeter(value.meter).id,bpm:finite(value.bpm,40,220)?Math.round(value.bpm):120,key:finite(value.key,0,11)?Math.round(value.key):null,mode:value.mode==='tempo'?'tempo':'uniform',speed:finite(value.speed,.5,2)?value.speed:1,fontSize:finite(value.fontSize,10,28)?value.fontSize:22,line:finite(value.line,0,399)?Math.round(value.line):0,clicks:!!value.clicks,countIn:!!value.countIn,screenBlink:!!value.screenBlink,torch:!!value.torch,fullStart:!!value.fullStart,fullBeatDots:!!value.fullBeatDots,highlightLines:!!value.highlightLines,highlightChords:!!value.highlightChords};
}
export function findLine(song,lineId){return linesOf(song).find(l=>l.id===lineId);}
export function findChord(song,chordId){for(const part of song.parts)for(const line of part.lines){const chord=line.chords.find(c=>c.id===chordId);if(chord)return {part,line,chord};}return null;}
export const chordWidth=symbol=>Math.max(3,Array.from(symbol).length)+1;
export function canPlaceChord(line,column,symbol,excludeId=null){
 if(!Number.isInteger(column)||column<0||column>5000)return false;
 const end=column+chordWidth(symbol);return line.chords.every(c=>c.id===excludeId||end<=c.column||column>=c.column+chordWidth(c.symbol));
}
export function nextFreeChordColumn(line,preferred=0,symbol='Am',excludeId=null){
 const words=[...line.text.matchAll(/\S+/g)].map(m=>m.index),free=col=>canPlaceChord(line,col,symbol,excludeId),closest=values=>values.filter(free).sort((a,b)=>Math.abs(a-preferred)-Math.abs(b-preferred)||b-a)[0];
 return closest(words)??closest([preferred,0,...line.chords.filter(c=>c.id!==excludeId).map(c=>c.column+chordWidth(c.symbol))])??null;
}
export function moveChord(song,chordId,lineId,column){
 const found=findChord(song,chordId),target=findLine(song,lineId);if(!found||!target)return false;
 const at=Math.max(0,Math.min(5000,Math.round(column)));
 if(!canPlaceChord(target,at,found.chord.symbol,chordId))return false;
 found.line.chords=found.line.chords.filter(c=>c.id!==chordId);found.chord.column=at;target.chords.push(found.chord);target.chords.sort((a,b)=>a.column-b.column);return true;
}
export function addChord(song,lineId,column,symbol='Am',beats=4){const line=findLine(song,lineId);if(!line||!isChord(symbol)||line.chords.length>=64)throw Error('Не удалось добавить аккорд.');const chord={id:id(),symbol,column:Math.max(0,Math.min(5000,Math.round(column))),beats:Math.max(.5,Math.min(8192,Math.round(beats*2)/2))};if(!canPlaceChord(line,chord.column,symbol))throw Error('Это место занято другим аккордом. Выберите свободное место в строке.');line.chords.push(chord);line.chords.sort((a,b)=>a.column-b.column);return chord;}
export function setPartBeats(part,total){
 const refs=[];for(const line of part.lines){if(line.chords.length)for(const c of line.chords)refs.push(c);else refs.push(line);}
 const values=allocate(total,refs.map(r=>r.beats));refs.forEach((r,i)=>r.beats=values[i]);return values.reduce((a,b)=>a+b,0);
}
export function splitPart(song,lineId,name){
 const pi=song.parts.findIndex(p=>p.lines.some(l=>l.id===lineId));if(pi<0)return false;const p=song.parts[pi],at=p.lines.findIndex(l=>l.id===lineId);
 if(!at){p.name=name;return true;}const next={id:id(),name,lines:p.lines.splice(at)};song.parts.splice(pi+1,0,next);return true;
}
export function snapshot(song,prefs){const result=normalizeSong({...clone(song),rehearsal:{...song.rehearsal,...prefs}});return result;}
export function createHistory(song,limit=40){
 let present=clone(song),undo=[],redo=[];
 return {get value(){return present;},get canUndo(){return !!undo.length;},get canRedo(){return !!redo.length;},commit(next){undo.push(clone(present));if(undo.length>limit)undo.shift();present=clone(next);redo=[];return present;},undo(){if(!undo.length)return present;redo.push(present);present=undo.pop();return clone(present);},redo(){if(!redo.length)return present;undo.push(present);present=redo.pop();return clone(present);}};
}
