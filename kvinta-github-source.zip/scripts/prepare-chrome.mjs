import fs from 'node:fs';
import {startupTarget} from '../dist/modules/startup-state.js';
import {appHeaderMarkup} from '../dist/modules/app-chrome.js';
function prepare(path,mode){
 let html=fs.readFileSync(path,'utf8');const release=JSON.parse(fs.readFileSync('package.json','utf8')).version;html=html.replace(/(<span>Квинта\. · )\d+\.\d+\.\d+(<\/span>)/g,'$1'+release+'$2');
 html=html.replace(/<script id="kvinta-startup-route">[\s\S]*?<\/script>/g,'');
 if(mode==='tools')html=html.replace('<head>','<head><script id="kvinta-startup-route">(()=>{try{const preferences=JSON.parse(localStorage.getItem("kvinta.preferences.v1")||"{}");const target=('+startupTarget.toString()+')({lastWorkspace:preferences?.lastWorkspace,pathname:location.pathname,search:location.search,hash:location.hash,base:new URL("./",location.href).href});if(target){document.documentElement.dataset.modeRedirect="true";location.replace(target);}}catch{}})();</script>');
 html=html.replace(/<body(?: class="[^"]*")?>/,'<body class="kv-app-body">');
 html=html.replace(/<link rel="stylesheet" href="(?:\.\/|\.\.\/)?app-chrome\.css">/g,'');
 html=html.replace(/<link rel="stylesheet" href="(?:\.\/|\.\.\/)?release-notice\.css">/g,'');
 html=html.replace(/<link rel="stylesheet" href="(?:\.\/|\.\.\/)?visual-rhythm\.css">/g,'');
 html=html.replace('</head>','<link rel="stylesheet" href="'+(mode==='song'?'../':'./')+'visual-rhythm.css"></head>');
 html=html.replace('</head>','<link rel="stylesheet" href="'+(mode==='song'?'../':'./')+'release-notice.css"></head>');
 html=html.replace(/<script id="kvinta-mode-nav">[\s\S]*?<\/script>/g,'');
 html=html.replace('</head>','<script id="kvinta-mode-nav">'+fs.readFileSync('dist/modules/app-nav.js','utf8')+'</script></head>');
 html=html.replace('</head>','<link rel="stylesheet" href="'+(mode==='song'?'../':'./')+'app-chrome.css"></head>');
 html=html.replace(/<link rel="stylesheet" href="(?:\.\/|\.\.\/)?modules\/rhythm-test\.css" data-rhythm-test(?:="true")?>/g,'');
 html=html.replace(/<link rel="stylesheet" href="(?:\.\/|\.\.\/)?modules\/rhythm-achievements\.css" data-achievement-styles(?:="true")?>/g,'');
 html=html.replace('</head>','<link rel="stylesheet" href="'+(mode==='song'?'../':'./')+'modules/rhythm-test.css" data-rhythm-test="true"><link rel="stylesheet" href="'+(mode==='song'?'../':'./')+'modules/rhythm-achievements.css" data-achievement-styles="true"></head>');
 if(mode==='tools')html=html.replace(/class="app(?: kv-app-frame)?"/,'class="app kv-app-frame"').replace(/<header class="(?:kv-chrome )?topbar">[\s\S]*?<\/header>/,appHeaderMarkup(mode));
 else html=html.replace(/<div class="qs-phone(?: kv-app-frame)?"([\s\S]*?)>[\s\S]*?<\/div><\/div><\/section>/,'<div class="qs-phone kv-app-frame"$1>'+appHeaderMarkup(mode)+'</div></div></section>');
 fs.writeFileSync(path,html);
}
prepare('dist/index.html','tools');prepare('features/songs/src/index.html','song');
