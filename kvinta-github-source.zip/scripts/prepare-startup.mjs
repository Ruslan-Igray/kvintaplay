import {build} from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const modules=path.join(root,'dist/modules');
const screens=[
 {name:'tools',entry:'dist/app.js',html:'dist/index.html',src:'./modules/'},
 {name:'songs',entry:'dist/songs/library.js',html:'dist/songs/index.html',src:'../modules/'},
 {name:'tests',entry:'dist/tests/tests-page.js',html:'dist/tests/index.html',src:'../modules/'},
];
// Keep chunks beside the original modules that resolve CSS, badges and audio via import.meta.url.
const result=await build({
 absWorkingDir:root,
 entryPoints:Object.fromEntries(screens.map(screen=>[screen.name,screen.entry])),
 outdir:modules,entryNames:'boot-[name]',chunkNames:'boot-chunk-[hash]',
 bundle:true,splitting:true,format:'esm',target:'es2022',platform:'browser',
 minify:true,charset:'utf8',legalComments:'inline',metafile:true,
});
const outputs=new Set(Object.keys(result.metafile.outputs).map(file=>path.resolve(root,file)));
const bundledInputs=Object.keys(result.metafile.inputs).filter(file=>file.startsWith('dist/')).map(file=>'./'+file.slice(5)).sort();
await fs.writeFile(path.join(root,'dist/.bundled-inputs.json'),JSON.stringify(bundledInputs));
for(const name of await fs.readdir(modules)){
 if(/^boot-chunk-[A-Z0-9]{8}\.js$/.test(name)&&!outputs.has(path.join(modules,name)))await fs.unlink(path.join(modules,name));
}
for(const screen of screens){
 const file=path.join(root,screen.html),html=await fs.readFile(file,'utf8');
 const script=/<script type="module" src="[^"]+"><\/script>/g;
 if([...html.matchAll(script)].length!==1)throw Error('Unexpected entry script in '+screen.html);
 await fs.writeFile(file,html.replace(script,'<script type="module" src="'+screen.src+'boot-'+screen.name+'.js"></script>'));
}
