import {DatabaseSync} from 'node:sqlite';import fs from 'node:fs';import path from 'node:path';
export function localD1(filename=':memory:',migrationDirectory=new URL('../drizzle/',import.meta.url)){
 const sqlite=new DatabaseSync(filename);sqlite.exec('PRAGMA foreign_keys=ON');sqlite.exec('CREATE TABLE IF NOT EXISTS _local_migrations(name TEXT PRIMARY KEY)');
 for(const name of fs.readdirSync(migrationDirectory).filter(n=>n.endsWith('.sql')).sort())if(!sqlite.prepare('SELECT name FROM _local_migrations WHERE name=?').get(name)){sqlite.exec(fs.readFileSync(new URL(name,migrationDirectory),'utf8'));sqlite.prepare('INSERT INTO _local_migrations VALUES(?)').run(name);}
 function prepare(sql){let args=[];return {sql,get args(){return args;},bind(...values){args=values;return this;},async first(column){const row=sqlite.prepare(sql).get(...args);return column?row?.[column]:row||null;},async all(){return {results:sqlite.prepare(sql).all(...args)};},async run(){const result=sqlite.prepare(sql).run(...args);return {meta:{changes:Number(result.changes)}};}};}
 return {prepare,async batch(statements){sqlite.exec('BEGIN');try{const result=[];for(const s of statements)result.push(await s.run());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}},close:()=>sqlite.close(),sqlite};
}
