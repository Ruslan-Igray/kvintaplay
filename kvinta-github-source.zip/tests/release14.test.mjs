import test from 'node:test';
import assert from 'node:assert/strict';
import {createPitchTracker,normalizeTuner,frequencyFor} from '../dist/modules/tuner-pitch.js';
import {createTuningSequence} from '../dist/modules/tuner-sequence.js';
import {stringsFor} from '../dist/modules/tuner-tunings.js';
import {tipMarkup,freshMusicTip} from '../dist/modules/tip-format.js';
import {MUSIC_TIPS} from '../dist/modules/music-tips.js';
import {swipeState,setupSwipeDelete} from '../dist/modules/swipe-delete.js';
import {rehearsalNotes,createRehearsalChords} from '../dist/modules/rehearsal-chords.js';
import {createMetronomeEngine} from '../dist/modules/metronome-engine.js';
import {createRehearsalTransport} from '../dist/modules/rehearsal-transport.js';
import {makeRehearsalPlan,rehearsalFrame} from '../dist/modules/rehearsal-model.js';
import {newSet,addSetChord,transposeSet,SET_TYPES} from '../dist/modules/composition-model.js';
import {pitchClass} from '../dist/modules/theory.js';
const measure=cents=>({frequency:frequencyFor(40)*2**(cents/1200),clarity:.99,rms:.015,clipped:false});

test('Normal tuning accepts a steady six-cent deviation; precision still requires closer tuning',()=>{
 for(const response of ['normal','precise']){const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response});let model;for(let t=0;t<=600;t+=40)model=tracker.update(measure(6),t,settings);assert.equal(model.tuned,response==='normal');assert.equal(model.stable,response==='normal');assert.ok(Math.abs(model.cents-6)<.01);}
 assert.equal(normalizeTuner({}).response,'normal');assert.equal(normalizeTuner({response:'precise'}).response,'precise');assert.equal(normalizeTuner({response:'unsafe'}).response,'normal');
});
test('Normal needle smooths short fluctuations more strongly while neither mode labels a large error tuned',()=>{
 const models={};for(const response of ['normal','precise']){const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response}),out=[];for(let i=0;i<70;i++){const cents=20+Math.sin(i*1.3)*7,model=tracker.update(measure(cents),i*40,settings);if(i>20){out.push(model.cents);assert.equal(model.tuned,false);}}models[response]=Math.max(...out)-Math.min(...out);}
 assert.ok(models.normal<models.precise*.7,JSON.stringify(models));
});
test('Normal mode completes an auto string after sustained near-centre jitter, without green on attack, silence or a large detune',()=>{
 const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response:'normal'}),sequence=createTuningSequence(),strings=stringsFor(settings);let event=null,model;
 for(let i=0;i<36;i++){const measurement=measure(6*Math.sin(i*1.6));model=tracker.update(measurement,i*40,settings);if(i<3)assert.ok(!model?.tuned);event=sequence.update(model,measurement,i*40,strings)||event;}
 assert.equal(event.completed,6);assert.equal(event.next,5);assert.equal(tracker.update({frequency:null},1500,settings),null);
 model=tracker.update(measure(45),1540,settings);assert.equal(model?.tuned,false);
});
test('Tips format symbols and emphasis safely, retain paragraphs, and avoid repeating recent cards',()=>{
 const html=tipMarkup('**○ — открытая.**\n\n× — молчит. <script>bad</script>');assert.match(html,/tip-open/);assert.match(html,/tip-muted/);assert.match(html,/<strong>/);assert.equal((html.match(/<p>/g)||[]).length,2);assert.ok(!html.includes('<script>'));
 const data=new Map(),storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)},seen=[];for(let i=0;i<9;i++)seen.push(freshMusicTip({random:()=>0,storage})[0]);assert.equal(new Set(seen).size,9);
 for(const [,body] of MUSIC_TIPS){assert.match(body,/\*\*/);assert.ok(!tipMarkup(body).includes('<a '));}
});
function swipeHarness(){
 let deletes=0;const classes=new Set();function element(){return {style:{},children:[],attrs:{},events:{},append(...x){this.children.push(...x);},prepend(x){this.children.unshift(x);},setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,fn){(this.events[k]??=[]).push(fn);},classList:{toggle(k,on){on?classes.add(k):classes.delete(k);}}};}
 const doc={createElement:element},row=element(),content=element();row.ownerDocument=doc;row.getBoundingClientRect=()=>({width:328});row.setPointerCapture=()=>{};
 const controller=setupSwipeDelete({row,content,onDelete:()=>deletes++});const fire=(type,x,y=0)=>{const e={button:0,pointerId:1,clientX:x,clientY:y,target:{closest:()=>null},preventDefault(){},stopImmediatePropagation(){this.suppressed=true;}};for(const fn of row.events[type]||[])fn(e);return e;};
 return {row,content,controller,fire,classes,get deletes(){return deletes;}};
}
test('Swipe reveals delete first, commits only past the threshold, and cancels without deleting',()=>{
 const f=swipeHarness();f.fire('pointerdown',300);f.fire('pointermove',230);f.fire('pointerup',230);assert.equal(f.deletes,0);assert.equal(f.content.style.transform,'translateX(-92px)');assert.equal(f.fire('click',230).suppressed,true);
 f.controller.cancel();f.fire('pointerdown',300);f.fire('pointermove',70);assert.ok(f.classes.has('swipe-armed'));f.fire('pointercancel',70);assert.equal(f.deletes,0);assert.equal(f.content.style.transform,'translateX(0px)');
 f.fire('pointerdown',300);f.fire('pointermove',70);f.fire('pointerup',70);assert.equal(f.deletes,1);
});
test('Vertical scroll, dragging back and tapping the delete label never delete a favorite',()=>{
 const f=swipeHarness();f.fire('pointerdown',300);f.fire('pointermove',290,80);f.fire('pointerup',20,80);assert.equal(f.deletes,0);
 f.fire('pointerdown',300);f.fire('pointermove',50);f.fire('pointermove',295);f.fire('pointerup',295);assert.equal(f.deletes,0);assert.equal(swipeState(5,328).open,false);
 assert.equal(f.row.children[0].children.length,1);assert.equal(f.row.children[0].children[0].events.click,undefined);assert.equal(f.deletes,0);
});
test('Touch capture transfer from the pressed child does not cancel a swipe; losing row capture does',()=>{
 const f=swipeHarness();f.fire('pointerdown',300);f.fire('pointermove',250);
 for(const fn of f.row.events.lostpointercapture)fn({target:f.content,pointerId:1});
 f.fire('pointermove',190);assert.equal(f.content.style.transform,'translateX(-110px)');f.fire('pointerup',190);assert.equal(f.content.style.transform,'translateX(-92px)');assert.equal(f.deletes,0);
 f.fire('pointerdown',300);f.fire('pointermove',200);for(const fn of f.row.events.lostpointercapture)fn({target:f.row,pointerId:1});assert.equal(f.content.style.transform,'translateX(0px)');f.fire('pointerup',30);assert.equal(f.deletes,0);
});
test('Rehearsal voicings cover every set chord quality, enharmonic spelling and slash bass',()=>{
 for(const root of ['C','F#','Bb','Bbb'])for(const type of SET_TYPES){const notes=rehearsalNotes({root,type:type.id});assert.equal(notes.length,6);assert.ok(notes.some(n=>n!==null));assert.equal(notes.find(n=>n!==null)%12,pitchClass(root));}
 const notes=rehearsalNotes({root:'C',type:'major',bass:'E'});assert.equal(Math.min(...notes.filter(n=>n!==null))%12,4);
 const power=rehearsalNotes({root:'D',type:'5'});assert.deepEqual([...new Set(power.filter(n=>n!==null).map(n=>n%12))],[2,9]);
});
function fakeAudio(){const sources=[],gains=[];const ctx={state:'running',currentTime:0,sampleRate:8000,destination:{},createGain(){const g={gain:{setValueAtTime(v,t){g.initial=[v,t];},setTargetAtTime(v,t){g.fade=[v,t];}},connect(){},disconnect(){g.disconnected=true;}};gains.push(g);return g;},createBuffer(c,n){const samples=new Float32Array(n);return {getChannelData:()=>samples};},createBufferSource(){const s={connect(){},disconnect(){this.disconnected=true;},start(t){this.startAt=t;},stop(t){this.stopAt=t;}};sources.push(s);return s;}};return {ctx,sources,gains};}
test('Chord strums follow exact beat boundaries and stop at their duration on the same audio clock',async()=>{
 let set=addSetChord(newSet(),{root:'C',type:'major',beats:2});set=addSetChord(set,{root:'G',type:'7',beats:1});const plan=makeRehearsalPlan(set),renderer=createRehearsalChords(),fake=fakeAudio();await renderer.prepare(plan,fake.ctx);
 renderer.schedule(rehearsalFrame(plan,0),{time:1,duration:.5},{context:fake.ctx,output:{},track(){}});assert.equal(fake.sources[0].startAt,1);assert.equal(fake.sources.at(-1).startAt,1.1);assert.ok(fake.sources.every(s=>s.stopAt===2));
 const count=fake.sources.length;renderer.schedule(rehearsalFrame(plan,1),{time:1.5,duration:.5},{context:fake.ctx,output:{},track(){}});assert.equal(fake.sources.length,count);
 renderer.schedule(rehearsalFrame(plan,2),{time:2,duration:.5},{context:fake.ctx,output:{},track(){}});assert.equal(fake.sources[count].startAt,2);assert.ok(fake.sources.slice(count).every(s=>s.stopAt===2.5));renderer.stop();assert.ok(fake.gains.every(g=>g.disconnected));
});
test('Audio preparation finishes before the first beat; Stop cancels scheduled chord nodes too',async()=>{
 const fake=fakeAudio(),tracked=[];const engine=createMetronomeEngine({getSettings:()=>({bpm:120}),audioContextFactory:()=>fake.ctx,setTimer:()=>1,clearTimer(){},onPrepare:async()=>{fake.ctx.currentTime=2;},onSchedule:(event,audio)=>{const s=fake.ctx.createBufferSource();audio.track(s);s.start(event.time);tracked.push(s);}});
 await engine.start();assert.equal(fake.sources[0].startAt,2.04);assert.equal(tracked[0].startAt,2.04);engine.stop();assert.ok(tracked.every(s=>s.disconnected));
});
test('Transport schedules all composition parts and loop boundaries, with a switch for guitar sound',async()=>{
 let set=addSetChord(newSet(),{root:'C',type:'major',beats:2});set=addSetChord(set,{root:'G',type:'major',beats:1});let callbacks;const calls=[],renderer={prepare(plan){calls.push(['prepare',plan.total]);},schedule(frame,event){calls.push(['strum',frame.index,event.ordinal]);},stop(){calls.push(['stop']);}};
 const transport=createRehearsalTransport({getSet:()=>set,getChordSound:()=>true,chordRenderer:renderer,requestFrame:()=>1,cancelFrame(){},now:()=>0,engineFactory:c=>{callbacks=c;return {async start(){await c.onPrepare({});for(const ordinal of [0,1,2,3])if(c.shouldSound({ordinal,part:0}))c.onSchedule({ordinal,part:0},{});return true;},stop(){c.onStop();},drain:()=>[]};}});
 await transport.start();assert.ok(calls.some(c=>c[0]==='prepare'&&c[1]===3));assert.ok(calls.some(c=>c[0]==='strum'&&c[1]===1&&c[2]===2));assert.ok(calls.some(c=>c[0]==='strum'&&c[1]===0&&c[2]===3));transport.stop();assert.equal(calls.at(-1)[0],'stop');
});

test('Stop during guitar buffer preparation cannot revive the scheduler',async()=>{
 const fake=fakeAudio();let finish,prepared=false,timers=0;const engine=createMetronomeEngine({getSettings:()=>({bpm:120}),audioContextFactory:()=>fake.ctx,setTimer:()=>{timers++;return 1;},clearTimer(){},onPrepare:()=>{prepared=true;return new Promise(resolve=>{finish=resolve;});}});
 const pending=engine.start();for(let i=0;i<4&&!prepared;i++)await Promise.resolve();assert.equal(prepared,true);engine.stop();finish();assert.equal(await pending,false);assert.equal(fake.sources.length,0);assert.equal(timers,0);
});
