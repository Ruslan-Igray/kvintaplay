import test from 'node:test';
import assert from 'node:assert/strict';
import { newSet,addSetChord,dropSetChord,setChordName,MAX_SET_CHORDS } from '../dist/modules/composition-model.js';
import { dropTargetAt,setupChordDrag } from '../dist/modules/composition-drag.js';

function song(){let set=newSet();for(const [root,type] of [['C','major'],['G','major'],['A','minor'],['F','major']])set=addSetChord(set,{root,type});return set;}
const names=set=>set.chords.map(c=>setChordName(c));
test('Palette centre drop replaces only its target, preserving occurrence identity and the original draft',()=>{
  const set=song(),before=JSON.stringify(set),result=dropSetChord(set,{chord:{root:'D',type:'7',bass:'F#'}},{kind:'replace',index:1});
  assert.deepEqual(names(result.set),['C','D7/F#','Am','F']);assert.equal(result.action,'replace');assert.equal(result.selectedId,set.chords[1].id);assert.equal(JSON.stringify(set),before);
  assert.deepEqual(result.set.chords.map(c=>c.id),set.chords.map(c=>c.id));
});
test('Palette edge drops insert a fresh repeated occurrence at start, middle and end',()=>{
  const set=song();for(const index of [0,2,4]){
    const result=dropSetChord(set,{chord:{root:'C',type:'major'}},{kind:'insert',index});
    assert.equal(result.action,'insert');assert.equal(result.set.chords.length,5);assert.equal(setChordName(result.set.chords[index]),'C');assert.ok(!set.chords.some(c=>c.id===result.selectedId));
    assert.deepEqual(result.set.chords.filter(c=>c.id!==result.selectedId),set.chords);
  }
});
test('Internal centre swaps both cards; edge insertion moves without loss or duplicate occurrence IDs',()=>{
  const set=song(),last=set.chords[3].id;
  assert.deepEqual(names(dropSetChord(set,{id:last},{kind:'replace',index:0}).set),['F','G','Am','C']);
  assert.deepEqual(names(dropSetChord(set,{id:last},{kind:'insert',index:1}).set),['C','F','G','Am']);
  const end=dropSetChord(set,{id:set.chords[0].id},{kind:'insert',index:4});assert.deepEqual(names(end.set),['G','Am','F','C']);assert.equal(new Set(end.set.chords.map(c=>c.id)).size,4);
  assert.equal(dropSetChord(set,{id:last},{kind:'insert',index:4}),null);assert.equal(dropSetChord(set,{id:last},{kind:'replace',index:3}),null);
});
test('Invalid or cancelled targets and stale sources leave the set untouched',()=>{
  const set=song(),before=JSON.stringify(set),source={chord:{root:'D',type:'major'}};
  for(const target of [null,{kind:'replace',index:4},{kind:'insert',index:-1},{kind:'insert',index:1.5},{kind:'delete',index:1}])assert.equal(dropSetChord(set,source,target),null);
  assert.equal(dropSetChord(set,{id:'missing'},{kind:'replace',index:0}),null);assert.equal(JSON.stringify(set),before);
});
test('Outside deletion removes only the dragged occurrence, including the last chord, and leaves its source immutable',()=>{
  let set=song();set=addSetChord(set,{root:'C',type:'major'});const before=JSON.stringify(set),id=set.chords[0].id;
  const result=dropSetChord(set,{id},{kind:'delete'});assert.equal(result.action,'delete');assert.deepEqual(names(result.set),['G','Am','F','C']);assert.equal(JSON.stringify(set),before);assert.equal(result.selectedId,set.chords[1].id);
  assert.equal(dropSetChord(set,{id:'missing'},{kind:'delete'}),null);assert.equal(dropSetChord(set,{chord:{root:'D',type:'major'}},{kind:'delete'}),null);
  const one=addSetChord(newSet(),{root:'C',type:'major'}),empty=dropSetChord(one,{id:one.chords[0].id},{kind:'delete'});assert.equal(empty.set.chords.length,0);assert.equal(empty.selectedId,null);
});
test('Full sequence still allows replacement and internal movement while refusing a new insertion',()=>{
  let set=newSet();for(let i=0;i<MAX_SET_CHORDS;i++)set=addSetChord(set,{root:'C',type:'major'});
  const source={chord:{root:'G',type:'major'}};assert.equal(dropSetChord(set,source,{kind:'insert',index:4}),null);
  assert.equal(dropSetChord(set,source,{kind:'replace',index:4}).set.chords.length,MAX_SET_CHORDS);
  assert.equal(dropSetChord(set,{id:set.chords[0].id},{kind:'insert',index:MAX_SET_CHORDS}).set.chords.length,MAX_SET_CHORDS);
});
const bounds={left:0,right:330,top:0,bottom:180};
const rects=Array.from({length:5},(_,index)=>({index,left:10+(index%4)*80,right:70+(index%4)*80,top:10+Math.floor(index/4)*80,bottom:70+Math.floor(index/4)*80}));
const hit=(x,y,extra={})=>dropTargetAt({x,y,bounds,rects,...extra});
test('Drop geometry distinguishes tile centres, edges and the gap between cards',()=>{
  assert.deepEqual(hit(40,40),{kind:'replace',index:0});assert.deepEqual(hit(12,40),{kind:'insert',index:0});assert.deepEqual(hit(68,40),{kind:'insert',index:1});assert.deepEqual(hit(80,40),{kind:'insert',index:1});
});
test('Wrapped rows, end tile and clipped scrolling boundaries resolve correct insertion positions',()=>{
  assert.deepEqual(hit(40,80),{kind:'insert',index:4});assert.deepEqual(hit(10,115),{kind:'insert',index:4});
  assert.deepEqual(hit(110,115,{rects:[...rects,{index:5,left:90,right:150,top:90,bottom:150,tail:true}]}),{kind:'insert',index:5});
  assert.deepEqual(hit(40,115,{bounds:{...bounds,top:90}}),{kind:'replace',index:4});
});
test('Outside the sequence is cancellation; empty target accepts the first card',()=>{
  assert.equal(hit(40,-1),null);assert.equal(hit(331,100),null);assert.deepEqual(hit(100,100,{rects:[]}),{kind:'insert',index:0});
});

function harness({internal=false}={}){
  const classes=()=>{const set=new Set();return {add(...names){names.forEach(n=>set.add(n));},remove(...names){names.forEach(n=>set.delete(n));},toggle(name,force){if(force)set.add(name);else set.delete(name);},contains:name=>set.has(name)};},handlers=new Map(),drops=[];let timer,ghost;
  const element=()=>({classList:classes(),style:{},children:[],append(...els){this.children.push(...els);},setAttribute(){},remove(){},querySelector(){return this.children[1];}});
  const tile={...element(),getBoundingClientRect:()=>({left:10,right:70,top:10,bottom:70}),hasAttribute:()=>false};
  const sequence={classList:classes(),getBoundingClientRect:()=>({left:0,right:200,top:0,bottom:100}),querySelectorAll:s=>s.includes('[data-chord-id]')?[tile]:[],querySelector:()=>null};
  const win={innerWidth:390,innerHeight:844,setTimeout:cb=>{timer=cb;return 0;},requestAnimationFrame:()=>1,cancelAnimationFrame(){},addEventListener(){},scrollBy(){}};
  const doc={defaultView:win,createElement:element,body:{append(el){ghost=el;}},documentElement:{classList:classes()},addEventListener(){}};
  const mount={ownerDocument:doc,addEventListener:(name,fn)=>{if(!handlers.has(name))handlers.set(name,[]);handlers.get(name).push(fn);}};
  const source={...element(),disabled:false,closest(){return this;},setPointerCapture(){},hasPointerCapture:()=>false};
  const controller=setupChordDrag({mount,sequence,getSource:()=>internal?{id:'chord-1',name:'D'}:{chord:{root:'D',type:'major'},name:'D'},onDrop:(s,t)=>drops.push(t),onStatus(){}});
  function fire(name,values={}){const e={target:source,isPrimary:true,button:0,pointerId:1,pointerType:'touch',clientX:40,clientY:140,detail:1,preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.stopped=true;},...values};for(const fn of handlers.get(name)||[])fn(e);return e;}
  return {fire,hold:()=>timer(),drops,controller,isRed:()=>ghost?.classList.contains('set-drag-delete'),sequence};
}
test('Quick tap remains a tap; touch hold/drop commits once and suppresses the following pointer click',()=>{
  const h=harness();h.fire('pointerdown');h.fire('pointerup');assert.equal(h.fire('click').prevented,undefined);assert.equal(h.drops.length,0);
  h.fire('pointerdown');h.hold();h.fire('pointermove',{clientY:40});h.fire('pointerup',{clientY:40});assert.deepEqual(h.drops,[{kind:'replace',index:0}]);assert.equal(h.fire('click').prevented,true);assert.equal(h.fire('click',{detail:0}).prevented,undefined);
  h.fire('pointerdown');h.fire('pointerup');assert.equal(h.fire('click').prevented,undefined);
});
test('Pointer cancellation, escape-style cancellation and outside release never commit a pending drop',()=>{
  const h=harness();h.fire('pointerdown');h.hold();h.fire('pointermove',{clientY:40});h.fire('pointercancel');assert.equal(h.drops.length,0);
  h.fire('pointerdown');h.hold();h.controller.cancel();h.fire('pointerup',{clientY:40});assert.equal(h.drops.length,0);
  h.fire('pointerdown');h.hold();h.fire('pointerup',{clientX:250,clientY:40});assert.equal(h.drops.length,0);
});
test('A bubbled loss of implicit child capture cannot cancel a chord drag or its insertion',()=>{
 const h=harness();h.fire('pointerdown');h.hold();h.fire('lostpointercapture',{target:{},pointerId:1});h.fire('pointermove',{clientX:12,clientY:40});h.fire('pointerup',{clientX:12,clientY:40});assert.deepEqual(h.drops,[{kind:'insert',index:0}]);
});
test('Internal drag turns red outside, returns to normal inside, and deletes only when released outside',()=>{
  const h=harness({internal:true});h.fire('pointerdown',{clientY:40});h.hold();assert.equal(h.isRed(),false);
  h.fire('pointermove',{clientX:250,clientY:40});assert.equal(h.isRed(),true);assert.equal(h.sequence.classList.contains('set-drop-delete'),true);assert.equal(h.drops.length,0);
  h.fire('pointermove',{clientX:40,clientY:40});assert.equal(h.isRed(),false);assert.equal(h.sequence.classList.contains('set-drop-delete'),false);h.fire('pointerup',{clientY:40});assert.deepEqual(h.drops,[{kind:'replace',index:0}]);
  h.fire('pointerdown',{clientY:40});h.hold();h.fire('pointermove',{clientX:250,clientY:40});h.fire('pointerup',{clientX:250,clientY:40});assert.deepEqual(h.drops.at(-1),{kind:'delete'});assert.equal(h.drops.length,2);
});
test('Cancellation of an internal drag outside never deletes and clears the red frame',()=>{
  const h=harness({internal:true});h.fire('pointerdown',{clientY:40});h.hold();h.fire('pointermove',{clientX:250,clientY:40});assert.equal(h.isRed(),true);h.fire('pointercancel');assert.equal(h.drops.length,0);assert.equal(h.sequence.classList.contains('set-drop-delete'),false);
});
