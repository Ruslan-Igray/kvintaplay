import test from 'node:test';import assert from 'node:assert/strict';
import {createTunerAudio} from '../dist/modules/tuner-audio.js';
import {createTunerPresentation} from '../dist/modules/tuner-presentation.js';
import {createPitchDetector,createPitchTracker,normalizeTuner,frequencyFor,centsBetween} from '../dist/modules/tuner-pitch.js';
import {sampleWaveform,waveformPath} from '../dist/modules/tuner-wave.js';
import {createTuningSequence} from '../dist/modules/tuner-sequence.js';import {stringsFor} from '../dist/modules/tuner-tunings.js';
function pluck(midi,rate,decay=60,noise=0){let seed=17;const f=frequencyFor(midi);return Float32Array.from({length:16384},(_,i)=>{seed=(seed*1664525+1013904223)>>>0;return .004*Math.exp(-decay*i/rate)*(.2*Math.sin(2*Math.PI*f*i/rate)+Math.sin(4*Math.PI*f*i/rate)+.4*Math.sin(6*Math.PI*f*i/rate))+noise*(seed/2**32-.5);});}
test('Rapidly fading E2/A2/D3 with strong partials remain periodic, accurate and usable for Auto',()=>{for(const rate of [44100,48000,96000])for(const midi of [40,45,50])for(const noise of [0,.00002]){const r=createPitchDetector()(pluck(midi,rate,60,noise),rate);assert.ok(r.frequency);assert.ok(Math.abs(centsBetween(r.frequency,frequencyFor(midi)))<3);assert.ok(r.clarity>=.88);}});
test('Amplitude compensation never invents pitch in decaying noise or folds high pure notes',()=>{for(const rate of [44100,48000]){let seed=11;const samples=Float32Array.from({length:16384},(_,i)=>{seed=(seed*1664525+1013904223)>>>0;return .02*Math.exp(-30*i/rate)*(seed/2**32-.5);});assert.equal(createPitchDetector()(samples,rate).frequency,null);for(const midi of [64,69,76]){const f=frequencyFor(midi),s=Float32Array.from({length:16384},(_,i)=>.004*Math.exp(-60*i/rate)*Math.sin(2*Math.PI*f*i/rate));const r=createPitchDetector()(s,rate);assert.ok(r.frequency);assert.ok(Math.abs(centsBetween(r.frequency,f))<4);}}});
test('Live waveform exists without a recognized pitch; silence/old audio cannot create activity',()=>{const silence=sampleWaveform(new Float32Array(16384),48000);assert.equal(silence.rms,0);assert.ok(silence.points.every(v=>v===0));const samples=pluck(40,48000,0);const w=sampleWaveform(samples,48000);assert.ok(w.rms>0);assert.ok(Math.max(...w.points)>.1);assert.match(waveformPath(w.points),/Q/);const old=samples.slice();old.fill(0,8000);assert.equal(sampleWaveform(old,48000).rms,0);assert.ok(!waveformPath(w.points).includes('NaN'));});
test('Auto tolerates short missing frames but counts only observed stable time and rejects a real detuning',()=>{const strings=stringsFor(),s=strings[0],flow=createTuningSequence(),model={target:s,frequency:frequencyFor(s.midi),stable:true},m={frequency:model.frequency,clarity:.99,rms:.01};let event=null;for(let now=0;now<=1400;now+=40){event=flow.update(now===400||now===440?null:model,m,now,strings);if(event)break;}assert.equal(event?.next,5);const broken=createTuningSequence();for(let now=0;now<800;now+=40)broken.update(model,m,now,strings);broken.update({...model,stable:false},m,800,strings);assert.equal(broken.update(model,m,840,strings),null);assert.equal(broken.progress(840),0);const silent=createTuningSequence();for(let now=0;now<800;now+=40)silent.update(model,m,now,strings);silent.update(null,{rms:0},1100,strings);assert.equal(silent.update(model,m,1140,strings),null);assert.equal(silent.progress(1140),0);});
test('A masked, quiet E2/A2/D3 returns promptly through the real microphone reader after a drum hit',async()=>{
 for(const sampleRate of [44100,48000,96000])for(const [string,midi] of [[6,40],[5,45],[4,50]]){
  const f=frequencyFor(midi),samples=new Float32Array(Math.ceil(sampleRate*1.7));let seed=73,now=0;
  for(let i=0;i<samples.length;i++){
   const t=i/sampleRate,p=2*Math.PI*f*t;
   samples[i]=.0005*(.28*Math.sin(p)+Math.sin(2*p)+.3*Math.sin(3*p));
   if(t>=1&&t<1.08){seed=(1664525*seed+1013904223)>>>0;samples[i]+=.2*(seed/2**32-.5)*Math.exp(-12*(t-1));}
  }
  const node={connect(){},disconnect(){}};
  const analyser={...node,getFloatTimeDomainData(buffer){
   const end=Math.round(now*sampleRate/1000);buffer.fill(0);const from=Math.max(0,end-buffer.length);
   buffer.set(samples.subarray(from,end),Math.max(0,buffer.length-end));
  }};
  const audio=createTunerAudio({mediaDevices:{async getUserMedia(){return {getTracks:()=>[],getAudioTracks:()=>[]};}},audioContextFactory:()=>({
   state:'running',sampleRate,destination:node,createAnalyser:()=>analyser,createGain:()=>({...node,gain:{value:0}}),createMediaStreamSource:()=>node,async close(){}
  })});
  const tracker=createPitchTracker(),display=createTunerPresentation(),settings=normalizeTuner({string});
  try{
   assert.equal(await audio.start(),true);let recoveredAt=null;
   for(now=400;now<=1320;now+=40){
    const signal=audio.read(),frame=display.update(tracker.update(signal,now,settings),now);
    if(now===1000)assert.equal(frame.model.tuned,true);
    if(now===1040||now===1080){assert.equal(frame.phase,'last');assert.equal(frame.model.tuned,false);assert.equal(frame.model.note.midi,midi);}
    if(now>1080&&frame.phase==='live'&&recoveredAt===null){recoveredAt=now;assert.ok(Math.abs(centsBetween(frame.model.frequency,f))<3);}
   }
   assert.ok(recoveredAt!==null&&recoveredAt-1080<=120,`String ${string} at ${sampleRate}: ${recoveredAt}`);
  }finally{audio.stop();}assert.equal(audio.read(),null);
 }
});
