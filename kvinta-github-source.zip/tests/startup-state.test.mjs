import test from 'node:test';import assert from 'node:assert/strict';
import {startupTarget,lastToolView,rememberToolView} from '../dist/modules/startup-state.js';
import {PREFERENCES_KEY} from '../dist/modules/preferences.js';
import {readFileSync} from 'node:fs';
test('Every workspace entry and its split modules are available offline',()=>{
 const dist=new URL('../dist/',import.meta.url);
 const sw=readFileSync(new URL('sw.js',dist),'utf8');
 const files=new Set(JSON.parse(sw.match(/^const FILES=(.+);$/m)[1]));
 const seen=new Set();
 function checkBundle(url){
  if(seen.has(url.href))return;
  seen.add(url.href);
  assert.ok(files.has('./'+url.href.slice(dist.href.length)),'Missing from offline cache: '+url.href);
  const script=readFileSync(url,'utf8');
  for(const [,chunk] of script.matchAll(/["'](\.\/boot-chunk-[A-Z0-9]+\.js)["']/g))checkBundle(new URL(chunk,url));
 }
 for(const page of ['index.html','songs/index.html','tests/index.html']){
  const entry=new URL(page,dist);
  const html=readFileSync(entry,'utf8');
  const match=html.match(/<script type="module" src="([^"]+\/boot-(?:tools|songs|tests)\.js)"><\/script>/);
  assert.ok(match,'Missing bundled entry for '+page);
  checkBundle(new URL(match[1],entry));
 }
});
test('A plain app launch restores the song workspace for root and GitHub subdirectory hosting',()=>{
 for(const path of ['/','/kvinta/'])for(const suffix of ['','index.html'])assert.equal(startupTarget({lastWorkspace:'song',pathname:path+suffix,base:'https://example.test'+path}),path+'songs/');
 assert.equal(startupTarget({lastWorkspace:'tools',pathname:'/kvinta/',base:'https://example.test/kvinta/'}),null);
});
test('Shared songs/sets, chord deep links and explicit mode navigation take priority over the saved workspace',()=>{
 const base={lastWorkspace:'song',pathname:'/kvinta/',base:'https://example.test/kvinta/'};
 for(const hash of ['#song=abc','#set=v4.example','#circle'])assert.equal(startupTarget({...base,hash}),null);
 for(const search of ['?from=song','?chord-root=C&chord-type=major'])assert.equal(startupTarget({...base,search}),null);
 assert.equal(startupTarget({...base,pathname:'/kvinta/songs/'}),null);assert.equal(startupTarget({...base,pathname:'/kvinta-other/'}),null);
});
test('Last instrument section persists additively; invalid values and unavailable storage fall back to the tuner',()=>{
 const data=new Map([[PREFERENCES_KEY,JSON.stringify({theme:'light',lastWorkspace:'song',metronome:{bpm:137},future:'keep'})]]),storage={getItem:key=>data.get(key),setItem:(key,value)=>data.set(key,value)};
 assert.equal(lastToolView(storage),'tuner');for(const view of ['circle','metronome','library','favorites','composition']){assert.equal(rememberToolView(view,storage),true);assert.equal(lastToolView(storage),view);}
 assert.equal(rememberToolView('shared',storage),false);const saved=JSON.parse(data.get(PREFERENCES_KEY));assert.equal(saved.lastWorkspace,'song');assert.equal(saved.metronome.bpm,137);assert.equal(saved.future,'keep');
 assert.equal(lastToolView({getItem(){throw Error();}}),'tuner');
});
