import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import {localD1} from '../scripts/local-d1.mjs';import {telemetryRequest,issueToken,verifyToken,validateEvents,report,ingest,moscowDay,EVENT_TYPES} from '../worker/telemetry.js';import {createAnalytics,ANALYTICS_EVENT_TYPES} from '../dist/modules/analytics.js';import {createShareActions} from '../dist/modules/share-actions.js';
const origin='https://ruslan-igray.github.io',now=Date.UTC(2026,10,2,10),sign='unit-test-signing-secret-not-production',read='unit-test-read-secret-not-production';
const event=(type,at=now)=>({id:randomUUID(),type,at});
test('Telemetry accepts only approved origins and bounded anonymous fields; report reads require a separate server key',async()=>{
 const db=localD1(),env={DB:db,TELEMETRY_SIGN_KEY:sign,STATS_READ_KEY:read},req=(route,data,headers={})=>new Request('https://app.test/api/telemetry/'+route,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...headers},body:JSON.stringify(data)});
 try{let response=await telemetryRequest(req('session',{id:randomUUID(),platform:'ios'}),env,now);assert.equal(response.status,200);assert.equal(response.headers.get('access-control-allow-origin'),origin);const session=await response.json();const c=await verifyToken(session.token,sign,origin,now);assert.equal(c.source,'github');assert.equal(c.platform,'ios');assert.equal(await verifyToken(session.token,sign,'https://evil.test',now),null);assert.equal(await verifyToken(session.token,sign,origin,now+3*86400000),null);assert.equal(await verifyToken(session.token.replace(/\.(.)/,(_,c)=>'.'+(c==='A'?'B':'A')),sign,origin,now),null);
 assert.equal((await telemetryRequest(req('session',{id:randomUUID(),platform:'ios'},{Origin:'https://evil.test'}),env,now)).status,403);assert.equal((await telemetryRequest(req('session',{id:randomUUID(),platform:'ios',email:'not-collected'}),env,now)).status,400);assert.equal((await telemetryRequest(req('events',{events:[event('active')]}),env,now)).status,401);
 response=await telemetryRequest(req('events',{events:[event('launch'),event('install')]},{Authorization:'Bearer '+session.token}),env,now);assert.equal(response.status,200);assert.equal((await response.json()).accepted,2);
 const url='https://app.test/api/telemetry/report?period=7';assert.equal((await telemetryRequest(new Request(url),env,now)).status,401);response=await telemetryRequest(new Request(url,{headers:{Authorization:'Bearer '+read}}),env,now);assert.equal(response.status,200);assert.equal(response.headers.get('access-control-allow-origin'),null);assert.equal((await response.json()).installations,1);
 }finally{db.close();}
});
test('Unknown data, malformed dates, excessive batches and chord contents cannot enter the statistics database',()=>{
 for(const e of [{...event('launch'),name:'Private song'},{...event('active'),microphone:[1,2]},event('arbitrary'),event('active',now-8*86400000),event('active',now+3*60000),{id:'not-a-uuid',type:'launch',at:now}])assert.throws(()=>validateEvents({events:[e]},now));
 assert.throws(()=>validateEvents({events:Array.from({length:21},()=>event('active'))},now));assert.throws(()=>validateEvents({events:[event('launch')],url:'secret'},now));assert.equal(moscowDay(Date.UTC(2026,10,1,22)),'2026-11-02');
});
test('Duplicate offline retries do not inflate counts; date/source filters and first observed installs stay consistent',async()=>{
 const db=localD1(),a={id:randomUUID(),source:'github',platform:'ios'},b={id:randomUUID(),source:'sites',platform:'android'},yesterday=now-86400000,events=[event('launch'),event('install'),event('share_copy'),event('share_send'),event('set_open'),event('set_save')].map(e=>({...e,day:moscowDay(e.at)}));
 try{assert.equal(await ingest(db,a,events),6);assert.equal(await ingest(db,a,events),0);await ingest(db,b,[{...event('launch',yesterday),day:moscowDay(yesterday)}]);let data=await report(db,'1','all',now);assert.equal(data.active,1);assert.equal(data.installations,1);assert.equal(data.totals.share_copy,1);assert.equal(data.totals.share_send,1);assert.equal(data.totals.set_open,1);assert.equal(data.totals.set_save,1);assert.equal(data.daily[0].exchanges,2);data=await report(db,'7','all',now);assert.equal(data.active,2);assert.equal(data.daily.length,2);assert.equal((await report(db,'7','sites',now)).active,1);assert.equal((await report(db,'1','sites',now)).active,0);assert.equal((await report(db,'all','github',now)).totals.launch,1);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM telemetry_events').get().n,7);}finally{db.close();}
});
test('Per-copy daily event limits bound ingestion without mutating musical data or exposing report access',async()=>{
 const db=localD1(),claims={id:randomUUID(),source:'sites',platform:'other'};try{for(let i=0;i<31;i++)await ingest(db,claims,Array.from({length:20},()=>({...event('active'),day:moscowDay(now)})));assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM telemetry_events').get().n,600);assert.equal((await report(db,'1','all',now)).active,1);}finally{db.close();}
});
const memory=()=>{const data=new Map();return {getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),data};};
function client({offline=true,local=false,storage=memory(),session=memory(),fail=false}={}){const calls=[],nav={standalone:true,userAgent:'iPhone',onLine:!offline},doc={hidden:false,addEventListener(){},removeEventListener(){}},win={location:{hostname:local?'127.0.0.1':'ruslan-igray.github.io'},addEventListener(){},removeEventListener(){},matchMedia:()=>({matches:true})};let failure=fail;const api=createAnalytics({win,nav,doc,storage,session,now:()=>now,uuid:randomUUID,later:()=>1,cancel(){},repeat:()=>1,stopRepeat(){},fetcher:async(url,options)=>{calls.push({url,...options});if(failure)throw Error('offline');return url.endsWith('/session')?Response.json({token:'test-session',expiresAt:now+86400000}):Response.json({accepted:JSON.parse(options.body).events.length});}});return {api,calls,storage,session,nav,set failure(v){failure=v;}};}
test('Client queues offline events, sends only minimal fields, and deduplicates first icon launches and repeated received-link opens',async()=>{
 const c=client();c.api.start();assert.equal(c.calls.length,0);await c.api.trackOnce('set_open','#set=PRIVATE-CONTENT');await c.api.trackOnce('set_open','#set=PRIVATE-CONTENT');c.api.track('share_copy');c.nav.onLine=true;await c.api.flush();const body=JSON.parse(c.calls.find(x=>x.url.endsWith('/events')).body);assert.deepEqual(body.events.map(e=>e.type),['launch','install','set_open','share_copy']);assert.ok(body.events.every(e=>Object.keys(e).sort().join(',')==='at,id,type'));assert.ok(!JSON.stringify(c.calls).includes('PRIVATE-CONTENT'));assert.equal(c.calls[0].credentials,'omit');assert.equal(c.calls[0].referrerPolicy,'no-referrer');c.api.stop();const next=client({offline:false,storage:c.storage,session:c.session});next.api.start();await next.api.flush();assert.deepEqual(JSON.parse(next.calls.at(-1).body).events.map(e=>e.type),['active']);next.api.stop();
});
test('Network errors retain the queue, opt-out clears future sends, and local previews do not pollute production statistics',async()=>{
 const c=client({offline:false,fail:true});c.api.start();await c.api.flush();assert.ok(JSON.parse(c.storage.getItem('kvinta.analytics.queue.v1')).length>0);c.failure=false;await c.api.flush();assert.deepEqual(JSON.parse(c.storage.getItem('kvinta.analytics.queue.v1')),[]);c.api.setEnabled(false);c.api.track('share_copy');const count=c.calls.length;await c.api.flush();assert.equal(c.calls.length,count);c.api.stop();const local=client({offline:false,local:true});local.api.start();await local.api.flush();assert.equal(local.calls.length,0);local.api.stop();
});


test('Owner read tickets cross the browser boundary with exact CORS, expiry and filter scope; write credentials cannot read statistics',async()=>{
 const db=localD1(),env={DB:db,STATS_READ_KEY:read},ownerOrigin='https://kvinta-private-statistics.sappy-mule-8607.chatgpt.site',claims={role:'report',origin:ownerOrigin,period:'7',source:'all',iat:now,exp:now+120000,nonce:randomUUID()};
 const encoded=Buffer.from(JSON.stringify(claims)).toString('base64url'),key=await crypto.subtle.importKey('raw',new TextEncoder().encode(read),{name:'HMAC',hash:'SHA-256'},false,['sign']),sig=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('r1.'+encoded)),ticket='r1.'+encoded+'.'+Buffer.from(sig).toString('base64url');
 const request=(token=ticket,origin=ownerOrigin,query='period=7&source=all')=>new Request('https://app.test/api/telemetry/report?'+query,{headers:{Origin:origin,Authorization:'Bearer '+token}});
 try{const preflight=await telemetryRequest(new Request('https://app.test/api/telemetry/report',{method:'OPTIONS',headers:{Origin:ownerOrigin}}),env,now);assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),ownerOrigin);assert.equal(preflight.headers.get('access-control-allow-credentials'),null);
 const result=await telemetryRequest(request(),env,now);assert.equal(result.status,200);assert.equal(result.headers.get('access-control-allow-origin'),ownerOrigin);assert.equal((await result.json()).active,0);
 assert.equal((await telemetryRequest(request(),env,now+120001)).status,401);assert.equal((await telemetryRequest(request(ticket,'https://evil.test'),env,now)).status,403);assert.equal((await telemetryRequest(request(ticket,ownerOrigin,'period=30&source=all'),env,now)).status,401);assert.equal((await telemetryRequest(request(ticket.replace(/r1./,'r2.')),env,now)).status,401);assert.equal((await telemetryRequest(request(read),env,now)).status,401);
 const write=await issueToken({id:randomUUID(),platform:'ios',source:'sites',origin:ownerOrigin,exp:now+1000},read);assert.equal((await telemetryRequest(request(write),env,now)).status,401);
 }finally{db.close();}
});


test('Share actions flush immediately and hidden/pagehide attempt delivery; opt-out removes lifecycle sends',async()=>{
 const handlers=new Map(),storage=memory(),session=memory(),calls=[],nav={onLine:false,userAgent:'iPhone',standalone:false},doc={hidden:false,addEventListener:(k,v)=>handlers.set('doc:'+k,v),removeEventListener:k=>handlers.delete('doc:'+k)},win={location:{hostname:'ruslan-igray.github.io'},matchMedia:()=>({matches:false}),addEventListener:(k,v)=>handlers.set('win:'+k,v),removeEventListener:k=>handlers.delete('win:'+k)};
 const api=createAnalytics({win,nav,doc,storage,session,now:()=>now,uuid:randomUUID,later:()=>1,cancel(){},repeat:()=>1,stopRepeat(){},fetcher:async(url,options)=>{calls.push({url,options});return url.endsWith('/session')?Response.json({token:'lifecycle-test',expiresAt:now+86400000}):Response.json({accepted:JSON.parse(options.body).events.length});}});
 const settled=()=>new Promise(resolve=>setImmediate(resolve));api.start();nav.onLine=true;doc.hidden=true;handlers.get('doc:visibilitychange')();await settled();assert.equal(calls.length,2);assert.equal(calls[1].options.keepalive,true);assert.equal(JSON.parse(calls[1].options.body).events[0].type,'launch');
 calls.length=0;api.track('share_copy');await settled();assert.equal(calls.length,1);assert.equal(JSON.parse(calls[0].options.body).events[0].type,'share_copy');
 nav.onLine=false;api.track('set_open');nav.onLine=true;handlers.get('win:pagehide')();await settled();assert.equal(JSON.parse(calls.at(-1).options.body).events[0].type,'set_open');api.setEnabled(false);assert.equal(handlers.has('win:pagehide'),false);const before=calls.length;api.track('share_send');await settled();assert.equal(calls.length,before);api.stop();
});

test('Set and app sharing outcomes pass the same bounded CORS schema, survive retries and stay separate in reports',async()=>{
 assert.deepEqual(ANALYTICS_EVENT_TYPES,EVENT_TYPES);
 const db=localD1(),env={DB:db,TELEMETRY_SIGN_KEY:sign},claims={id:randomUUID(),origin,source:'github',platform:'ios',exp:now+86400000},token=await issueToken(claims,sign);
 const types=['share_attempt','share_send','share_attempt','share_cancel','share_copy','app_share_attempt','app_share_send','app_share_attempt','app_share_error','app_share_copy'],events=types.map(t=>event(t));
 const req=()=>new Request('https://app.test/api/telemetry/events',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({events})});
 try{
   const response=await telemetryRequest(req(),env,now);assert.equal(response.status,200);assert.equal(response.headers.get('access-control-allow-origin'),origin);assert.equal((await response.json()).accepted,10);
   assert.equal((await (await telemetryRequest(req(),env,now)).json()).accepted,0);
   const data=await report(db,'7','github',now);assert.equal(data.totals.share_attempt,2);assert.equal(data.totals.share_send,1);assert.equal(data.totals.share_cancel,1);assert.equal(data.totals.app_share_attempt,2);assert.equal(data.totals.app_share_send,1);assert.equal(data.totals.app_share_error,1);
   assert.equal(data.daily[0].share_attempts,2);assert.equal(data.daily[0].app_share_attempts,2);assert.equal(data.daily[0].exchanges,2);assert.equal(data.daily[0].app_exchanges,2);assert.equal(data.daily[0].share_copies,1);assert.equal(data.daily[0].app_share_copies,1);
   assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM telemetry_events').get().n,10);
 }finally{db.close();}
});

test('A still-pending native share is durable before page suspension and replays with the same event id on the next launch',async()=>{
 const handlers=new Map(),storage=memory(),session=memory(),nav={onLine:false,userAgent:'iPhone'},doc={hidden:false,addEventListener:(k,v)=>handlers.set(k,v),removeEventListener:k=>handlers.delete(k)},win={location:{hostname:'ruslan-igray.github.io'},addEventListener:(k,v)=>handlers.set(k,v),removeEventListener:k=>handlers.delete(k)};
 const api=createAnalytics({win,nav,doc,storage,session,now:()=>now,uuid:randomUUID,later:()=>1,cancel(){},repeat:()=>1,stopRepeat(){},fetcher:async()=>{throw Error('no connection');}});
 api.start();nav.share=()=>{assert.ok(JSON.parse(storage.getItem('kvinta.analytics.queue.v1')).some(e=>e.type==='share_attempt'));return new Promise(()=>{});};
 const actions=createShareActions({nav,analytics:api});void actions.send({url:'https://example.test/'});
 doc.hidden=true;handlers.get('visibilitychange')();handlers.get('pagehide')();
 const before=JSON.parse(storage.getItem('kvinta.analytics.queue.v1')),attempt=before.find(e=>e.type==='share_attempt');assert.ok(attempt);assert.equal(before.some(e=>e.type==='share_send'),false);api.stop();
 const next=client({offline:false,storage,session});next.api.start();await next.api.flush();const sent=next.calls.filter(c=>c.url.endsWith('/events')).flatMap(c=>JSON.parse(c.body).events);assert.deepEqual(sent.find(e=>e.type==='share_attempt'),attempt);assert.equal(sent.some(e=>e.type==='share_send'),false);assert.deepEqual(JSON.parse(storage.getItem('kvinta.analytics.queue.v1')),[]);next.api.stop();
});
