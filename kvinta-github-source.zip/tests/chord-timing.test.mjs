import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeSong,lineBeats,snapshot} from '../features/songs/src/score-model.js';
import {applyChordTiming,createChordTimingSession,orderedChords} from '../features/songs/src/chord-timing.js';
import {recordingBeat,recordingTime,recordingRhythmOrigin} from '../features/songs/src/recording-model.js';
import {createRecordingTransport} from '../features/songs/src/recording-transport.js';
import {songApiRequest} from '../worker/song-api.js';

const score=()=>normalizeSong({schema:2,id:'chord-timing',title:'Тапы',parts:[{id:'part',name:'Куплет',lines:[
 {id:'line-1',text:'Первая строка',chords:[{id:'c1',symbol:'Am',column:0,beats:8},{id:'c2',symbol:'F',column:8,beats:8}]},
 {id:'line-2',text:'Вторая строка',chords:[{id:'c3',symbol:'C',column:0,beats:8},{id:'c4',symbol:'G',column:8,beats:8}]}
]}],rehearsal:{bpm:150,meter:'4/4'},recording:{localId:'audio-file',name:'track.wav',duration:30,referenceBpm:120,tempoVerified:true,enabled:false,times:[]}});

test('Consecutive chord taps calculate half-beat durations without modifying the input',()=>{
 const song=score(),before=JSON.stringify(song),{song:next,durations}=applyChordTiming(song,{boundaries:[2,4,5,8,10]});
 assert.equal(JSON.stringify(song),before);assert.deepEqual(orderedChords(next).map(c=>c.symbol),['Am','F','C','G']);
 assert.deepEqual(next.parts.flatMap(p=>p.lines).flatMap(l=>l.chords).map(c=>c.beats),[4,2,6,4]);
 assert.deepEqual(durations.map(d=>d.beats),[4,2,6,4]);assert.equal(next.recording.enabled,true);assert.equal(next.rehearsal.bpm,150);
});
test('Exact timestamps survive rounding and persisted snapshots',()=>{
 const next=applyChordTiming(score(),{boundaries:[1.1234,3.1445,4.13]}).song,restored=snapshot(JSON.parse(JSON.stringify(next)),{});
 assert.deepEqual(restored.recording.chordTimes,[{chordId:'c1',at:1.123,endAt:3.145},{chordId:'c2',at:3.145,endAt:4.13}]);
 assert.equal(recordingBeat(restored,3.145),4);assert.equal(recordingTime(restored,4),3.145);
 for(const beat of [0,1,2,3,4,5,6])assert.ok(Math.abs(recordingBeat(restored,recordingTime(restored,beat))-beat)<1e-8);
});
test('Partial marking changes only completed chords, not the last started chord',()=>{
 const result=applyChordTiming(score(),{start:1,boundaries:[8,9,11]});
 assert.deepEqual(result.song.parts.flatMap(p=>p.lines).flatMap(l=>l.chords).map(c=>c.beats),[8,2,4,8]);
 assert.deepEqual(result.song.recording.chordTimes.map(t=>t.chordId),['c2','c3']);
});
test('A marked fragment preserves coherent old line anchors outside its range',()=>{
 const song=score();song.recording.times=[{lineId:'line-1',at:2},{lineId:'line-2',at:10}];
 const next=applyChordTiming(song,{start:2,boundaries:[11,13]}).song;
 assert.equal(recordingTime(next,0),2);assert.equal(recordingTime(next,16),11);assert.equal(recordingTime(next,20),13);
});
test('Rounding error is carried forward rather than accumulating at every chord',()=>{
 const result=applyChordTiming(score(),{boundaries:[0,1.12,2.24,3.36,4.48]});
 const total=result.durations.reduce((n,d)=>n+d.beats,0);assert.equal(total,9);assert.ok(Math.abs(total-4.48*2)<.25);
});
test('Invalid, equal, backwards and out-of-file times never replace a score',()=>{
 for(const boundaries of [[0],[0,0],[3,2],[0,NaN],[0,31],[0,.01],[0,1,2,3,4,5]])assert.throws(()=>applyChordTiming(score(),{boundaries}));
 assert.throws(()=>applyChordTiming(score(),{boundaries:[0,1],bpm:0}));assert.throws(()=>applyChordTiming(score(),{start:4,boundaries:[0,1]}));
});
test('Lyric-only lines share measured duration instead of adding phantom beats',()=>{
 const song=score();song.parts[0].lines.splice(1,0,{id:'plain',text:'Без аккордов',chords:[],beats:16,cues:[]});
 const next=applyChordTiming(song,{start:1,boundaries:[4,8]}).song;
 assert.equal(next.parts[0].lines[0].chords[1].beats+lineBeats(next.parts[0].lines[1]),8);
 const start=next.parts[0].lines[0].chords[0].beats;
 assert.equal(recordingBeat(next,4),start);assert.equal(recordingBeat(next,8),start+8);
});
test('Re-marking a fragment preserves non-crossing anchors and discards conflicting old timestamps',()=>{
 const first=applyChordTiming(score(),{boundaries:[0,2,4,6,8]}).song;
 let next=applyChordTiming(first,{start:1,boundaries:[2,3]}).song;
 assert.deepEqual(next.recording.chordTimes.map(t=>t.chordId),['c1','c2','c3','c4']);
 next=applyChordTiming(first,{start:1,boundaries:[1,7]}).song;
 assert.deepEqual(next.recording.chordTimes.map(t=>t.chordId),['c2']);
});
test('Normalization rejects unknown, overlapping, unordered or unbounded chord marks',()=>{
 const song=score();song.recording.chordTimes=[{chordId:'unknown',at:0,endAt:1},{chordId:'c1',at:2,endAt:4},{chordId:'c2',at:3,endAt:6},{chordId:'c3',at:5,endAt:7},{chordId:'c4',at:9,endAt:31}];
 const next=normalizeSong(song);assert.deepEqual(next.recording.chordTimes,[{chordId:'c1',at:2,endAt:4},{chordId:'c3',at:5,endAt:7}]);
});
function sessionHarness(){let song=score(),time=0,playing=false,rate=1;const session=createChordTimingSession({getSong:()=>song,getTime:()=>time,isPlaying:()=>playing,getRate:()=>rate});return {session,setTime:t=>time=t,setPlaying:p=>playing=p,setRate:r=>rate=r,setSong:s=>song=s,get song(){return song;}};}
test('Tap session ignores paused, unconfirmed and sped-up recording playback',()=>{
 const h=sessionHarness();h.session.tap();assert.equal(h.session.state().dirty,false);h.setPlaying(true);h.setRate(1.25);h.session.tap();assert.equal(h.session.state().dirty,false);
 h.setRate(1);h.setSong({...h.song,recording:{...h.song.recording,tempoVerified:false}});h.session.tap();assert.equal(h.session.state().dirty,false);
});
test('Session supports undo, explicit finish, partial apply and restarts at any chord',()=>{
 const h=sessionHarness();h.setPlaying(true);h.session.reset(1);h.setTime(2);h.session.tap();h.setTime(3);h.session.tap();h.setTime(4);h.session.finish();
 assert.equal(h.session.state().finished,true);assert.equal(h.session.state().count,2);h.session.undo();assert.equal(h.session.state().finished,false);assert.equal(h.session.state().count,1);
 assert.deepEqual(h.session.result().durations.map(d=>d.chordId),['c2']);h.setTime(5);h.session.finish();assert.equal(h.session.result().durations[1].beats,4);
});
test('Backwards seeking and accidental double taps cannot corrupt the active sequence',()=>{
 const h=sessionHarness();h.setPlaying(true);h.setTime(5);h.session.tap();h.setTime(5.03);assert.equal(h.session.tap().ignored,true);h.setTime(2);assert.equal(h.session.tap().ignored,true);assert.deepEqual(h.session.state().boundaries,[5]);h.setTime(7);h.session.tap();assert.equal(h.session.state().count,1);
});
test('Changing songs or recording identity invalidates an unfinished tap session',()=>{
 const h=sessionHarness();h.setPlaying(true);h.session.tap();h.setTime(2);h.session.tap();h.setSong({...h.song,id:'another'});assert.equal(h.session.state().count,0);assert.throws(()=>h.session.result());
});
test('Last chord needs its own ending tap and cannot overflow to a non-existent chord',()=>{
 const h=sessionHarness();h.setPlaying(true);h.session.reset(3);h.setTime(3);h.session.tap();assert.equal(h.session.state().next,undefined);assert.equal(h.session.state().canApply,false);
 h.setTime(5);h.session.tap();assert.equal(h.session.state().finished,true);h.setTime(6);assert.equal(h.session.tap().ignored,true);assert.equal(h.session.result().durations[0].beats,4);
});
test('Tap jitter affects score anchors but never makes the metronome accelerate',()=>{
 const song=applyChordTiming(score(),{boundaries:[2,4.08,5.04,7.96,10]}).song;assert.equal(recordingRhythmOrigin(song),2);
 assert.equal((4.08-recordingRhythmOrigin(song))*song.recording.referenceBpm/60,4.16);
 assert.equal(recordingBeat(song,4.08),4);
});
test('Chord-only recording marks enable prepare, seeking, playback and restore without line taps',async()=>{
 let song=applyChordTiming(score(),{boundaries:[2,4,5]}).song;
 const media={currentTime:0,paused:true,playbackRate:1,muted:false,pause(){this.paused=true;},async play(){this.paused=false;},load(){},removeAttribute(){}};
 const transport=createRecordingTransport({media,getSong:()=>song,onRecord:r=>song={...song,recording:r},store:{get:async()=>({size:10}),put:async()=>{}},makeUrl:()=> 'blob:test',revokeUrl(){},waitMetadata:async()=>30});
 await transport.restore();assert.equal(await transport.prepare(),true);transport.seekBeat(4);assert.equal(media.currentTime,4);await transport.play();assert.equal(transport.beat(),4);assert.equal(transport.rhythmClock().beat,4);assert.equal(media.playbackRate,1.25);
 await transport.attach({size:10,name:'track-copy.wav'});assert.equal(song.recording.chordTimes.length,2);assert.equal(song.recording.tempoVerified,true);
});
test('Shared songs retain chord timings and BPM, but never include the audio file identity',async()=>{
 const song=applyChordTiming(score(),{boundaries:[2,4,5]}).song,objects=new Map(),env={BUCKET:{put:async(k,v)=>objects.set(k,v),get:async k=>objects.has(k)?{text:async()=>objects.get(k)}:null}};
 const response=await songApiRequest(new Request('https://test.local/api/song-shares',{method:'POST',headers:{origin:'https://test.local','content-type':'application/json'},body:JSON.stringify({song})}),env,{limit:async()=>true});assert.equal(response.status,201);
 const link=await response.json(),data=await (await songApiRequest(new Request('https://test.local/api/song-shares/'+link.id),env)).json();
 assert.deepEqual(data.song.recording.chordTimes,song.recording.chordTimes);assert.equal(data.song.recording.tempoVerified,true);assert.equal(data.song.recording.localId,null);assert.equal(data.song.recording.enabled,false);
});
