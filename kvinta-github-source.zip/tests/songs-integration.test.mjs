import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {songApiRequest,allowSongRequest} from '../worker/song-api.js';
import {apiUrl} from '../features/songs/src/api.js';
import {SEARCH_SERVICE_ORIGIN} from '../features/songs/src/service-config.js';
const SERVICE='https://kvinta-guitar-circle.sappy-mule-8607.chatgpt.site',ORIGIN='https://ruslan-igray.github.io';
const song={schema:1,title:'Учебный пример',parts:[{name:'Куплет',lines:[{text:'Моя строка',chords:[{symbol:'Am',column:0}]}]}],rehearsal:{bpm:108,key:4,mode:'tempo'}};
test('GitHub phone client shares a song and opens the immutable version with CORS',async()=>{const files=new Map(),env={BUCKET:{async put(k,v){files.set(k,v);},async get(k){return files.has(k)?{text:async()=>files.get(k)}:null;}}},options={limit:async()=>true};
 const preflight=await songApiRequest(new Request(SERVICE+'/api/song-shares',{method:'OPTIONS',headers:{origin:ORIGIN}}),env,options);assert.equal(preflight.status,204);
 const created=await songApiRequest(new Request(SERVICE+'/api/song-shares',{method:'POST',headers:{origin:ORIGIN,'content-type':'application/json'},body:JSON.stringify({song})}),env,options);assert.equal(created.status,201);assert.equal(created.headers.get('access-control-allow-origin'),ORIGIN);const data=await created.json();assert.equal(data.url,'https://ruslan-igray.github.io/kvinta/#song='+data.id);
 const opened=await songApiRequest(new Request(SERVICE+'/api/song-shares/'+data.id,{headers:{origin:ORIGIN}}),env,options);assert.equal(opened.status,200);assert.equal((await opened.json()).song.rehearsal.bpm,108);
});
test('Untrusted origin is refused before storage or source requests and request limits fail closed',async()=>{let called=false;const deps={limit:async()=>{called=true;return false;}};const denied=await songApiRequest(new Request(SERVICE+'/api/songs/search?q=hello',{headers:{origin:'https://evil.test'}}),{},deps);assert.equal(denied.status,403);assert.equal(called,false);const limited=await songApiRequest(new Request(SERVICE+'/api/songs/search?q=hello',{headers:{origin:ORIGIN}}),{},deps);assert.equal(limited.status,429);assert.equal(limited.headers.get('access-control-allow-origin'),ORIGIN);assert.equal(await allowSongRequest(new Request(SERVICE),{},'import'),false);});
test('The production song client uses the search service for lookup, artist lists and imports',()=>{
 for(const hostname of ['kvintaplay.ru','ruslan-igray.github.io']){
  for(const path of ['/api/songs/search?q=%D0%9A%D0%B8%D0%BD%D0%BE','/api/songs/artist?url=artist','/api/songs/import?url=song']){
   assert.equal(apiUrl(path,{hostname}),SEARCH_SERVICE_ORIGIN+path);
  }
  for(const path of ['/api/song-shares','/api/song-shares/abc','/api/songs/unrelated']){
   assert.equal(apiUrl(path,{hostname}),SERVICE+path);
  }
 }
 assert.equal(apiUrl('/api/songs/search',{hostname:'localhost'}),'/api/songs/search');
});
test('Public share quota is atomic and stores a keyed code instead of a network address',async()=>{const rows=new Map(),bound=[];const env={TELEMETRY_SIGN_KEY:'test-only-secret',DB:{prepare(sql){return {bind(...args){bound.push(args);return {async first(){const [id,,limit]=args,n=rows.get(id)||0;if(n>=limit)return null;rows.set(id,n+1);return {hits:n+1};},async run(){return {};}};}};}}};const req=new Request(SERVICE,{headers:{'cf-connecting-ip':'192.0.2.44'}});for(let i=0;i<30;i++)assert.equal(await allowSongRequest(req,env,'share',1700000000000),true);assert.equal(await allowSongRequest(req,env,'share',1700000000000),false);assert.ok(!JSON.stringify(bound).includes('192.0.2.44'));});
test('Updated worker serves correct offline entry on both root and GitHub subpath',async()=>{const listeners={},seen=[],cache={match:async key=>{seen.push(key);return new Response('cached');}},context={self:{location:{origin:ORIGIN},registration:{scope:ORIGIN+'/kvinta/'},addEventListener:(n,cb)=>listeners[n]=cb},caches:{open:async()=>cache},URL,fetch:()=>{throw Error('Unexpected network');}};vm.runInNewContext(fs.readFileSync(new URL('../dist/sw.js',import.meta.url),'utf8'),context);
 for(const [path,expected] of [['/kvinta/songs/','/kvinta/songs/index.html'],['/kvinta/','/kvinta/index.html']]){let pending;listeners.fetch({request:{url:ORIGIN+path,method:'GET',mode:'navigate'},respondWith:p=>pending=p});await pending;assert.equal(seen.at(-1),ORIGIN+expected);}
 let intercepted=false;listeners.fetch({request:{url:ORIGIN+'/api/songs/search',method:'GET'},respondWith(){intercepted=true;}});assert.equal(intercepted,false);
});
