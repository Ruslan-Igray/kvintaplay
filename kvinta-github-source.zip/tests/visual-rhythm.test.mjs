import test from 'node:test';import assert from 'node:assert/strict';
import {VISUAL_RHYTHMS,VISUAL_RHYTHM_KEY,normalizeVisualRhythm,readVisualRhythm,saveVisualRhythm,createVisualRhythm,visualRhythmFrame,bindRhythmSettingHelp} from '../dist/modules/visual-rhythm.js';
import {PREFERENCES_KEY,readPreferences,savePreferences,appSound} from '../dist/modules/preferences.js';
import {loadState,saveState} from '../dist/modules/storage.js';
import {loadPresentation,savePresentation} from '../dist/modules/rehearsal-presentation.js';
import {sharedSongSettings,mergeSongSettings,quickActions,editorDefaults} from '../features/songs/src/song-settings.js';
function memory(){const data=new Map();return {getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)};}
test('Every visual style and intensity survive repeated loads and additive schema updates',()=>{
 const storage=memory();for(const item of VISUAL_RHYTHMS){assert.equal(saveVisualRhythm({kind:item.id,intensity:37},{storage,win:null}),true);assert.deepEqual(readVisualRhythm(storage),{kind:item.id,intensity:37,saturation:100,color:'auto'});assert.deepEqual(readVisualRhythm(storage),readVisualRhythm(storage));}
 storage.setItem(VISUAL_RHYTHM_KEY,JSON.stringify({kind:'wave',intensity:0,futureSetting:'keep'}));saveVisualRhythm({intensity:82},{storage,win:null});assert.deepEqual(JSON.parse(storage.getItem(VISUAL_RHYTHM_KEY)),{kind:'wave',intensity:82,saturation:100,color:'auto',futureSetting:'keep'});
 storage.setItem(VISUAL_RHYTHM_KEY,'broken');assert.equal(saveVisualRhythm({kind:'bar',intensity:45},{storage,win:null}),true);assert.deepEqual(readVisualRhythm(storage),{kind:'bar',intensity:45,saturation:100,color:'auto'});
 assert.deepEqual(normalizeVisualRhythm({kind:'bad',intensity:-4}),{kind:'edge',intensity:0,saturation:100,color:'auto'});assert.equal(normalizeVisualRhythm({intensity:Infinity}).intensity,70);
 const blocked={getItem(){throw Error();},setItem(){throw Error();}};assert.equal(saveVisualRhythm({kind:'bar'},{storage:blocked,win:null}),false);assert.equal(readVisualRhythm(blocked).kind,'edge');
});
test('Visual strength does not change beat selection, meter or tempo; inversion avoids intermediate low-contrast frames',()=>{
 for(const kind of VISUAL_RHYTHMS.map(x=>x.id))for(const beats of [2,3,4,7])for(const intensity of [0,20,70,100]){
  const f=visualRhythmFrame({kind,intensity},{ordinal:beats+1,beats,bpm:120});assert.equal(f.beat,1);assert.equal(f.beats,beats);assert.equal(f.first,false);assert.equal(f.power,intensity/100);
 }
});
function fixture(){
 let reduced=false;const animations=[],style=()=>({setProperty(){}});
 const node=()=>({style:style(),animate(frames,options){const record={frames,options,cancelled:false,cancel(){this.cancelled=true;}};animations.push(record);return record;}}),nodes=new Map(),layer={...node(),dataset:{},innerHTML:'',setAttribute(){},removeAttribute(key){if(key==='data-active')delete this.dataset.active;if(key==='data-kind')delete this.dataset.kind;},querySelector:s=>{if(!nodes.has(s))nodes.set(s,node());return nodes.get(s);},remove(){}};
 const host={classList:{add(){}},append(el){this.child=el;},ownerDocument:{createElement:()=>layer,defaultView:{matchMedia:()=>({matches:reduced})}}};return {host,layer,nodes,animations,reduce:v=>reduced=v};
}
test('Six live effects use the same meter ordinal and cancel old animation on pause',()=>{
 for(const kind of VISUAL_RHYTHMS.map(x=>x.id)){
  const f=fixture(),effect=createVisualRhythm({host:f.host,getSettings:()=>({kind,intensity:80})});effect.pulse({ordinal:5,beats:3,bpm:120});assert.equal(f.layer.dataset.kind,kind);
  if(kind==='bar'){assert.equal(f.nodes.get('.vr-rail>span').style.width,'33.333333333333336%');assert.equal(f.nodes.get('.vr-rail>span').style.transform,'translateX(200%)');}
  if(kind==='invert')assert.equal(f.animations[0].options.easing,'steps(1,end)');
  effect.clear();assert.ok(f.animations.every(a=>a.cancelled));assert.equal(f.layer.dataset.active,undefined);
  f.reduce(true);const count=f.animations.length;effect.pulse({ordinal:6,beats:3});assert.equal(f.animations.length,count);effect.destroy();
 }
});
test('Zero intensity emits no animation and host changes cancel old presentation',()=>{
 const f=fixture();let settings={kind:'breath',intensity:0};const effect=createVisualRhythm({host:f.host,getSettings:()=>settings});effect.pulse({ordinal:0});assert.equal(f.animations.length,0);settings={kind:'wave',intensity:100};effect.pulse({ordinal:0});assert.equal(f.animations.length,2);const other={classList:{add(){}},append(el){this.child=el;}};effect.setHost(other);assert.equal(other.child,f.layer);assert.ok(f.animations.every(a=>a.cancelled));
});
test('Tool preferences round trip without losing tuner, metronome, chord library or newer fields',()=>{
 const storage=memory(),previous=globalThis.localStorage;globalThis.localStorage=storage;
 try{
  const original={theme:'light',startupTips:false,german:true,notation:'solfege',haptics:false,customFuture:'keep',metronome:{bpm:137,meter:'7/4',subdivision:3,accent:false,volume:42,sound:'bell',visual:'screen',flashFirst:true,newerOption:'keep'},tuner:{tuning:'bass-standard',response:'precise',a4:442,confirmationSound:false},library:{root:'Eb',type:'sus4',position:3,layout:'vertical',autoPlay:true}};
  assert.equal(savePreferences(original,storage),true);const first=loadState();assert.equal(first.metronome.sound,'bell');assert.equal(first.metronome.bpm,137);assert.equal(first.library.type,'sus4');assert.equal(first.tuner.confirmationSound,false);assert.equal(first.tuner.a4,442);
  assert.equal(saveState(first),true);savePreferences({theme:'dark'},storage);const reloaded=loadState();assert.equal(reloaded.theme,'dark');assert.deepEqual(reloaded.metronome,first.metronome);assert.deepEqual(reloaded.tuner,first.tuner);assert.deepEqual(reloaded.library,first.library);assert.equal(readPreferences(storage).customFuture,'keep');assert.equal(readPreferences(storage).metronome.newerOption,'keep');
 }finally{if(previous===undefined)delete globalThis.localStorage;else globalThis.localStorage=previous;}
});
test('Legacy and nested sound preferences agree across tools and songs; changing theme preserves every sound field',()=>{
 const storage=memory();storage.setItem(PREFERENCES_KEY,JSON.stringify({sound:'shh',metronome:{bpm:100}}));assert.equal(appSound(readPreferences(storage)),'shh');savePreferences({theme:'light'},storage);assert.equal(appSound(readPreferences(storage)),'shh');savePreferences({metronome:{sound:'bell'}},storage);assert.equal(appSound(readPreferences(storage)),'bell');assert.equal(readPreferences(storage).metronome.bpm,100);
});
test('Song display/quick settings and rehearsal presentation retain custom values while tempo and meter stay per song',()=>{
 const common={mode:'tempo',speed:1.7,fontSize:26,clicks:true,countIn:false,screenBlink:true,torch:false,fullStart:true,fullBeatDots:false,highlightLines:true,highlightChords:false,quickActions:['torch','clicks','fullStart','screenBlink','highlightLines']},stored=JSON.parse(JSON.stringify(common));
 const next=mergeSongSettings({bpm:83,meter:'3/4',key:7},sharedSongSettings(stored));assert.equal(next.bpm,83);assert.equal(next.meter,'3/4');assert.equal(next.key,7);assert.equal(next.mode,'tempo');assert.equal(next.fontSize,26);assert.deepEqual(quickActions(stored.quickActions),common.quickActions);
 const storage=memory(),presentation={countIn:false,fullscreen:true,screen:true,torch:false,firstOnly:true};savePresentation(presentation,storage);assert.deepEqual(loadPresentation(storage),presentation);assert.equal(editorDefaults({symbol:'Bbsus4',beats:3,color:'red',preset:'solo',cueColor:'blue'}).color,'red');
});

test('Rhythm color and saturation survive partial changes and migrate old preferences without losing intensity',()=>{
 const storage=memory();storage.setItem(VISUAL_RHYTHM_KEY,JSON.stringify({kind:'wash',intensity:93}));
 assert.equal(readVisualRhythm(storage).saturation,100);assert.equal(readVisualRhythm(storage).color,'auto');
 for(const color of ['auto','amber','teal','blue','purple','red']){saveVisualRhythm({color,saturation:165},{storage,win:null});saveVisualRhythm({kind:'edge'},{storage,win:null});const value=readVisualRhythm(storage);assert.equal(value.color,color);assert.equal(value.saturation,165);assert.equal(value.intensity,93);}
 saveVisualRhythm({saturation:0},{storage,win:null});assert.equal(readVisualRhythm(storage).saturation,0);
 assert.equal(normalizeVisualRhythm({saturation:999,color:'unknown'}).saturation,200);assert.equal(normalizeVisualRhythm({color:'unknown'}).color,'auto');
});
test('Tapping slider names opens one explanation; outside taps and Escape dismiss it without closing settings',()=>{
 const node=()=>({handlers:{},attrs:{},hidden:true,textContent:'',addEventListener(type,fn){(this.handlers[type]??=[]).push(fn);},fire(type,event={}){const e={target:this,stopPropagation(){},preventDefault(){this.prevented=true;},...event};for(const fn of this.handlers[type]||[])fn(e);return e;},setAttribute(k,v){this.attrs[k]=v;},getAttribute(k){return this.attrs[k];},contains(target){return target===this;},focus(){this.focused=true;}});
 const strength=node(),saturation=node(),a=node(),b=node(),dialog=node();strength.dataset={rhythmHelp:'strength'};saturation.dataset={rhythmHelp:'saturation'};strength.attrs['aria-controls']='a';saturation.attrs['aria-controls']='b';dialog.querySelectorAll=()=>[strength,saturation];dialog.querySelector=selector=>selector==='#a'?a:b;
 let kind='edge';bindRhythmSettingHelp(dialog,()=>kind);strength.fire('click');assert.equal(a.hidden,false);assert.match(a.textContent,/заметно мерцание/);assert.equal(strength.attrs['aria-expanded'],'true');
 saturation.fire('click');assert.equal(a.hidden,true);assert.equal(b.hidden,false);assert.match(b.textContent,/0% — серый/);assert.match(b.textContent,/Сила эффекта остаётся прежней/);
 dialog.fire('click',{target:{}});assert.equal(b.hidden,true);strength.fire('click');strength.fire('click');assert.equal(a.hidden,true);
 kind='invert';strength.fire('click');assert.match(a.textContent,/длительность светового импульса/);const escape=dialog.fire('cancel');assert.equal(escape.prevented,true);assert.equal(a.hidden,true);assert.equal(strength.focused,true);assert.equal(dialog.fire('cancel').prevented,undefined,'A second Escape can close the native settings dialog');
 saturation.fire('click');assert.match(b.textContent,/ползунок недоступен/);
});
