import test from 'node:test';
import assert from 'node:assert/strict';
import {createTorch,canToggleTorch,TORCH_PULSE_MS,TORCH_TEST_PULSE_MS,torchCadence} from '../dist/modules/metronome-torch.js';
const flush=()=>new Promise(setImmediate);
function camera({cameras=[{id:'main',support:true}],devices=[],apply,settings,wait=async()=>{},verifySettings=true,enumerate,commandTimeout,now}={}){
 const requests=[],tracks=[],videos=[],commands=[],timers=[],delays=[],errors=[];
 const mediaDevices={async getUserMedia(options){requests.push(options);const id=options.video.deviceId?.exact||cameras[0].id,spec=cameras.find(c=>c.id===id);if(!spec)throw Error('unknown camera');
  const track={id,readyState:'live',led:false,played:false,stop(){this.readyState='ended';this.led=false;},getSettings(){return {torch:settings?settings(this):this.led,deviceId:id,facingMode:spec.facing||'environment'};},getCapabilities(){return {torch:this.played?spec.support:false};},getConstraints(){return {deviceId:{exact:id},width:{ideal:640},height:{ideal:480},advanced:[{focusMode:'continuous'},{torch:false}]};},async applyConstraints(value){const enabled=typeof value.torch==='object'?value.torch.exact:typeof value.torch==='boolean'?value.torch:value.advanced.at(-1).torch;commands.push({id,enabled,value});if(apply)return apply(this,value,enabled);this.led=enabled;}};
  const listeners=new Map();track.addEventListener=(name,fn)=>listeners.set(name,fn);track.removeEventListener=(name,fn)=>{if(listeners.get(name)===fn)listeners.delete(name);};track.end=()=>{track.readyState='ended';listeners.get('ended')?.();};tracks.push(track);return {getTracks:()=>[track],getVideoTracks:()=>[track]};},async enumerateDevices(){return enumerate?enumerate():devices;}};
 const control=createTorch({mediaDevices,verifySettings,commandTimeout,now,wait:async ms=>{delays.push(ms);await wait(ms);},makeVideo:()=>{const video={setAttribute(){},async play(){videos.push(this);tracks.at(-1).played=true;},pause(){},remove(){}};return video;},attachVideo(){},later:(fn,ms)=>{const timer={fn,ms,cancelled:false};timers.push(timer);return timer;},cancelLater:timer=>{if(timer)timer.cancelled=true;},onError:error=>errors.push(error)});
 return {control,requests,tracks,videos,commands,timers,delays,errors};
}

test('Torch capability accepts Chromium booleans and controllable sequences only',()=>{
 assert.equal(canToggleTorch(true),true);assert.equal(canToggleTorch([false,true]),true);for(const value of [false,undefined,[],[false],[true],'true'])assert.equal(canToggleTorch(value),false);
});
test('Fast torch cadence follows integer beats and adapts to measured camera latency',async()=>{
 assert.equal(torchCadence(150).stride,1);assert.equal(torchCadence(151).stride,2);assert.equal(torchCadence(240).stride,2);assert.equal(torchCadence(240,180).stride,3);
 let clock=0;const h=camera({now:()=>clock,apply(track,c,enabled){clock+=180;track.led=enabled;}});await h.control.connect();h.commands.length=0;
 for(let ordinal=0;ordinal<8;ordinal++){
  const accepted=h.control.pulse(1000+ordinal*250,{ordinal,bpm:240,beat:ordinal%4});assert.equal(accepted,ordinal%3===0);
  await flush();if(accepted){h.timers.at(-1).fn();await flush();}
 }
 assert.deepEqual(h.commands.map(c=>c.enabled),[true,false,true,false,true,false]);assert.equal(h.tracks[0].led,false);h.control.release();
});
test('Playing does not stall on delayed settings readback and first-only honors odd meters',async()=>{
 let stale=false;const h=camera({settings:track=>stale?false:track.led});await h.control.connect();stale=true;h.delays.length=0;
 assert.equal(h.control.pulse(1000,{bpm:240,ordinal:3,beat:0,firstOnly:true}),true);await flush();h.timers.at(-1).fn();await flush();assert.deepEqual(h.delays,[]);assert.equal(h.errors.length,0);assert.equal(h.control.pulse(1750,{bpm:240,ordinal:6,beat:0,firstOnly:true}),true);await flush();h.timers.at(-1).fn();await flush();h.control.release();
});
test('Connection warms the video then verifies a real on/off cycle and preserves camera constraints',async()=>{
 const h=camera();assert.equal(await h.control.connect(),true);assert.equal(h.control.connected,true);assert.equal(h.requests[0].audio,false);assert.deepEqual(h.commands.map(c=>c.enabled),[false,true,false]);assert.equal(h.tracks[0].led,false);assert.ok(h.delays.includes(TORCH_TEST_PULSE_MS));assert.ok(TORCH_PULSE_MS<=100);
 for(const {value}of h.commands){assert.deepEqual(value.deviceId,{exact:'main'});assert.deepEqual(value.width,{ideal:640});assert.ok(value.advanced.some(v=>v.focusMode==='continuous'));}h.control.release();
});
test('A device ignoring advanced-only commands receives a verified basic torch request',async()=>{
 const h=camera({apply(track,c,enabled){if('torch'in c)track.led=enabled;}});await h.control.connect();h.control.pulse(1000);await flush();assert.equal(h.tracks[0].led,true);h.timers.at(-1).fn();await flush();assert.equal(h.tracks[0].led,false);h.control.release();
});
test('A silently ignored on command never produces a false connected state',async()=>{
 const h=camera({apply(){}});await assert.rejects(()=>h.control.connect(),error=>error.code==='torch-unconfirmed');assert.equal(h.control.connected,false);assert.equal(h.tracks[0].readyState,'ended');assert.equal(h.tracks[0].led,false);
});
test('A logical rear camera without torch is released before trying the main rear camera',async()=>{
 const h=camera({cameras:[{id:'wide',support:false},{id:'main',support:[false,true]},{id:'front',support:true,facing:'user'}],devices:[{kind:'videoinput',deviceId:'front',label:'Front camera'},{kind:'videoinput',deviceId:'main',label:'Back camera main'}],apply(track,c,enabled){if(track.id==='main')assert.equal(h.tracks[0].readyState,'ended');track.led=enabled;}});
 assert.equal(await h.control.connect(),true);assert.equal(h.requests.length,2);assert.equal(h.requests[1].video.deviceId.exact,'main');assert.equal(h.tracks[0].readyState,'ended');assert.ok(h.tracks.every(t=>t.id!=='front'));h.control.release();
});
test('Older implementations can fall back to advanced-only without losing on/off verification',async()=>{
 const h=camera({apply(track,c,enabled){if('torch'in c||'width'in c)throw Object.assign(Error('legacy'),{name:'TypeError'});track.led=enabled;}});assert.equal(await h.control.connect(),true);assert.equal(h.tracks[0].led,false);h.control.pulse(1000);await flush();assert.equal(h.tracks[0].led,true);h.timers.at(-1).fn();await flush();assert.equal(h.tracks[0].led,false);h.control.release();
});
test('Pulse holds the LED, never overlaps, throttles fast beats and ignores stale off timers',async()=>{
 const h=camera();await h.control.connect();h.commands.length=0;h.control.pulse(1000);h.control.pulse(1500);await flush();assert.equal(h.commands.length,1);assert.equal(h.timers.length,1);assert.equal(h.timers[0].ms,TORCH_PULSE_MS);assert.equal(h.tracks[0].led,true);
 h.timers[0].fn();await flush();assert.equal(h.tracks[0].led,false);h.control.pulse(1100);await flush();assert.equal(h.commands.length,2);h.control.pulse(1600);await flush();assert.equal(h.commands.length,3);const late=h.timers.at(-1).fn;h.control.release();late();await flush();assert.equal(h.commands.length,3);assert.equal(h.tracks[0].led,false);
});
test('Immediate stop prevents a queued on command from touching an ended camera',async()=>{
 const h=camera();await h.control.connect();h.commands.length=0;h.control.pulse(1000);h.control.release();await flush();assert.equal(h.commands.length,0);assert.equal(h.tracks[0].led,false);
});
test('Cancellation during warm-up cannot leave the camera connected or light it later',async()=>{
 let finish;const warm=new Promise(resolve=>finish=resolve),h=camera({wait:ms=>ms===100?warm:Promise.resolve()});const pending=h.control.connect();await flush();h.control.release();finish();assert.equal(await pending,false);assert.equal(h.commands.length,0);assert.equal(h.tracks[0].readyState,'ended');
});
test('Cancellation while enumerating alternatives never opens another camera',async()=>{
 let finish;const waiting=new Promise(resolve=>finish=resolve),h=camera({cameras:[{id:'wide',support:false}],enumerate:()=>waiting});const pending=h.control.connect();await flush();h.control.release();finish([{kind:'videoinput',deviceId:'other',label:'Rear camera'}]);assert.equal(await pending,false);assert.equal(h.requests.length,1);
});
test('A hung Android camera command times out and releases the stream',async()=>{
 const h=camera({commandTimeout:5,apply:()=>new Promise(()=>{})});await assert.rejects(()=>h.control.connect(),error=>error.code==='torch-timeout');assert.equal(h.control.connected,false);assert.equal(h.tracks[0].readyState,'ended');
});
test('The manual check emits three held flashes and ends with the LED off',async()=>{
 const h=camera();await h.control.connect();h.commands.length=0;const check=h.control.test();h.control.pulse(1000);assert.equal(await check,true);assert.deepEqual(h.commands.map(c=>c.enabled),[true,false,true,false,true,false]);assert.equal(h.tracks[0].led,false);assert.equal(h.control.testing,false);h.control.release();
});
test('A manual check waits for an in-flight beat and blocks new beat flashes until done',async()=>{
 let released=false;const h=camera({wait:async ms=>{if(ms===50&&!released&&h.timers.length){released=true;h.timers[0].fn();}}});await h.control.connect();h.commands.length=0;h.control.pulse(1000);await flush();const checking=h.control.test();h.control.pulse(1600);assert.equal(await checking,true);assert.deepEqual(h.commands.map(c=>c.enabled),[true,false,true,false,true,false,true,false]);h.control.release();
});
test('WebKit stale settings can use the compatible path without breaking an actual torch',async()=>{
 const h=camera({settings:()=>false,verifySettings:false});assert.equal(await h.control.connect(),true);assert.equal(await h.control.test(),true);assert.equal(h.tracks[0].led,false);h.control.release();
});
test('A pulse failure is surfaced once and releases the camera',async()=>{
 let broken=false;const h=camera({apply(track,c,enabled){if(broken)throw Error('hardware failed');track.led=enabled;}});await h.control.connect();broken=true;h.control.pulse(1000);await flush();assert.equal(h.errors.length,1);assert.equal(h.control.connected,false);assert.equal(h.tracks[0].readyState,'ended');
});
test('A camera ending externally reports failure rather than silently stopping flashes',async()=>{
 const h=camera();await h.control.connect();h.tracks[0].end();assert.equal(h.control.connected,false);assert.equal(h.errors.length,1);assert.equal(h.errors[0].code,'torch-ended');assert.equal(h.tracks[0].led,false);
});
