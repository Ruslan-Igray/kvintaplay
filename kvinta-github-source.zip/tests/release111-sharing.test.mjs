import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createSetLink,readSetLink} from '../dist/modules/composition-link.js';
import {newSet,normalizeDraft,createCompositionStore,SET_TYPES} from '../dist/modules/composition-model.js';
import {scoreScrollDuration,createScoreScroll} from '../dist/modules/score-scroll.js';
import {setupSwipeDelete} from '../dist/modules/swipe-delete.js';
import {createRehearsalEffects} from '../dist/modules/rehearsal-effects.js';
const token=fs.readFileSync(new URL('fixtures/shared-user-v2.txt',import.meta.url),'utf8').trim();
const music=s=>[s.name,s.keyIndex,s.mode,s.rehearsal,s.sections?.map(p=>p.name),s.chords.map(c=>[c.root,c.type,c.bass,c.beats,s.sections?.findIndex(p=>p.id===c.sectionId)]),s.playOrder?.map(id=>s.sections.findIndex(p=>p.id===id))];
test('The exact reported 33-chord v2 link opens, imports independently and becomes a much shorter v4 link',()=>{
 const s=readSetLink('#set='+token);assert.equal(s.chords.length,33);assert.deepEqual(s.sections.map(p=>p.name),['Куплет 1','Припев 1','Проигрыш 1']);assert.equal(s.rehearsal.bpm,228);assert.equal(s.rehearsal.meter,'7/4');assert.ok(s.chords.some(c=>c.root==='F##'));
 const url=new URL(createSetLink(s,'https://ruslan-igray.github.io/kvinta/'));assert.ok(url.hash.length<token.length*.3);assert.deepEqual(music(readSetLink(url.hash)),music(s));
 const data=new Map(),store=createCompositionStore({storage:{getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)}});store.saveDraft(newSet());assert.equal(store.save(s,{asNew:true,keepDraft:true}).ok,true);assert.equal(store.list()[0].chords.length,33);assert.equal(store.draft.chords.length,0);
 assert.deepEqual(music(readSetLink('#set='+encodeURIComponent(token))),music(s));assert.deepEqual(music(readSetLink('#set='+token.slice(0,30)+'\n'+token.slice(30))),music(s));
});
test('Compact links preserve every note spelling, all durations, Unicode, arrangement and maximum set size',()=>{
 const notes=Array.from('CDEFGAB').flatMap(n=>['bb','b','','#','##'].map(a=>n+a));
 for(const type of SET_TYPES){const s=normalizeDraft({...newSet(),name:'🎸'.repeat(40),keyIndex:11,mode:'minor',rehearsal:{bpm:240,meter:'12/8',loop:false},sections:[{id:'a',name:'Куплет'},{id:'b',name:'Припев'}],playOrder:['a','b','a'],chords:Array.from({length:128},(_,i)=>({root:notes[i%35],bass:notes[(i+7)%35],type:type.id,beats:i%32+1,sectionId:i<64?'a':'b'}))});assert.deepEqual(music(readSetLink(new URL(createSetLink(s,'https://example.test/')).hash)),music(s));}
});
test('Compact-link checksum rejects changed bytes, truncation and appended data before saving anything',()=>{
 const hash=new URL(createSetLink(readSetLink('#set='+token),'https://example.test')).hash;const bytes=Buffer.from(hash.slice(8),'base64url');
 for(let i=0;i<bytes.length;i++){const b=Buffer.from(bytes);b[i]^=1;assert.throws(()=>readSetLink('#set=v4.'+b.toString('base64url')),/повреждена/);}
 for(const b of [bytes.subarray(0,-1),Buffer.concat([bytes,Buffer.from([0])])])assert.throws(()=>readSetLink('#set=v4.'+b.toString('base64url')),/повреждена/);
});
test('Score scrolling follows tempo, interpolates without jumps, clamps bounds, cancels and honors reduced motion',()=>{
 assert.ok(scoreScrollDuration(60)>scoreScrollDuration(180));let time=0,raf;const el={scrollTop:0,scrollHeight:1000,clientHeight:400},control=createScoreScroll({element:el,now:()=>time,request:fn=>{raf=fn;return 1;},cancel:()=>{raf=null;}});control.to(500,120);assert.equal(el.scrollTop,0);time=500;raf();assert.equal(el.scrollTop,250);time=1000;raf();assert.equal(el.scrollTop,500);control.to(900,120,true);assert.equal(el.scrollTop,600);control.to(0,60);control.stop();assert.equal(raf,null);assert.equal(el.scrollTop,600);
});
test('Right swipe opens sharing only after a deliberate threshold, while left delete and cancellation remain independent',()=>{
 let shares=0,deletes=0;const make=()=>({style:{},children:[],events:{},append(...x){this.children.push(...x);},prepend(x){this.children.unshift(x);},setAttribute(){},classList:{toggle(){}},addEventListener(k,f){(this.events[k]??=[]).push(f);}}),row=make(),content=make();row.ownerDocument={createElement:make};row.getBoundingClientRect=()=>({width:328});row.setPointerCapture=()=>{};const controller=setupSwipeDelete({row,content,onDelete:()=>deletes++,onShare:()=>shares++}),fire=(type,x,y=0)=>row.events[type].forEach(f=>f({button:0,pointerId:1,clientX:x,clientY:y,preventDefault(){}}));
 fire('pointerdown',30);fire('pointermove',100);fire('pointerup',100);assert.equal(shares,0);fire('pointerdown',30);fire('pointermove',150);fire('pointerup',150);assert.equal(shares,1);assert.equal(deletes,0);fire('pointerdown',30);fire('pointermove',160);fire('pointercancel',160);assert.equal(shares,1);fire('pointerdown',300);fire('pointermove',60);fire('pointerup',60);assert.equal(deletes,1);controller.cancel();
});
test('Rehearsal screen and torch run together, throttle fast beats, honor reduced motion and release camera on stop',async()=>{
 const ids=new Map();let flashes=0,pulses=0,releases=0,connected=false,reduced=false,permissionCalls=0;
 const element=()=>({events:{},style:{},classList:{add(){}},append(...items){items.forEach(x=>{x.parentElement=this;});},setAttribute(){},remove(){},addEventListener(k,f){(this.events[k]??=[]).push(f);},showModal(){this.open=true;},close(){this.open=false;},animate(){flashes++;return {cancel(){}};}});
 for(const id of ['rehearsal-connect-camera','rehearsal-camera-status','rehearsal-camera-options','rehearsal-torch'])ids.set('#'+id,element());
 const doc={createElement:element,querySelector:()=>null,defaultView:{matchMedia:()=>({matches:reduced})}},mount=element();mount.ownerDocument=doc;mount.querySelector=s=>ids.get(s);const p={screen:true,torch:true,firstOnly:false};
 const fx=createRehearsalEffects({mount,getPresentation:()=>p,getBpm:()=>240,rhythmFactory:()=>({clear(){},setHost(){},pulse(){flashes++;}}),torchFactory:()=>({available:true,get connected(){return connected;},async connect(){permissionCalls++;connected=true;return true;},pulse(){pulses++;},release(){connected=false;releases++;}})});
 assert.equal(permissionCalls,0);await ids.get('#rehearsal-connect-camera').events.click[0]();assert.equal(permissionCalls,1);
 fx.paint({ordinal:0,beatInBar:0});fx.paint({ordinal:0,beatInBar:0});fx.paint({ordinal:1,beatInBar:1});assert.equal(pulses,2);assert.equal(flashes,1);fx.paint({ordinal:2,beatInBar:2});assert.equal(pulses,3);assert.equal(flashes,2);
 reduced=true;fx.paint({ordinal:4,beatInBar:0});assert.equal(pulses,4);assert.equal(flashes,2);fx.stop();assert.equal(connected,false);assert.equal(releases,1);
 reduced=false;fx.paint({ordinal:6,beatInBar:2});assert.equal(flashes,3);assert.equal(pulses,4);fx.paint(null);assert.equal(releases,2);
});
