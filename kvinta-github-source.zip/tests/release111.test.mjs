import test from 'node:test';
import assert from 'node:assert/strict';
import {newSet,addSetChord,SET_TYPES,suggestedChords,draftSignature} from '../dist/modules/composition-model.js';
import {contextChords} from '../dist/modules/context-chords.js';
import {dropTargetAt} from '../dist/modules/composition-drag.js';
import {createDrumPicker} from '../dist/modules/drum-picker.js';
function song(){let s=newSet();for(const [root,type] of [['C','major'],['A','minor'],['F','major'],['G','7']])s=addSetChord(s,{root,type});return s;}
test('Selecting a different chord updates recommendations immediately without changing the composition or key',()=>{
 const s=song(),before=draftSignature(s),a=contextChords(s,s.chords[0].id),b=contextChords(s,s.chords[2].id);assert.notDeepEqual(a,b);assert.equal(draftSignature(s),before);assert.equal(s.keyIndex,0);assert.deepEqual(contextChords(s,null),suggestedChords(s));
 assert.equal(contextChords(s,s.chords[3].id)[0].root,'C');assert.equal(contextChords(s,s.chords[3].id)[0].type,'major');
});
test('All chord qualities, enharmonic roots and out-of-key selections yield bounded valid draggable candidates',()=>{
 for(const root of ['C#','Bb','F##','Gb'])for(const type of SET_TYPES){const s=addSetChord(song(),{root,type:type.id}),r=contextChords(s,s.chords.at(-1).id);assert.ok(r.length>=6&&r.length<=7);assert.equal(new Set(r.map(c=>c.root+':'+c.type)).size,r.length);for(const c of r){assert.match(c.root,/^[A-G](?:#{1,2}|b{1,2})?$/);assert.ok(SET_TYPES.some(t=>t.id===c.type));assert.ok(addSetChord(s,c));}}
});
test('Insertion zones stay usable beside narrow cards and between wrapped rows while centres still replace',()=>{
 const bounds={left:0,right:320,top:0,bottom:200},rects=[{index:0,left:8,right:76,top:8,bottom:66},{index:1,left:82,right:150,top:8,bottom:66},{index:2,left:8,right:76,top:72,bottom:130}];const hit=(x,y)=>dropTargetAt({x,y,bounds,rects});assert.deepEqual(hit(60,38),{kind:'insert',index:1});assert.deepEqual(hit(79,38),{kind:'insert',index:1});assert.deepEqual(hit(40,38),{kind:'replace',index:0});assert.deepEqual(hit(40,69),{kind:'insert',index:2});
});
test('Formatted selection wheels announce their labels and release global listeners when rebuilt',()=>{
 const globals=new Map(),make=()=>({children:[],attrs:{},style:{},events:{},classList:{toggle(){}},append(x){this.children.push(x);},setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,v){this.events[k]=v;}}),view={addEventListener(k,v){globals.set(k,v);},removeEventListener(k,v){if(globals.get(k)===v)globals.delete(k);},clearTimeout(){},setTimeout(){return 1;}},doc={defaultView:view,createElement:make},mount=make();mount.ownerDocument=doc;let value;
 const picker=createDrumPicker({mount,values:['major','minor'],formatValue:v=>v==='major'?'Мажор':'Минор',label:'Тип',onChange:v=>value=v});picker.set('major');assert.equal(mount.attrs['aria-valuetext'],'Мажор');mount.events.keydown({key:'ArrowDown',preventDefault(){}});assert.equal(value,'minor');assert.equal(mount.attrs['aria-valuetext'],'Минор');assert.equal(globals.size,3);picker.destroy();assert.equal(globals.size,0);
});
