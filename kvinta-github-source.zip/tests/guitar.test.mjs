import test from 'node:test';
import assert from 'node:assert/strict';
import { ROOTS,TYPES,MAX_FRET,voicingsFor,soundingNotes,chordNotes,TUNING } from '../dist/modules/guitar.js';
import { mod,pitchClass } from '../dist/modules/theory.js';

test('All 96 chords retain valid fingerings entirely within the first 12 frets', () => {
  let count = 0;
  for (const root of ROOTS) for (const type of TYPES) {
    const shapes = voicingsFor(root,type.id), target = type.intervals.map(i => mod(pitchClass(root)+i));
    assert.ok(shapes.length >= 1, `${root}${type.suffix}: no variants within 12 frets`);
    for (const shape of shapes) {
      count++;
      assert.equal(shape.frets.length,6);
      const notes = soundingNotes(shape).filter(n=>n!==null).map(n=>mod(n));
      assert.ok(notes.length >= 3);
      assert.ok(notes.every(n=>target.includes(n)),`${root}${type.suffix} ${shape.id}: foreign tone`);
      const required = shape.omitFifth ? target.filter(n=>n!==mod(pitchClass(root)+7)) : target;
      assert.ok(required.every(n=>notes.includes(n)),`${root}${type.suffix} ${shape.id}: missing chord tone`);
      assert.equal(notes[0],pitchClass(root),`${root}${type.suffix} ${shape.id}: unexpected inversion`);
      assert.ok(shape.frets.every(f=>Number.isInteger(f)&&f>=-1&&f<=12));
      assert.ok(shape.start>=1&&shape.start+4<=12,`${shape.id}: diagram exceeds 12th fret`);
      const pressed=shape.frets.filter(f=>f>0);
      assert.ok(Math.max(...pressed)-Math.min(...pressed)<=3,`${shape.id}: wide stretch`);
      for(let i=0;i<6;i++) {
        assert.ok(shape.frets[i]<=0?shape.fingers[i]===0:shape.fingers[i]>=1&&shape.fingers[i]<=4,`${shape.id}: finger invalid`);
      }
      for(const bar of shape.barres) for(let i=bar.from;i<=bar.to;i++) {
        assert.ok(shape.frets[i]>=bar.fret || shape.frets[i]===-1,`${shape.id}: barre blocks a lower note`);
      }
      for (let finger=1;finger<=4;finger++) {
        const strings=shape.fingers.flatMap((f,i)=>f===finger?[i]:[]);
        if(strings.length>1) assert.ok(shape.barres.some(b=>b.finger===finger&&b.from<=Math.min(...strings)&&b.to>=Math.max(...strings)&&strings.every(i=>shape.frets[i]===b.fret)),`${shape.id}: same finger used without barre`);
      }
    }
  }
  console.log(`Validated ${count} fingerings in standard tuning ${TUNING.join(',')}`);
});
test('Positions extending past XII are removed even when their first fret is below XII', () => {
  assert.equal(MAX_FRET,12);
  const c=voicingsFor('C','major');
  assert.ok(!c.some(s=>s.id==='-1,-1,10,12,13,12'));
  assert.ok(!c.some(s=>s.id==='-1,15,17,17,17,15'));
  assert.ok(c.some(s=>s.id==='8,10,10,9,8,8'));
});
test('Well-known open and barre shapes stay correct', () => {
  for(const [root,type,frets] of [['C','major',[-1,3,2,0,1,0]],['C','major',[-1,3,5,5,5,3]],['C','major',[8,10,10,9,8,8]],['A','minor',[-1,0,2,2,1,0]],['F','major',[1,3,3,2,1,1]],['D','7',[-1,-1,0,2,1,2]]]) {
    assert.ok(voicingsFor(root,type).some(s=>s.id===frets.join(',')),`${root} ${type}`);
  }
});
test('Chord spelling preserves sevenths, suspended tones and theoretical accidentals', () => {
  assert.deepEqual(chordNotes('C','maj7'),['C','E','G','B']);
  assert.deepEqual(chordNotes('F#','major'),['F#','A#','C#']);
  assert.deepEqual(chordNotes('Db','minor'),['Db','Fb','Ab']);
  assert.deepEqual(chordNotes('B','dim'),['B','D','F']);
  for(const root of ROOTS)for(const type of TYPES)assert.deepEqual(chordNotes(root,type.id).map(pitchClass),type.intervals.map(i=>mod(pitchClass(root)+i)));
});
