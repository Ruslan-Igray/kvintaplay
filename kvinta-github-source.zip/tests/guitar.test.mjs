import test from 'node:test';
import assert from 'node:assert/strict';
import { ROOTS,TYPES,MAX_FRET,voicingsFor,soundingNotes,chordNotes,TUNING } from '../dist/modules/guitar.js';
import { mod,pitchClass } from '../dist/modules/theory.js';
import {diagram} from '../dist/modules/chord-diagram.js';
import {loadState,saveState} from '../dist/modules/storage.js';

test('All 96 chords retain valid fingerings entirely within the first 12 frets', () => {
  let count = 0;
  for (const root of ROOTS) for (const type of TYPES) {
    const shapes = voicingsFor(root,type.id), target = type.intervals.map(i => mod(pitchClass(root)+i));
    assert.ok(shapes.length >= 1, `${root}${type.suffix}: no variants within 12 frets`);
    for (const shape of shapes) {
      count++;
      assert.equal(shape.frets.length,6);
      const notes = soundingNotes(shape).filter(n=>n!==null).map(n=>mod(n));
      assert.ok(notes.length >= 3);
      assert.ok(notes.every(n=>target.includes(n)),`${root}${type.suffix} ${shape.id}: foreign tone`);
      const required = shape.omitFifth ? target.filter(n=>n!==mod(pitchClass(root)+7)) : target;
      assert.ok(required.every(n=>notes.includes(n)),`${root}${type.suffix} ${shape.id}: missing chord tone`);
      assert.equal(notes[0],pitchClass(root),`${root}${type.suffix} ${shape.id}: unexpected inversion`);
      assert.ok(shape.frets.every(f=>Number.isInteger(f)&&f>=-1&&f<=12));
      assert.ok(shape.start>=1&&shape.start+4<=12,`${shape.id}: diagram exceeds 12th fret`);
      const pressed=shape.frets.filter(f=>f>0);
      assert.ok(Math.max(...pressed)-Math.min(...pressed)<=3,`${shape.id}: wide stretch`);
      for(let i=0;i<6;i++) {
        assert.ok(shape.frets[i]<=0?shape.fingers[i]===0:shape.fingers[i]>=1&&shape.fingers[i]<=4,`${shape.id}: finger invalid`);
      }
      for(const bar of shape.barres) for(let i=bar.from;i<=bar.to;i++) {
        assert.ok(shape.frets[i]>=bar.fret || shape.frets[i]===-1,`${shape.id}: barre blocks a lower note`);
      }
      for (let finger=1;finger<=4;finger++) {
        const strings=shape.fingers.flatMap((f,i)=>f===finger?[i]:[]);
        if(strings.length>1) assert.ok(shape.barres.some(b=>b.finger===finger&&b.from<=Math.min(...strings)&&b.to>=Math.max(...strings)&&strings.every(i=>shape.frets[i]===b.fret)),`${shape.id}: same finger used without barre`);
      }
    }
  }
  console.log(`Validated ${count} fingerings in standard tuning ${TUNING.join(',')}`);
});
test('Positions extending past XII are removed even when their first fret is below XII', () => {
  assert.equal(MAX_FRET,12);
  const c=voicingsFor('C','major');
  assert.ok(!c.some(s=>s.id==='-1,-1,10,12,13,12'));
  assert.ok(!c.some(s=>s.id==='-1,15,17,17,17,15'));
  assert.ok(c.some(s=>s.id==='8,10,10,9,8,8'));
});
test('Well-known open and barre shapes stay correct', () => {
  for(const [root,type,frets] of [['C','major',[-1,3,2,0,1,0]],['C','major',[-1,3,5,5,5,3]],['C','major',[8,10,10,9,8,8]],['A','minor',[-1,0,2,2,1,0]],['F','major',[1,3,3,2,1,1]],['D','7',[-1,-1,0,2,1,2]]]) {
    assert.ok(voicingsFor(root,type).some(s=>s.id===frets.join(',')),`${root} ${type}`);
  }
});
test('Chord spelling preserves sevenths, suspended tones and theoretical accidentals', () => {
  assert.deepEqual(chordNotes('C','maj7'),['C','E','G','B']);
  assert.deepEqual(chordNotes('F#','major'),['F#','A#','C#']);
  assert.deepEqual(chordNotes('Db','minor'),['Db','Fb','Ab']);
  assert.deepEqual(chordNotes('B','dim'),['B','D','F']);
  for(const root of ROOTS)for(const type of TYPES)assert.deepEqual(chordNotes(root,type.id).map(pitchClass),type.intervals.map(i=>mod(pitchClass(root)+i)));
});

test('Horizontal layouts align notes, frets, open strings and barres without flipping text',()=>{
  const render=(root,frets,layout)=>diagram(voicingsFor(root,'major').find(s=>s.id===frets),root,chordNotes(root,'major'),n=>n,layout);
  for(const layout of ['horizontal','horizontal-first-top','horizontal-nut-right']){
    const right=layout==='horizontal-nut-right',top=layout==='horizontal-first-top';
    const x=value=>right?390-value:value, y=string=>top?51+48*(string-1):51+48*(6-string);
    const open=render('C','-1,3,2,0,1,0',layout);
    assert.ok(open.includes(`data-layout="${layout}"`));
    assert.ok(open.includes(`class="neck-fret neck-nut" d="M${x(56)} 35V309"`));
    assert.ok(open.includes(`class="muted-mark" d="M${x(44)-5} ${y(6)-5}l10 10`));
    assert.ok(open.includes(`class="open-mark" cx="${x(43)}" cy="${y(1)}"`));
    assert.ok(open.includes(`data-string="5" data-fret="3" cx="${x(191)}" cy="${y(5)}"`));
    assert.ok(open.includes(`class="sounding-note root-label" x="${x(361)}" y="${y(5)}">C</text>`));
    assert.ok(open.includes(`class="string-number" x="${x(8)}" y="${y(1)}">1</text>`));
    assert.doesNotMatch(open,/transform=/);
    const high=render('C','8,10,10,9,8,8',layout);
    const frets=[...high.matchAll(/class="fret-number" x="(\d+)" y="333">(\d+)/g)];
    assert.deepEqual(frets.map(m=>Number(m[2])),[8,9,10,11,12]);
    assert.deepEqual(frets.map(m=>Number(m[1])),[83,137,191,245,299].map(x));
    assert.ok(high.includes(`class="neck-inlay" cx="${x(299)}" cy="123"`));
    assert.ok(high.includes(`class="neck-barre" d="M${x(83)} ${y(6)}V${y(1)}"`));
  }
});

test('All board views survive reload; unknown or missing legacy preferences select the original view',()=>{
  const before=globalThis.localStorage;
  let raw='{}';globalThis.localStorage={getItem:()=>raw,setItem:(_,v)=>{raw=v;}};
  try{
    assert.equal(loadState().library.layout,'horizontal');
    for(const layout of ['vertical','horizontal','horizontal-first-top','horizontal-nut-right','obsolete']){
      const state=loadState();state.library.layout=layout;saveState(state);
      assert.equal(loadState().library.layout,layout==='obsolete'?'horizontal':layout);
    }
  }finally{if(before===undefined)delete globalThis.localStorage;else globalThis.localStorage=before;}
});
