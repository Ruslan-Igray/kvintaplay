import test from 'node:test';
import assert from 'node:assert/strict';
import {newSet,addSetChord,draftSignature,suggestedChords,transposeSet} from '../dist/modules/composition-model.js';
import {addSection} from '../dist/modules/composition-sections.js';
import {setPlayOrder} from '../dist/modules/arrangement.js';
import {rehearsalSelection,makeRehearsalPlan,rehearsalFrame} from '../dist/modules/rehearsal-model.js';
import {scoreFollowTarget,scoreScrollDuration,createScoreScroll} from '../dist/modules/score-scroll.js';
import {createRehearsalFocus} from '../dist/modules/rehearsal-focus.js';
function song(){let s=addSetChord(newSet(),{root:'A',type:'minor',beats:4}),p=addSection(s,'Припев');s=addSetChord(p.set,{root:'C',type:'major',beats:2,sectionId:p.id});s=addSetChord(s,{root:'G',type:'7',beats:6,sectionId:p.id});s=setPlayOrder(s,['main',p.id,'main',p.id]);return {s,id:p.id};}
test('A selected rehearsal part isolates its own chords and durations without modifying the song or saved arrangement',()=>{
 const {s,id}=song(),before=draftSignature(s),single=rehearsalSelection(s,id);assert.equal(rehearsalSelection(s,''),s);assert.equal(rehearsalSelection(s,'missing'),s);assert.equal(draftSignature(s),before);assert.deepEqual(single.chords.map(c=>[c.root,c.beats]),[['C',2],['G',6]]);assert.deepEqual(single.playOrder,[id]);assert.equal(single.rehearsal,s.rehearsal);assert.equal(single.sections.length,1);assert.deepEqual(s.playOrder,['main',id,'main',id]);
});
test('Part rehearsal loops only the selected part; full-song rehearsal still follows repeated arrangement occurrences',()=>{
 const {s,id}=song(),part=makeRehearsalPlan(rehearsalSelection(s,id)),all=makeRehearsalPlan(s);assert.equal(part.total,8);assert.equal(rehearsalFrame(part,7).chord.root,'G');assert.equal(rehearsalFrame(part,8).chord.root,'C');assert.equal(rehearsalFrame(part,8).cycle,2);assert.equal(all.total,24);assert.deepEqual(all.chords.map(c=>c.root),['A','C','G','A','C','G']);part.settings.loop=false;assert.equal(rehearsalFrame(part,8).ended,true);
});
test('Following a new part aligns its heading above the first chord, while later rows do not jump back to the old heading',()=>{
 const base={scrollTop:200,viewTop:10,viewBottom:650,headingTop:620,tileTop:680,tileBottom:764,padding:20};assert.equal(scoreFollowTarget({...base,partChanged:true}),790);assert.equal(scoreFollowTarget({...base,headingTop:-500,tileTop:100,tileBottom:184,partChanged:false}),null);assert.equal(scoreFollowTarget({...base,headingTop:-500,partChanged:false}),850);assert.equal(scoreFollowTarget({...base,headingTop:30,tileTop:90,tileBottom:174,partChanged:true}),null);
});
test('Fast large score transitions retain readable duration instead of racing a long distance in half a second',()=>{
 assert.ok(scoreScrollDuration(240,1000)>=1300);assert.ok(scoreScrollDuration(60,500)>scoreScrollDuration(180,500));assert.ok(scoreScrollDuration(240,500)>scoreScrollDuration(240,100));assert.ok(scoreScrollDuration(20,10000)<=2000);
});
test('Subpixel differences at a part boundary do not restart an in-flight scroll and delay the current chord',()=>{
 let time=0,raf;const element={scrollTop:0,scrollHeight:2000,clientHeight:640},control=createScoreScroll({element,now:()=>time,request:fn=>{raf=fn;return 1;},cancel(){}});control.to(500,120);time=500;raf();assert.equal(element.scrollTop,250);control.to(500.2,120);time=1000;raf();assert.equal(element.scrollTop,500);
});
test('The restored tonal palette keeps the seven diatonic chords for every transposed key',()=>{
 const {s}=song();assert.deepEqual(suggestedChords(s).map(c=>c.root),['C','D','E','F','G','A','B']);for(let key=0;key<12;key++){const moved=transposeSet(s,key),a=suggestedChords(moved);assert.equal(a.length,7);assert.equal(new Set(a.map(c=>c.root)).size,7);assert.deepEqual(suggestedChords({...moved,chords:[]}),a);}
});
test('A long looping score continues into the next pass with at most two copies; a fitting score never duplicates',()=>{
 function harness(long){
  let doc;class El{constructor(tag){this.tag=tag;this.children=[];this.dataset={};this.style={setProperty(){}};this.attrs={};this.className='';this.added=new Set();this.classList={add:n=>this.added.add(n),remove:n=>this.added.delete(n),toggle:(n,on)=>on?this.added.add(n):this.added.delete(n)};this.scrollTop=0;this.clientHeight=640;this.scrollHeight=long?2000:640;}
   get ownerDocument(){return doc;}append(...nodes){for(const n of nodes){n.parentElement=this;this.children.push(n);}}replaceChildren(...nodes){this.children=[];this.append(...nodes);}remove(){const p=this.parentElement;if(p)p.children=p.children.filter(n=>n!==this);}setAttribute(k,v){this.attrs[k]=v;}removeAttribute(k){delete this.attrs[k];}addEventListener(){}showModal(){this.open=true;}focus(){}close(){this.open=false;}matches(s){return s.startsWith('.')?this.className.split(' ').includes(s.slice(1)):this.tag===s;}querySelector(s){for(const c of this.children){if(c.matches(s))return c;const result=c.querySelector(s);if(result)return result;}return null;}closest(s){return this.matches(s)?this:this.parentElement?.closest(s);}getBoundingClientRect(){return this.tag==='h2'?{top:20,bottom:59}:{top:100,bottom:this.className==='focus-score'?740:184};}}
  doc={createElement:tag=>new El(tag),defaultView:{matchMedia:()=>({matches:true}),getComputedStyle:()=>({paddingTop:'20px'}),requestAnimationFrame(){return 1;},cancelAnimationFrame(){},performance:{now:()=>0}}};const mount=new El('main'),focus=createRehearsalFocus({mount,nameOf:c=>c.root,onToggle(){}});return {mount,focus};
 }
 const {s}=song(),plan=makeRehearsalPlan(s),last=plan.chords.at(-1).start;
 for(const long of [false,true]){const {mount,focus}=harness(long);focus.open(plan);focus.paint(rehearsalFrame(plan,last));const score=mount.querySelector('.focus-score');assert.equal(score.children.length,long?2:1);focus.paint(rehearsalFrame(plan,plan.total));assert.equal(score.children.filter(n=>n.querySelector('.focus-chord')?.attrs['aria-current']==='step').length,1);focus.paint(rehearsalFrame(plan,plan.total+last));assert.equal(score.children.length,long?2:1);if(long)assert.deepEqual(score.children.map(n=>n.dataset.focusCycle),[2,3]);}
});
