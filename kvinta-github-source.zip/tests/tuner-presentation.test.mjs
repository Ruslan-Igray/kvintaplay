import test from 'node:test';import assert from 'node:assert/strict';
import {createTunerPresentation,tunerHistoryPath,tunerProximity,tunerNoteColor} from '../dist/modules/tuner-presentation.js';
import {createPitchTracker,frequencyFor,normalizeTuner} from '../dist/modules/tuner-pitch.js';
const target={id:6,midi:40,note:'E'},model=(cents=0)=>({target,cents,frequency:frequencyFor(40)*2**(cents/1200),note:{note:'E',midi:40},tuned:Math.abs(cents)<=8,stable:true,uncertain:false,ambiguous:false}),measure=cents=>({frequency:frequencyFor(40)*2**(cents/1200),clarity:.99,rms:.02,clipped:false});
test('The last trustworthy pluck stays readable for four seconds and never remains a live confirmation',()=>{
 const view=createTunerPresentation();view.update(model(2),1000);let frame=view.update(null,1700);assert.equal(frame.phase,'last');assert.equal(frame.model.note.note,'E');assert.equal(frame.model.resultTuned,true);assert.equal(frame.model.tuned,false);assert.equal(frame.model.stable,false);assert.equal(frame.model.remembered,true);assert.equal(view.update(null,4999).phase,'last');assert.equal(view.update(null,5000).model,null);
});
test('Fresh uncertain estimates remain visible without refreshing an old confirmed success',()=>{
 const view=createTunerPresentation();view.update(model(),0);for(let t=200;t<4000;t+=100){const frame=view.update({...model(49),uncertain:true},t);assert.equal(frame.model.cents,49);assert.equal(frame.phase,'estimate');assert.equal(frame.model.tuned,false);assert.equal(frame.model.stable,false);}const held=view.update(null,4300);assert.equal(held.model.provisional,true);assert.equal(held.model.resultTuned,false);assert.equal(held.phase,'last');assert.equal(view.update({ ...model(),stale:true},7900).model,null);
});

test('Real detuning is not hidden; a confirmed next string clears the old history and resets the indicator',()=>{
 const view=createTunerPresentation();view.update(model(),0);let frame=view.update(model(32),40);assert.equal(frame.model.cents,32);assert.ok(frame.position>0&&frame.position<32);assert.equal(frame.model.tuned,false);frame=view.update({...model(-18),target:{id:5,midi:45,note:'A'},note:{note:'A',midi:45}},80);assert.equal(frame.points.length,1);assert.equal(frame.position,-18);assert.equal(frame.model.note.note,'A');view.reset();assert.equal(view.update(null,90).model,null);
});
test('The pitch trace has bounded size and explicit breaks across missing measurements instead of invented sound',()=>{
 const view=createTunerPresentation();let frame;for(let t=0;t<12000;t+=40)frame=view.update(model(Math.sin(t/100)),t);assert.ok(frame.points.length<=101);const path=tunerHistoryPath([{at:0,cents:-500},{at:40,cents:500},{at:800,cents:0}],800);assert.equal((path.match(/M/g)||[]).length,2);assert.ok(path.includes('2.00'));assert.ok(path.includes('98.00'));assert.equal(tunerHistoryPath([{at:0,cents:0}],5000),'');
});
test('Isolated edge and octave errors do not reset a settled pitch in either accuracy mode',()=>{
 for(const response of ['normal','precise']){const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response});let current;for(let t=0;t<=600;t+=40)current=tracker.update(measure(0),t,settings);assert.ok(current.tuned);for(const [offset,cents] of [[40,110],[120,-140],[200,1200]]){assert.equal(tracker.update(measure(cents),600+offset,settings),null);current=tracker.update(measure(0),600+offset+40,settings);assert.ok(current);assert.ok(Math.abs(current.cents)<1);}}
});
test('Sustained pitch changes and a gradual tuning movement still reach their real values promptly',()=>{
 for(const response of ['normal','precise']){const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response});let current;for(let t=0;t<=600;t+=40)current=tracker.update(measure(0),t,settings);for(let t=640;t<=1040;t+=40)current=tracker.update(measure(85),t,settings);assert.ok(current);assert.ok(Math.abs(current.cents-85)<1);assert.equal(current.tuned,false);for(let i=0;i<50;i++)current=tracker.update(measure(85-i*2),1080+i*40,settings);for(let i=0;i<20;i++)current=tracker.update(measure(-13),3080+i*40,settings);assert.ok(Math.abs(current.cents+13)<2);assert.equal(current.tuned,false);}
});


test('The reported E/A/D regression is reproduced at moderate confidence and all three notes now remain live',()=>{
 for(const [id,midi] of [[6,40],[5,45],[4,50]]){const tracker=createPitchTracker(),display=createTunerPresentation(),settings=normalizeTuner({string:id});let view;for(let t=0;t<=1200;t+=40)view=display.update(tracker.update({frequency:frequencyFor(midi),clarity:.85,rms:.0002,clipped:false},t,settings),t);assert.equal(view.model.target.id,id);assert.equal(view.model.note.midi,midi);assert.equal(view.phase,'estimate');assert.equal(view.model.tuned,false);assert.equal(view.model.stable,false);assert.equal(view.model.remembered,undefined);}
});
test('A reliable matching pluck can be recalled after fading, while a newly heard different string cannot recall its old green note',()=>{
 const view=createTunerPresentation();view.update(model(),0);view.update({...model(3),uncertain:true},200);const remembered=view.update(null,600);assert.equal(remembered.model.resultTuned,true);assert.equal(remembered.model.cents,0);view.update({...model(0),target:{id:5,midi:45,note:'A'},note:{note:'A',midi:45},uncertain:true},700);const next=view.update(null,1000);assert.equal(next.model.note.note,'A');assert.equal(next.model.provisional,true);assert.equal(next.model.resultTuned,false);
});
test('Note colour approaches green with pitch accuracy but uncertain, ambiguous or octave estimates cannot become confirmed green',()=>{
 const far=tunerProximity(model(40)),near=tunerProximity(model(18)),tuned=tunerProximity(model());assert.ok(far<near&&near<tuned);assert.equal(tuned,1);assert.equal(tunerNoteColor(0),'#e8c58f');assert.equal(tunerNoteColor(1),'#a5d7b3');assert.ok(tunerProximity({...model(),uncertain:true})<1);assert.ok(tunerProximity({...model(),provisional:true})<1);assert.equal(tunerProximity({...model(),ambiguous:true}),0);assert.equal(tunerProximity({...model(),octave:true}),0);assert.equal(tunerProximity(null),0);assert.equal(tunerNoteColor(1,'#b36942','#347348'),'#347348');
});
test('A running listener without a usable pitch never invents a note or extends a remembered result',()=>{
 const view=createTunerPresentation();for(let t=0;t<4000;t+=40)assert.equal(view.update(null,t).model,null);view.update(model(-20),4000);assert.equal(view.update(null,7999).model.remembered,true);assert.equal(view.update(null,8000).model,null);
});
