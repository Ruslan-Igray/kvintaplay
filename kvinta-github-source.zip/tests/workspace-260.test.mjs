import test from 'node:test';import assert from 'node:assert/strict';
import {pinchFontSize} from '../features/songs/src/pinch-zoom.js';
test('Pinch font size follows relative finger distance, rounds and respects the readable range',()=>{assert.equal(pinchFontSize(20,100,120),24);assert.equal(pinchFontSize(20,100,60),12);assert.equal(pinchFontSize(20,100,10),10);assert.equal(pinchFontSize(20,100,300),28);});
