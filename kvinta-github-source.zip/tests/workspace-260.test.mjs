import test from 'node:test';import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {pinchFontSize} from '../features/songs/src/pinch-zoom.js';
import {mountSongWorkspace} from '../features/songs/src/workspace.js';
test('Pinch font size follows relative finger distance, rounds and respects the readable range',()=>{assert.equal(pinchFontSize(20,100,120),24);assert.equal(pinchFontSize(20,100,60),12);assert.equal(pinchFontSize(20,100,10),10);assert.equal(pinchFontSize(20,100,300),28);});

test('Tracks opens the library directly below the workspace controls and both other modes close it',t=>{
 const win=new EventTarget();
 const previousWindow=globalThis.window;
 globalThis.window=win;
 t.after(()=>{if(previousWindow===undefined)delete globalThis.window;else globalThis.window=previousWindow;});
 const nodes=new Map();
 const doc={defaultView:win,createElement:()=>new Element()};
 class Element extends EventTarget{
  ownerDocument=doc;
  dataset={};
  children=[];
  attributes=new Map();
  setAttribute(name,value){this.attributes.set(name,value);}
  append(...nodes){this.children.push(...nodes);}
  insertBefore(node){this.children.unshift(node);}
  after(node){this.nextElementSibling=node;}
  querySelector(selector){
   if(!nodes.has(selector))nodes.set(selector,new Element());
   return nodes.get(selector);
  }
 }
 const phone=new Element(),library=new Element(),editorStates=[];
 const workspace=mountSongWorkspace({phone,library,editor:{setEditing(value){editorStates.push(value);}},player:{stop(){}}});
 const tracksButton=phone.querySelector('.ke-edit-switch').children.at(-1);
 nodes.set('.kw-tracks-button',tracksButton);
 assert.equal(phone.querySelector('.ke-addbar').nextElementSibling,library);
 assert.equal(workspace.mode,'rehearsal');assert.equal(library.hidden,true);
 for(const [control,next]of [[tracksButton,'tracks'],[phone.querySelector('.ke-edit'),'editor'],[tracksButton,'tracks'],[phone.querySelector('.ke-view'),'rehearsal']]){
  control.onclick();
  assert.equal(workspace.mode,next);
  assert.equal(phone.dataset.workspace,next);
  assert.equal(library.hidden,next!=='tracks');
  assert.equal(control.attributes.get('aria-pressed'),'true');
 }
 assert.deepEqual(editorStates,[false,true,false,false]);
});

test('The song library has exactly two matching navigation choices and content panels',()=>{
 const source=readFileSync(new URL('../features/songs/src/library.js',import.meta.url),'utf8');
 const tabs=[...source.matchAll(/<button\b[^>]*\bdata-tab="([^"]+)"[^>]*>([^<]+)<\/button>/g)];
 assert.deepEqual(tabs.map(([,id,label])=>[id,label]),[['search','Поиск'],['saved','Мои песни']]);
 assert.deepEqual([...source.matchAll(/<section\b[^>]*\bdata-panel="([^"]+)"/g)].map(match=>match[1]),['search','saved']);
});
