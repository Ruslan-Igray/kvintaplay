// Local QA only. Sites publishes dist/, so neither this route nor its fixture is deployed.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=fileURLToPath(new URL('../dist/',import.meta.url));
const fixture=fileURLToPath(new URL('./browser/tuner.html',import.meta.url));
const port=Number(process.argv[2])||4174;
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};
http.createServer(async(request,response)=>{
  try{
    let pathname=decodeURIComponent(new URL(request.url,'http://localhost').pathname);
    const qa=pathname==='/__qa/tuner';if(pathname.endsWith('/'))pathname+='index.html';
    const filename=qa?fixture:path.resolve(root,'.'+pathname);
    if(!qa&&!filename.startsWith(path.resolve(root)+path.sep)){response.writeHead(403).end();return;}
    const data=await readFile(filename);
    response.writeHead(200,{'Content-Type':types[path.extname(filename)]||'application/octet-stream','Cache-Control':'no-cache'}).end(data);
  }catch{response.writeHead(404).end('Not found');}
}).listen(port,'0.0.0.0',()=>console.log(`Local: http://localhost:${port}/ · synthetic tuner QA: http://localhost:${port}/__qa/tuner`));
