import test from 'node:test';
import assert from 'node:assert/strict';
import { signatureLabel } from '../dist/modules/theory.js';
import { createReferenceTone,REFERENCE_SECONDS } from '../dist/modules/reference-tone.js';
import { tuningGuidance } from '../dist/modules/tuner-guidance.js';
import { segmentAt,switchAt,setupSwitchGestures } from '../dist/modules/switch-gestures.js';

test('Key signatures use readable Russian counts for both sharp and flat keys',()=>{
  assert.equal(signatureLabel(0),'Без знаков');assert.equal(signatureLabel(1),'1 диез');assert.equal(signatureLabel(4),'4 диеза');assert.equal(signatureLabel(6),'6 диезов');assert.equal(signatureLabel(-1),'1 бемоль');assert.equal(signatureLabel(-3),'3 бемоля');assert.equal(signatureLabel(-5),'5 бемолей');
});
test('Tuner instructions follow pitch direction, with a distinct in-tune and wrong-string state',()=>{
  assert.equal(tuningGuidance({cents:-20}).title,'↑ Натяните струну');assert.equal(tuningGuidance({cents:20}).title,'↓ Ослабьте струну');assert.equal(tuningGuidance({cents:-4,tuned:true}).direction,'tuned');assert.equal(tuningGuidance({cents:-400,far:true}).direction,'check');assert.equal(tuningGuidance(null).direction,'waiting');
});
function audio(){
  const nodes=[],context={state:'running',currentTime:2,sampleRate:12000,destination:{},resume:()=>Promise.resolve(),createBuffer(channels,length,rate){const samples=new Float32Array(length);return {samples,sampleRate:rate,getChannelData:()=>samples};},createGain(){const n={gain:{value:1},connect(){},disconnect(){this.disconnected=true;}};nodes.push(n);return n;},createBufferSource(){const n={connect(){},disconnect(){this.disconnected=true;},start(t){this.starts=t;},stop(t){this.stops=t;}};nodes.push(n);return n;}};
  return {context,nodes};
}
test('Reference sound is sustained for three seconds and Stop releases its nodes',async()=>{
  const a=audio(),events=[],player=createReferenceTone({contextFactory:()=>a.context,onState:playing=>events.push(playing)});
  assert.equal(await player.play(442),true);const source=a.nodes.find(n=>n.buffer);assert.equal(source.buffer.samples.length,12000*REFERENCE_SECONDS);assert.ok(Math.abs(source.stops-source.starts-REFERENCE_SECONDS)<1e-8);assert.equal(player.active,true);player.stop();assert.equal(player.active,false);assert.ok(a.nodes.every(n=>n.disconnected));assert.equal(events.at(-1),false);
});
test('A late audio resume cannot play after cancellation, and interruption clears the reference',async()=>{
  const a=audio();let resume;a.context.state='suspended';a.context.resume=()=>new Promise(r=>{resume=r;});const player=createReferenceTone({contextFactory:()=>a.context});const start=player.play(82.4069);player.stop();a.context.state='running';resume();assert.equal(await start,false);assert.equal(a.nodes.length,0);
  await player.play(82.4069);a.context.state='interrupted';a.context.onstatechange();assert.equal(player.active,false);assert.ok(a.nodes.every(n=>n.disconnected));
});
test('Slide selection clamps to the nearest segment and checkbox drag commits once',()=>{
  const rects=[{left:10,right:60},{left:70,right:120},{left:130,right:180}];assert.equal(segmentAt(-20,rects),0);assert.equal(segmentAt(95,rects),1);assert.equal(segmentAt(999,rects),2);assert.equal(switchAt(30,10,54),false);assert.equal(switchAt(60,10,54),true);
  const handlers={},doc={addEventListener:(name,fn)=>{(handlers[name]??=[]).push(fn);},defaultView:{addEventListener(){}}};let clicks=0;
  const checkbox={checked:false,disabled:false,classList:{remove(){},add(){}},style:{removeProperty(){},setProperty(){}},setPointerCapture(){},getBoundingClientRect:()=>({left:10,width:54}),closest:()=>checkbox,matches:()=>true,click(){this.checked=!this.checked;clicks++;},contains:e=>e===checkbox};
  setupSwitchGestures(doc);const fire=(name,data={})=>{const e={target:checkbox,button:0,isPrimary:true,pointerId:1,clientX:15,clientY:30,preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.stopped=true;},...data};for(const h of handlers[name]||[])h(e);return e;};
  fire('pointerdown');fire('pointermove',{clientX:61});fire('pointerup',{clientX:61});assert.equal(checkbox.checked,true);assert.equal(clicks,1);assert.equal(fire('click',{isTrusted:true}).prevented,true);
  fire('pointerdown',{clientX:61});fire('pointermove',{clientX:60,clientY:70});fire('pointerup',{clientX:60,clientY:70});assert.equal(clicks,1);
});
