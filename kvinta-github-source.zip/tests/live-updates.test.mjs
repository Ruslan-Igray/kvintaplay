import test from 'node:test';
import assert from 'node:assert/strict';
import {createLiveUpdates,updateBusy,UPDATE_INTERVAL} from '../dist/modules/live-updates.js';
import {clientsReady,refreshSafeLegacyClients} from '../dist/modules/update-worker.js';
function fixture({controlled=true,busy=true,waiting=true,published="2.4.4",active="2.4.4"}={}){
 let time=0,reloads=0,checks=0,block=busy;const timers=[],sent=[];
 const win=new EventTarget();win.Event=Event;win.navigator={onLine:true};
 const doc=new EventTarget();doc.hidden=false;doc.querySelector=()=>null;
 const worker=new EventTarget();worker.state='installed';worker.postMessage=m=>sent.push(m);
 const registration=new EventTarget();Object.assign(registration,{active:controlled?{}:null,waiting:waiting?worker:null,update:async()=>{checks++;}});
 const sw=new EventTarget();sw.controller=controlled?{}:null;sw.register=async()=>registration;
 const updates=createLiveUpdates({scriptUrl:'./sw.js',scope:'./',win,doc,sw,isBusy:()=>block,now:()=>time,repeat:(fn,ms)=>{const timer={fn,ms};timers.push(timer);return timer;},cancel:timer=>{if(timer)timer.cancelled=true;},reload:()=>reloads++,appVersion:'2.4.4',getPublishedVersion:async()=>published,getActiveVersion:async()=>active});
 return {updates,doc,win,sw,registration,worker,sent,timers,setTime:n=>time=n,setBusy:value=>block=value,idle:()=>timers.find(t=>t.ms===1000).fn(),get reloads(){return reloads;},get checks(){return checks;}};
}
test('A downloaded update waits through playback, then applies in an idle pause without an app restart',async()=>{
 const f=fixture();await f.updates.ready;f.setTime(2000);f.idle();assert.equal(f.sent.length,0);assert.equal(f.updates.pending,true);
 f.setBusy(false);f.idle();assert.deepEqual(f.sent,[{type:'KVINTA_APPLY_UPDATE'}]);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.updates.dispose();
});
test('An update activated elsewhere never reloads a playing, editing, hidden or touched client',async()=>{
 const f=fixture({waiting:false});await f.updates.ready;f.setTime(5000);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,0);f.setBusy(false);f.doc.hidden=true;f.idle();assert.equal(f.reloads,0);f.doc.hidden=false;f.doc.dispatchEvent(new Event('pointerdown'));f.idle();assert.equal(f.reloads,0);f.doc.dispatchEvent(new Event('pointercancel'));f.setTime(6300);f.idle();assert.equal(f.reloads,1);f.updates.dispose();
});
test('First installation does not reload, periodic and reconnect checks run while the app remains open',async()=>{
 const f=fixture({controlled:false,waiting:false,busy:false});await f.updates.ready;assert.equal(f.checks,1);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,0);f.setTime(UPDATE_INTERVAL+1);f.timers.find(t=>t.ms===UPDATE_INTERVAL).fn();await Promise.resolve();assert.equal(f.checks,2);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.updates.dispose();assert.ok(f.timers.every(t=>t.cancelled));
});
test('Every client reports real activity to a waiting worker; a blocked peer defers activation',async()=>{
 const f=fixture();await f.updates.ready;let reply;const event=new Event('message');event.data={type:'KVINTA_CAN_UPDATE'};event.ports=[{postMessage:data=>reply=data}];f.setTime(2000);f.sw.dispatchEvent(event);assert.deepEqual(reply,{safe:false,version:'2.4.4',hidden:false});f.setBusy(false);f.sw.dispatchEvent(event);assert.deepEqual(reply,{safe:true,version:'2.4.4',hidden:false});f.idle();const deferred=new Event('message');deferred.data={type:'KVINTA_UPDATE_DEFERRED'};f.sw.dispatchEvent(deferred);f.idle();assert.equal(f.sent.length,2);f.updates.dispose();
});
function channel(){const port1={close(){}},port2={host:port1};return {port1,port2};}
test('Worker requires visible windows to be safe, including visible legacy clients with no response',async()=>{
 const scope='https://example.test/kvinta/',page=safe=>({url:scope+'songs/',postMessage(message,[port]){port.host.onmessage({data:{safe}});}});
 const options={scope,makeChannel:channel};assert.equal(await clientsReady({matchAll:async()=>[page(true),page(true)]},options),true);assert.equal(await clientsReady({matchAll:async()=>[page(true),page(false)]},options),false);
 const timers=[];const pending=clientsReady({matchAll:async()=>[{url:scope,postMessage(){}}]},{...options,later:fn=>{timers.push(fn);return fn;},cancel(){}});await Promise.resolve();timers.forEach(fn=>fn());assert.equal(await pending,false);
 assert.equal(await clientsReady({matchAll:async()=>[{url:'https://example.test/elsewhere/'}]},options),true);
});
test('Activity guard covers microphone, set rehearsal, count-in, song editing, open dialogs and loading',()=>{
 const doc={documentElement:{dataset:{}},activeElement:null,querySelector:()=>null,querySelectorAll:()=>[]};assert.equal(updateBusy(doc,{}),false);assert.equal(updateBusy(doc,{kvintaEditing:true}),true);doc.documentElement.dataset.kvintaReady='false';assert.equal(updateBusy(doc,{}),true);doc.documentElement.dataset.kvintaReady='true';doc.querySelector=()=>({});assert.equal(updateBusy(doc,{}),true);doc.querySelector=()=>null;doc.querySelectorAll=()=>[{getClientRects:()=>[{}]}];assert.equal(updateBusy(doc,{}),true);
});
test('A stale 2.4.4 page cannot report latest when 2.4.5 is published; an unknown active worker never causes a reload loop',async()=>{
 const unknown=fixture({busy:false,waiting:false,published:'2.4.5',active:null});await unknown.updates.ready;assert.match(unknown.updates.status,/Открыта 2\.4\.4.*Доступна 2\.4\.5/);unknown.setTime(4000);unknown.idle();assert.equal(unknown.reloads,0);unknown.updates.dispose();
 const updated=fixture({busy:false,waiting:false,published:'2.4.5',active:'2.4.5'});await updated.updates.ready;assert.ok(!updated.updates.status.includes('актуальная версия'));updated.setTime(4000);updated.idle();assert.equal(updated.reloads,1);updated.updates.dispose();
 const offline=fixture({waiting:false,published:null});await offline.updates.ready;assert.match(offline.updates.status,/Не удалось сверить/);offline.updates.dispose();
});
test('Returning from Safari page cache restores checking and clears a pointer that ended outside the app',async()=>{
 const f=fixture({busy:false,waiting:false});await f.updates.ready;f.doc.dispatchEvent(new Event('pointerdown'));f.win.dispatchEvent(new Event('pagehide'));assert.ok(f.timers.every(t=>!t.cancelled));f.win.dispatchEvent(new Event('pageshow'));await new Promise(setImmediate);assert.equal(f.checks,2);f.setTime(4000);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.updates.dispose();
});
test('Returning from background forces a check even before the periodic interval expires',async()=>{const f=fixture({waiting:false,busy:false});await f.updates.ready;assert.equal(f.checks,1);f.setTime(2000);f.doc.hidden=true;f.doc.dispatchEvent(new Event('visibilitychange'));f.doc.hidden=false;f.doc.dispatchEvent(new Event('visibilitychange'));await new Promise(setImmediate);assert.equal(f.checks,2);f.updates.dispose();});
test('A focused slider or switch does not block an idle update after interaction ends',()=>{const doc={documentElement:{dataset:{}},querySelector:()=>null,querySelectorAll:()=>[],activeElement:{tagName:'INPUT',type:'range',getClientRects:()=>[{}]}};assert.equal(updateBusy(doc,{}),false);doc.activeElement.type='checkbox';assert.equal(updateBusy(doc,{}),false);doc.activeElement.type='text';assert.equal(updateBusy(doc,{}),true);});
test('A hidden or frozen old window does not block activation for the visible app',async()=>{
 const scope='https://example.test/kvinta/';let askedHidden=false;
 const pages=[{url:scope,visibilityState:'visible',postMessage(message,[port]){port.host.onmessage({data:{safe:true}});}},{url:scope+'songs/',visibilityState:'hidden',postMessage(){askedHidden=true;}}];
 assert.equal(await clientsReady({matchAll:async()=>pages},{scope,makeChannel:channel}),true);assert.equal(askedHidden,false);
});
test('Activation refreshes only safe old screens and leaves playing, hidden and newer screens intact',async()=>{
 const scope='https://example.test/kvinta/',navigated=[],deferred=[];
 const page=(name,safe,version,visibilityState='visible')=>({url:scope+name,visibilityState,postMessage(message,ports){if(message.type==='KVINTA_CAN_UPDATE')ports[0].host.onmessage({data:{safe,version}});else deferred.push(name);},async navigate(url){navigated.push(url);}});
 const pages=[page('old',true,undefined),page('playing',false,'2.4.4'),page('hidden',true,'2.4.4','hidden'),page('current',true,'2.4.6'),page('newer',true,'2.4.7')];
 await refreshSafeLegacyClients({matchAll:async()=>pages},{scope,version:'2.4.6',makeChannel:channel});assert.deepEqual(navigated,[scope+'old']);assert.deepEqual(deferred,['playing','hidden']);
});

test('Concurrent worker activation and apply requests navigate a legacy screen only once',async()=>{
 const scope='https://dedup.test/kvinta/';let navigations=0;
 const page={id:'legacy-dedup',url:scope,visibilityState:'visible',postMessage(message,[port]){port.host.onmessage({data:{safe:true}});},async navigate(){navigations++;await new Promise(setImmediate);}};
 const clients={matchAll:async()=>[page]},options={scope,version:'2.4.6',makeChannel:channel};
 await Promise.all([refreshSafeLegacyClients(clients,options),refreshSafeLegacyClients(clients,options)]);
 assert.equal(navigations,1);
});

test('Built worker finishes activation before navigating a legacy client, avoiding an activation-fetch deadlock',async()=>{
 const {readFile}=await import('node:fs/promises'),{runInNewContext}=await import('node:vm');
 const source=await readFile(new URL('../dist/sw.js',import.meta.url),'utf8'),listeners={},queued=[];let activationDone=false,navigated=false;
 const scope='https://activation.test/kvinta/',client={id:'activation-legacy',url:scope,visibilityState:'visible',postMessage(message,[port]){port.host.onmessage({data:{safe:true,version:'2.4.4'}});},async navigate(){assert.equal(activationDone,true);navigated=true;}};
 const self={registration:{scope,active:{state:'activating',postMessage:message=>queued.push(message)}},clients:{claim:async()=>{},matchAll:async()=>[client]},addEventListener:(type,fn)=>listeners[type]=fn};
 runInNewContext(source,{self,caches:{keys:async()=>[],delete:async()=>true},MessageChannel:function(){return channel();},setTimeout,clearTimeout,URL});
 let activation;listeners.activate({waitUntil:promise=>activation=promise});await activation;activationDone=true;self.registration.active.state='activated';assert.equal(navigated,false);assert.equal(queued[0].type,'KVINTA_REFRESH_LEGACY');
 let refresh;listeners.message({data:queued[0],waitUntil:promise=>refresh=promise});await refresh;assert.equal(navigated,true);
});
