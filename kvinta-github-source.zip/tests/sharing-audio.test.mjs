import test from 'node:test';
import assert from 'node:assert/strict';
import { newSet,addSetChord,normalizeDraft,createCompositionStore,draftSignature } from '../dist/modules/composition-model.js';
import { createSetLink,readSetLink } from '../dist/modules/composition-link.js';
import { chordVoices,pluckSamples,createChordPlayer,createChordAudition,midiFrequency } from '../dist/modules/chord-player.js';
import { loadState,saveState } from '../dist/modules/storage.js';
import { soundingNotes,voicingsFor } from '../dist/modules/guitar.js';
import { createPitchDetector,centsBetween } from '../dist/modules/tuner-pitch.js';

function song(){let set={...newSet(),name:'Припев 🎸 №1 / До♯',keyIndex:3,mode:'minor',rehearsal:{bpm:137,meter:'7/8',loop:false}};for(const c of [{root:'F#',type:'m7',bass:'C#',beats:3},{root:'B',type:'7',beats:5},{root:'F#',type:'m7',bass:'C#',beats:8}])set=addSetChord(set,c);return {...set,editingId:'private-record-id'};}
const musical=set=>[set.name,set.keyIndex,set.mode,set.rehearsal,set.chords.map(c=>[c.root,c.type,c.bass,c.beats])];
const rawLink=p=>'#set=v1.'+Buffer.from(JSON.stringify(p)).toString('base64url');
test('Sharing round-trip preserves exact spellings, basses, repeats, durations and rehearsal with no private IDs',()=>{
  const source=song(),url=new URL(createSetLink(source,'https://example.test/kvinta/?temporary=do-not-share#circle')),received=readSetLink(url.hash);
  assert.equal(url.search,'');
  assert.deepEqual(musical(received),musical(source));assert.equal(received.editingId,null);assert.equal(new Set(received.chords.map(c=>c.id)).size,3);
  assert.ok(received.chords.every(c=>!source.chords.some(s=>s.id===c.id)));
  assert.ok(!Buffer.from(url.hash.split('.')[1],'base64url').toString().includes('private-record-id'));
  const another=readSetLink(url.hash);another.chords[0].beats=32;assert.equal(source.chords[0].beats,3);assert.equal(readSetLink(url.hash).chords[0].beats,3);
});
test('Full 128-chord legacy sets and empty-name fallbacks survive a bounded share link',()=>{
  const set=normalizeDraft({...song(),name:'',chords:Array.from({length:128},(_,i)=>({root:'F##',type:'maj7',bass:'Bbb',beats:i%32+1}))}),url=new URL(createSetLink(set,'https://example.test/'));
  assert.ok(url.href.length<16000);const copy=readSetLink(url.hash);assert.equal(copy.chords.length,128);assert.equal(copy.chords.at(-1).beats,32);assert.match(copy.name,/^\d{10}$/);
});
test('Malformed, future, excessive and semantically invalid links are rejected before import',()=>{
  const valid=[1,'Тест',0,'major',[96,'4/4',true],[['C','major',null,4]]];
  const bad=[null,{},[],[...valid,{}],valid.map((x,i)=>i===2?12:x),valid.map((x,i)=>i===3?'harmonic':x),valid.map((x,i)=>i===4?[500,'4/4',true]:x),valid.map((x,i)=>i===4?[96,'99/4',true]:x),valid.map((x,i)=>i===4?[96,'4/4','true']:x),valid.map((x,i)=>i===5?[['<script>','major',null,4]]:x),valid.map((x,i)=>i===5?[['C','constructor',null,4]]:x),valid.map((x,i)=>i===5?[['C','major',null,33]]:x),valid.map((x,i)=>i===5?Array(129).fill(['C','major',null,4]):x)];
  for(const p of bad)assert.throws(()=>readSetLink(rawLink(p)),/повреждена/);
  for(const hash of ['#set=v1.a','#set=v1.%zz','#set=v1.'+'a'.repeat(16001),'#set=v1._w'])assert.throws(()=>readSetLink(hash),/повреждена/);
  assert.throws(()=>readSetLink('#set=v9.a'),/не поддерживается/);assert.equal(readSetLink('#circle'),null);
});
test('Import saves an independent favorite without replacing the current draft; failed storage changes nothing',()=>{
  let blocked=false,uid=0;const data=new Map(),storage={getItem:k=>data.get(k),setItem(k,v){if(blocked)throw new Error();data.set(k,v);}},store=createCompositionStore({storage,idFactory:()=>`saved-${++uid}`});
  const old=store.save(song());const working=addSetChord({...old.draft,name:'Неоконченный куплет'},{root:'D',type:'major',beats:2});store.saveDraft(working);
  const imported=readSetLink(new URL(createSetLink(song(),'https://example.test')).hash),result=store.save(imported,{asNew:true,keepDraft:true});
  assert.equal(result.ok,true);assert.notEqual(result.record.id,old.record.id);assert.equal(draftSignature(store.draft),draftSignature(working));assert.deepEqual(musical(store.find(result.record.id)),musical(imported));
  const reloaded=createCompositionStore({storage});assert.equal(reloaded.list().length,2);assert.equal(draftSignature(reloaded.draft),draftSignature(working));
  blocked=true;const before=data.get('kvinta.compositions.v1');assert.equal(store.save(imported,{asNew:true,keepDraft:true}).ok,false);assert.equal(data.get('kvinta.compositions.v1'),before);
});
test('Chord sound follows the selected fingering, skips muted strings and keeps voicing octaves',()=>{
  const positions=voicingsFor('C','major'),open=chordVoices(soundingNotes(positions[0]));
  assert.deepEqual(open.map(v=>v.midi),[48,52,55,60,64]);assert.deepEqual(open.map(v=>v.string),[1,2,3,4,5]);assert.equal(open[0].delay,0);assert.equal(open[4].delay,.1);
  assert.notDeepEqual(chordVoices(soundingNotes(positions[1])).map(v=>v.midi),open.map(v=>v.midi));assert.deepEqual(chordVoices([40,-1,1,2,3,4]),[]);assert.deepEqual(chordVoices([null,null,null,null,null,null]),[]);
});
test('Synthesized plucks have the intended pitch at both phone sample rates and end at silence',()=>{
  const detect=createPitchDetector();for(const rate of [44100,48000])for(const midi of [40,48,64,76]){
    const samples=pluckSamples(midi,rate),found=detect(samples.slice(1000,17384),rate);assert.ok(found.frequency);assert.ok(Math.abs(centsBetween(found.frequency,midiFrequency(midi)))<2);
    assert.equal(samples[0],0);assert.equal(samples.at(-1),0);assert.ok(samples.every(x=>Number.isFinite(x)&&Math.abs(x)<1));
  }
});
function audio(){
  const nodes=[],gains=[];let resume=()=>Promise.resolve();
  const context={state:'running',currentTime:2,sampleRate:12000,destination:{},resume(){return resume();},createBuffer:(channels,length)=>({getChannelData:()=>new Float32Array(length)}),createGain(){const node={gain:{value:1,setTargetAtTime(){}},connect(){},disconnect(){this.disconnected=true;}};gains.push(node);return node;},createBufferSource(){const node={connect(){},disconnect(){this.disconnected=true;},start(t){this.startAt=t;},stop(t){this.stopAt=t;}};nodes.push(node);return node;}};
  return {context,nodes,gains,deferResume(){context.state='suspended';let finish;resume=()=>new Promise(r=>{finish=r;});return ()=>{context.state='running';finish();};}};
}
test('Audio transport finishes once, stops every scheduled string, and cancels pending activation',async()=>{
  const a=audio(),states=[],player=createChordPlayer({contextFactory:()=>a.context,onState:s=>states.push(s)});
  assert.equal(await player.play([40,45,null,55,59,64]),true);assert.equal(a.nodes.length,5);assert.equal(a.nodes[0].startAt,2.025);assert.equal(a.nodes.at(-1).startAt,2.125);
  a.nodes.forEach(n=>n.onended());assert.equal(player.active,false);assert.equal(states.at(-1),'idle');
  await player.play([40,45,null,55,59,64]);player.stop();assert.equal(player.active,false);assert.ok(a.nodes.slice(5).every(n=>n.stopAt===2.04));a.nodes.slice(5).forEach(n=>n.onended());assert.ok(a.gains.every(g=>g.disconnected));
  const b=audio(),finish=b.deferResume(),waiting=createChordPlayer({contextFactory:()=>b.context}),pending=waiting.play([40,45,50,55,59,64]);waiting.stop();finish();assert.equal(await pending,false);assert.equal(b.nodes.length,0);
});
test('Unavailable audio reports a recoverable state instead of leaving Play stuck',async()=>{
  let message='';const player=createChordPlayer({contextFactory:()=>{throw new Error('unsupported');},onState:(s,m)=>{message=m;}});assert.equal(await player.play([40,45,50,55,59,64]),false);assert.equal(player.active,false);assert.match(message,/Не удалось/);
});
test('Audio interruption releases every source immediately and an old completion cannot stop a new chord',async()=>{
  const a=audio(),player=createChordPlayer({contextFactory:()=>a.context});await player.play([40,45,50,55,59,64]);const finished=a.nodes[0].onended;
  a.context.state='interrupted';a.context.onstatechange();assert.equal(player.active,false);assert.ok(a.nodes.every(n=>n.disconnected));
  a.context.state='running';await player.play([40,45,50,55,59,64]);finished();assert.equal(player.active,true);player.stop();
});
test('Automatic audition stays enabled between strums; manual mode only sounds on a chord press',async()=>{
  const calls=[],changes=[];let notes=[40,45,50,55,59,64],stops=0;
  const player={play:n=>{calls.push([...n]);return Promise.resolve(true);},stop:()=>{stops++;}},audition=createChordAudition({player,getNotes:()=>notes,onChange:v=>changes.push(v)});
  await audition.selected();assert.equal(calls.length,0);await audition.play();assert.equal(calls.length,1);assert.equal(audition.enabled,false);
  await audition.toggle();assert.equal(audition.enabled,true);assert.equal(calls.length,2);
  player.stop();assert.equal(audition.enabled,true);notes=[null,48,52,55,60,64];await audition.selected();assert.deepEqual(calls.at(-1),notes);assert.equal(calls.length,3);
  await audition.toggle();assert.equal(audition.enabled,false);assert.equal(stops,2);notes=[null,null,50,57,62,66];await audition.selected();assert.equal(calls.length,3);await audition.play();assert.deepEqual(calls.at(-1),notes);assert.deepEqual(changes,[true,false]);
});
test('Restoring automatic mode never starts audio until the user makes a selection',async()=>{
  let calls=0;const audition=createChordAudition({auto:true,player:{play:()=>{calls++;return Promise.resolve(true);},stop(){}},getNotes:()=>[40,45,50,55,59,64]});
  assert.equal(audition.enabled,true);assert.equal(calls,0);await audition.selected();assert.equal(calls,1);
});
test('Old preferences default to manual audition; enabled mode survives reload without changing the voicing',()=>{
  const before=globalThis.localStorage;let raw='{"library":{"root":"F#","type":"maj7","position":1}}';globalThis.localStorage={getItem:()=>raw,setItem:(k,v)=>{raw=v;}};
  try{const state=loadState();assert.equal(state.library.autoPlay,false);state.library.autoPlay=true;saveState(state);assert.deepEqual(loadState().library,{root:'F#',type:'maj7',position:1,layout:'horizontal',autoPlay:true});raw='broken';assert.equal(loadState().library.autoPlay,false);}finally{if(before===undefined)delete globalThis.localStorage;else globalThis.localStorage=before;}
});
