import test from 'node:test';import assert from 'node:assert/strict';
import {recentSearches,wordPositions} from '../features/songs/src/editor-controls.js';
import {normalizeSong,snapshot,addChord} from '../features/songs/src/score-model.js';
import {sharesRequest} from '../features/songs/worker/shares.js';
import {createCountIn} from '../features/songs/src/count-in.js';
import {createSearchServer} from '../hosting/search/server.mjs';

test('Production song requests and preflight are accepted at the new domain',async()=>{
 const server=createSearchServer({handler:async()=>Response.json({results:[],sources:[]})});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  const base='http://127.0.0.1:'+server.address().port;
  for(const origin of ['https://kvintaplay.ru','http://kvintaplay.ru']){
   for(const route of ['search','artist','import']){
    const url=base+'/api/songs/'+route;
    const options=await fetch(url,{method:'OPTIONS',headers:{Origin:origin,'Access-Control-Request-Method':'GET'}});
    assert.equal(options.status,204);
    assert.equal(options.headers.get('access-control-allow-origin'),origin);
    const response=await fetch(url,{headers:{Origin:origin}});
    assert.equal(response.status,200);
    assert.equal(response.headers.get('access-control-allow-origin'),origin);
   }
  }
 }finally{await new Promise(resolve=>server.close(resolve));}
});

test('Search history keeps ten unique recent queries, with normalized whitespace and case',()=>{let items=[];for(let i=0;i<12;i++)items=recentSearches(items,'Песня '+i);assert.equal(items.length,10);assert.equal(items[0],'Песня 11');items=recentSearches(items,'  песня   5 ');assert.equal(items[0],'песня 5');assert.equal(items.length,10);assert.equal(items.filter(x=>x.toLowerCase()==='песня 5').length,1);assert.deepEqual(recentSearches(null,''),[]);});
test('Word selection preserves a precise current position, Unicode offsets and instrumental lines',()=>{const positions=wordPositions('Тихий вечер — музыка',8);assert.equal(positions.find(w=>w.label==='вечер').column,6);assert.ok(positions.some(w=>w.column===8));assert.equal(wordPositions('',0)[0].column,0);assert.equal(wordPositions('',20).at(-1).column,0);});
const make=()=>normalizeSong({schema:2,title:'Тест цвета',parts:[{name:'Куплет',lines:[{text:'Тихий вечер гасит окна',chords:[{symbol:'Am',column:0,beats:128,color:'teal'}],cues:[{id:'cue',type:'cue',preset:'bass',label:'Вступает бас',color:'purple',column:12}]}]}]});
test('Cue position and chord color survive save, transport preferences and legacy migration',()=>{const first=make(),out=snapshot(JSON.parse(JSON.stringify(first)),{countIn:true}),line=out.parts[0].lines[0];assert.equal(line.cues[0].column,12);assert.equal(line.cues[0].color,'purple');assert.equal(line.chords[0].color,'teal');assert.equal(line.chords[0].beats,128);assert.equal(out.rehearsal.countIn,true);delete line.cues[0].column;delete line.chords[0].color;const old=normalizeSong(out).parts[0].lines[0];assert.equal(old.cues[0].column??0,0);assert.equal(old.chords[0].color,undefined);});
test('Long manual duration is retained when a new chord is added',()=>{const song=make(),line=song.parts[0].lines[0],c=addChord(song,line.id,6,'G',256);assert.equal(normalizeSong(song).parts[0].lines[0].chords.find(x=>x.id===c.id).beats,256);});
test('Shared immutable song includes cue anchors, chord colors and count-in preference',async()=>{const objects=new Map(),env={BUCKET:{put:async(k,v)=>objects.set(k,v),get:async k=>objects.has(k)?{text:async()=>objects.get(k)}:null}},song=snapshot(make(),{countIn:true});const post=await sharesRequest(new Request('https://test/api/song-shares',{method:'POST',headers:{Origin:'https://ruslan-igray.github.io','Content-Type':'application/json'},body:JSON.stringify({song})}),env);assert.equal(post.status,201);const {id}=await post.json(),read=await sharesRequest(new Request('https://test/api/song-shares/'+id),env),data=await read.json();assert.equal(data.song.parts[0].lines[0].cues[0].column,12);assert.equal(data.song.parts[0].lines[0].chords[0].color,'teal');assert.equal(data.song.rehearsal.countIn,true);});
function clock(){let at=0,next=0;const jobs=new Map();return {setTimer(fn,ms){const id=++next;jobs.set(id,{fn,at:at+ms});return id;},clearTimer(id){jobs.delete(id);},advance(ms){const until=at+ms;for(;;){const entry=[...jobs].filter(([,j])=>j.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!entry)break;jobs.delete(entry[0]);at=entry[1].at;entry[1].fn();}at=until;},now:()=>at};}
test('Count-in is exactly four quarter notes at composition tempo before advancing',()=>{for(const bpm of [60,120,220]){const c=clock(),events=[],transport=createCountIn(c);let done=false;transport.start({bpm,onBeat:n=>events.push([n,c.now()]),onDone:()=>done=true});c.advance(60000/bpm*4-.01);assert.deepEqual(events.map(x=>x[0]),[1,2,3,4]);assert.equal(done,false);c.advance(.02);assert.equal(done,true);for(let i=0;i<4;i++)assert.ok(Math.abs(events[i][1]-i*60000/bpm)<.01);}});
test('Stopping or restarting count-in cancels every pending beat and completion',()=>{const c=clock(),events=[],transport=createCountIn(c);transport.start({bpm:120,onBeat:n=>events.push(n),onDone:()=>events.push('old')});c.advance(0);transport.cancel();c.advance(4000);assert.deepEqual(events,[1]);transport.start({bpm:60,onBeat:n=>events.push(n),onDone:()=>events.push('new')});c.advance(4000);assert.equal(events.at(-1),'new');assert.ok(!events.includes('old'));});
test('Standalone search rejects unknown origin and route before making an upstream request',async()=>{let calls=0;const server=createSearchServer({handler:async()=>{calls++;return Response.json({results:[]});}});await new Promise(r=>server.listen(0,'127.0.0.1',r));try{const base='http://127.0.0.1:'+server.address().port;assert.equal((await fetch(base+'/api/songs/search?q=abc',{headers:{Origin:'https://evil.test'}})).status,403);assert.equal((await fetch(base+'/api/song-shares',{headers:{Origin:'https://ruslan-igray.github.io'}})).status,404);assert.equal(calls,0);const r=await fetch(base+'/api/songs/search?q=abc',{headers:{Origin:'https://ruslan-igray.github.io'}});assert.equal(r.status,200);assert.equal(r.headers.get('Access-Control-Allow-Origin'),'https://ruslan-igray.github.io');assert.equal(calls,1);}finally{server.closeAllConnections();await new Promise(r=>server.close(r));}});
test('Standalone quota cannot be bypassed by supplying forwarded addresses',async()=>{const server=createSearchServer({perClient:1,handler:async()=>Response.json({results:[]})});await new Promise(r=>server.listen(0,'127.0.0.1',r));try{const base='http://127.0.0.1:'+server.address().port+'/api/songs/search?q=abc';for(const [i,ip]of ['1.2.3.4','4.3.2.1'].entries()){const r=await fetch(base,{headers:{Origin:'https://ruslan-igray.github.io','X-Forwarded-For':ip}});assert.equal(r.status,i?429:200);}}finally{server.closeAllConnections();await new Promise(r=>server.close(r));}});
