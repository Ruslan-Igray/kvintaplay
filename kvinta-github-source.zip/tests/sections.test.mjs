import test from 'node:test';
import assert from 'node:assert/strict';
import {newSet,addSetChord,dropSetChord,normalizeDraft,transposeSet,createCompositionStore} from '../dist/modules/composition-model.js';
import {sectionsOf,sectionChords,addSection,copySection,changeSection} from '../dist/modules/composition-sections.js';
import {createSetLink,readSetLink} from '../dist/modules/composition-link.js';
import {makeRehearsalPlan,rehearsalFrame} from '../dist/modules/rehearsal-model.js';
function song(){let s=addSetChord(newSet(),{root:'C',type:'major',beats:2});const part=addSection(s,'Припев');s=addSetChord(part.set,{root:'G',type:'7',beats:3,sectionId:part.id});return s;}
test('Legacy sets become a first verse without losing chords, and new parts have independent capacity',()=>{
 let s=newSet();for(let i=0;i<16;i++)s=addSetChord(s,{root:'C',type:'major'});const original=s.chords.map(c=>c.id),part=addSection(s,'Припев');s=part.set;
 assert.deepEqual(s.chords.map(c=>c.id),original);assert.equal(s.sections[0].name,'Куплет 1');assert.equal(addSetChord(s,{root:'D',type:'major',sectionId:'main'}),null);
 s=addSetChord(s,{root:'G',type:'major',sectionId:part.id});assert.equal(s.chords.length,17);assert.equal(sectionChords(s,part.id).length,1);
});
test('Copies retain beats and musical spelling but have independent chord/section identities',()=>{
 const s=song(),part=copySection(s,s.sections[1].id);assert.equal(part.set.sections.length,3);const [old]=sectionChords(s,s.sections[1].id),[copy]=sectionChords(part.set,part.id);
 assert.equal(copy.root,old.root);assert.equal(copy.beats,3);assert.notEqual(copy.id,old.id);part.set.chords.at(-1).beats=9;assert.equal(old.beats,3);
 const replaced=dropSetChord(part.set,{chord:{root:'A',type:'minor'}},{kind:'replace',index:2});assert.equal(replaced.set.chords[2].sectionId,part.id);
});
test('Part order, rename and deletion preserve the remaining sequence and transpose every part',()=>{
 const s=song(),id=s.sections[1].id,moved=changeSection(s,id,{delta:-1});assert.equal(moved.chords[0].root,'G');assert.equal(moved.sections[0].id,id);
 const renamed=changeSection(moved,id,{name:'Припев финал'});assert.equal(renamed.sections[0].name,'Припев финал');assert.deepEqual(transposeSet(renamed,2).chords.map(c=>c.root),['A','D']);
 const removed=changeSection(renamed,id,{remove:true});assert.equal(removed.chords.length,1);assert.equal(removed.chords[0].root,'C');assert.equal(changeSection(removed,'main',{remove:true}),null);
});
test('Saving and sharing a full composition preserve section order and durations without sharing local IDs',()=>{
 const s=song(),data=new Map(),storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)},store=createCompositionStore({storage});assert.equal(store.save(s).ok,true);
 const restored=createCompositionStore({storage}).list()[0];assert.deepEqual(restored.sections,s.sections);
 const url=new URL(createSetLink(s,'https://example.test/')),received=readSetLink(url.hash);assert.ok(url.hash.startsWith('#set=v4.'));
 assert.deepEqual(received.sections.map(p=>p.name),s.sections.map(p=>p.name));assert.deepEqual(received.chords.map(c=>[c.root,c.beats,received.sections.findIndex(p=>p.id===c.sectionId)]),[['C',2,0],['G',3,1]]);
 assert.ok(!Buffer.from(url.hash.split('.')[1],'base64url').toString().includes(s.sections[1].id));
 const old=readSetLink(new URL(createSetLink(newSetWithChord(),'https://example.test/')).hash);assert.equal(sectionsOf(old).length,1);
});
function newSetWithChord(){return addSetChord(newSet(),{root:'C',type:'major'});}
test('Malformed section links reject missing names, extra mappings and invalid part references',()=>{
 const base=[2,'Song',0,'major',[96,'4/4',true],[['C','major',null,4]]];
 for(const bad of [[[''],[0]],[['Verse'],[1]],[['Verse'],[]],[Array(17).fill('Verse'),[0]]])assert.throws(()=>readSetLink('#set=v2.'+Buffer.from(JSON.stringify([...base,bad])).toString('base64url')),/повреждена/);
 const corrupt=normalizeDraft({...song(),sections:[{id:'main',name:'Verse'},{id:'main',name:'Duplicate'}]});assert.equal(corrupt.sections.length,1);assert.ok(corrupt.chords.every(c=>c.sectionId==='main'));
});

test('Rehearsal advances from verse into chorus and loops the entire composition',()=>{
 const s=song(),plan=makeRehearsalPlan(s);assert.equal(plan.total,5);assert.equal(rehearsalFrame(plan,1).chord.sectionId,'main');assert.equal(rehearsalFrame(plan,2).chord.sectionId,s.sections[1].id);assert.equal(rehearsalFrame(plan,5).chord.sectionId,'main');assert.equal(rehearsalFrame({...plan,settings:{...plan.settings,loop:false}},5).ended,true);
});
