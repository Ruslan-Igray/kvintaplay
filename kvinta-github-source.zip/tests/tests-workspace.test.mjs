import test from 'node:test';import assert from 'node:assert/strict';
import {startupTarget} from '../dist/modules/startup-state.js';
import {appHeaderMarkup} from '../dist/modules/app-chrome.js';
import {GAME_MODES,gameKey,gameHistoryEntry,normalizeGame,gamePlan,scoreGame} from '../dist/modules/rhythm-game-model.js';
import {workspaceDocument} from '../dist/modules/workspace-document.js';
test('Offline navigation resolves all three documents without treating unrelated paths as tests',()=>{
 for(const base of ['https://example.test/','https://example.test/kvinta/']){const root=new URL(base).pathname;for(const folder of ['songs','tests'])for(const suffix of ['','index.html'])assert.equal(workspaceDocument(root+folder+'/'+suffix,base),base+folder+'/index.html');assert.equal(workspaceDocument(root,base),base+'index.html');assert.equal(workspaceDocument(root+'tests-other/',base),base+'index.html');}
});
test('Tests restore on plain launch in root and subdirectory hosting, while explicit links win',()=>{
 for(const root of ['/','/kvinta/']){const input={lastWorkspace:'tests',pathname:root,base:'https://example.test'+root};assert.equal(startupTarget(input),root+'tests/');assert.equal(startupTarget({...input,pathname:root+'index.html'}),root+'tests/');for(const hash of ['#set=old','#song=share','#circle'])assert.equal(startupTarget({...input,hash}),null);assert.equal(startupTarget({...input,search:'?from=tests'}),null);}
});
test('All three workspaces have native navigation with one selected mode',()=>{
 for(const mode of ['tools','song','tests']){const header=appHeaderMarkup(mode);assert.equal((header.match(/aria-current="page"/g)||[]).length,1);assert.ok(header.includes('data-app-mode="'+mode+'" role="img"'));assert.equal((header.match(/<a data-app-mode=/g)||[]).length,2);assert.ok(!header.includes('data-app-action="tests"'));assert.ok(!header.includes('aria-haspopup="dialog"'));}
});
test('Podkhvat renames the display without changing saved return-mode keys or history',()=>{
 const settings=normalizeGame({task:'return',bpm:120,meter:'4/4',duration:15,pauses:3,bars:1}),p=gamePlan(settings),result=scoreGame(settings,[...Array.from({length:p.guideBeats},(_,i)=>i*p.period),...p.expected.map(a=>a.time)]),record=gameHistoryEntry({at:1000,settings,result});assert.equal(GAME_MODES.return,'Подхват');assert.equal(gameKey(settings),'v2|return|120|4/4|15|3|1');assert.equal(record.settings.task,'return');assert.equal(record.result.score,100);
});
