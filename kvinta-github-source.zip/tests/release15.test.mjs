import test from 'node:test';
import assert from 'node:assert/strict';
import {APP_SOUNDS,soundSamples} from '../dist/modules/ui-sounds.js';
import {createClickFeedback} from '../dist/modules/feedback.js';
import {createMetronomeEngine,normalizeMetro} from '../dist/modules/metronome-engine.js';
import {MUSIC_TIPS} from '../dist/modules/music-tips.js';
import {TIP_COLLECTIONS} from '../dist/modules/music-tip-collections.js';
import {freshMusicTip,tipMarkup} from '../dist/modules/tip-format.js';
import {loadState,saveState} from '../dist/modules/storage.js';

function memory(initial=[]){const data=new Map(initial);return {data,getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};}
test('All 300 authored cards have unique titles, concise bodies, valid emphasis and no rendered source links',()=>{
 assert.equal(MUSIC_TIPS.length,300);assert.equal(new Set(MUSIC_TIPS.map(t=>t[0])).size,300);assert.equal(new Set(MUSIC_TIPS.map(t=>t[1])).size,300);
 assert.equal(Object.values(TIP_COLLECTIONS).flat().length,272);
 for(const [title,body] of MUSIC_TIPS){assert.ok(title.trim()&&title.length<=65,title);assert.ok(body.length>=80&&body.length<=300,title);assert.match(body,/\*\*.+?\*\*/);assert.equal((body.match(/\*\*/g)||[]).length%2,0);assert.ok(!body.includes(' ~ '));assert.ok(!tipMarkup(body).includes('<a '));}
});
test('A persisted reading cycle shows every card once and avoids a repeat at the cycle boundary',()=>{
 const storage=memory(),names=[];for(let i=0;i<300;i++)names.push(freshMusicTip({storage,random:()=>.4})[0]);assert.equal(new Set(names).size,300);
 const next=freshMusicTip({storage,random:()=>.4})[0];assert.notEqual(next,names.at(-1));const second=[next];for(let i=1;i<300;i++)second.push(freshMusicTip({storage,random:()=>.4})[0]);assert.equal(new Set(second).size,300);
});
test('Tip deck migrates recent cards, survives corruption and falls back with unavailable storage',()=>{
 const storage=memory([['kvinta.tips.recent.v1',JSON.stringify([0,1,2,3,4,5,6,7])]]);for(let i=0;i<20;i++)assert.ok(!MUSIC_TIPS.slice(0,8).includes(freshMusicTip({storage,random:()=>0})));
 storage.setItem('kvinta.tips.cycle.v1',JSON.stringify({count:300,remaining:[900,-1],last:0}));assert.ok(MUSIC_TIPS.includes(freshMusicTip({storage,random:()=>0})));
 assert.equal(freshMusicTip({storage:{getItem(){throw new Error();}},random:()=>0}),MUSIC_TIPS[0]);
});
test('Three sound families remain bounded, end at silence and have distinct waveforms at phone sample rates',()=>{
 for(const rate of [8000,44100,48000,96000]){const families=APP_SOUNDS.map(s=>soundSamples(rate,s.id));for(const data of families){assert.equal(Math.abs(data[0]),0);assert.ok(Math.abs(data.at(-1))<.0001);assert.ok(data.every(n=>Number.isFinite(n)&&Math.abs(n)<1));assert.ok(data.some(n=>Math.abs(n)>.1));}assert.notDeepEqual(families[0],families[1]);assert.notDeepEqual(families[1],families[2]);}
 assert.equal(normalizeMetro({sound:'shh'}).sound,'shh');assert.equal(normalizeMetro({sound:'click'}).sound,'click');assert.equal(normalizeMetro({sound:'invalid'}).sound,'wood');
});
function audio(){const sources=[];const ctx={state:'running',currentTime:1,sampleRate:8000,destination:{},resume:async()=>{},createGain:()=>({connect(){},gain:{setValueAtTime(){},setTargetAtTime(){}}}),createBuffer(c,n){const data=new Float32Array(n);return {getChannelData:()=>data};},createBufferSource(){const s={connect(){},disconnect(){},start(t){this.time=t;},stop(){this.stopped=true;}};sources.push(s);return s;}};return {ctx,sources};}
test('Wheel/slider feedback and metronome audition use identical samples from the currently selected family',async()=>{
 let selected='wood';const ui=audio(),metro=audio(),feedback=createClickFeedback({getSound:()=>selected,contextFactory:()=>ui.ctx}),engine=createMetronomeEngine({getSettings:()=>({sound:selected,volume:65}),audioContextFactory:()=>metro.ctx,setTimer:()=>1,clearTimer(){}});
 for(const family of ['wood','click','shh','wood']){selected=family;ui.ctx.currentTime+=.1;await feedback.play();await engine.audition();assert.deepEqual(ui.sources.at(-1).buffer.getChannelData(0),metro.sources.at(-1).buffer.getChannelData(0));}
 assert.notDeepEqual(ui.sources[0].buffer.getChannelData(0),ui.sources[1].buffer.getChannelData(0));engine.stop();
});
test('Hiss works in a running metronome, keeps the main-beat accent and cancels on stop',async()=>{
 const a=audio();let pump;const engine=createMetronomeEngine({getSettings:()=>({sound:'shh',bpm:120}),audioContextFactory:()=>a.ctx,setTimer:fn=>{pump=fn;return 1;},clearTimer(){}});
 await engine.start();a.ctx.currentTime=1.5;pump();assert.equal(a.sources.length,2);assert.notDeepEqual(a.sources[0].buffer.getChannelData(0),a.sources[1].buffer.getChannelData(0));engine.stop();assert.ok(a.sources.every(s=>s.stopped));
});
test('Passive feedback cannot change the audio route while tuner capture is active',async()=>{
 let created=0,allowed=false;const a=audio(),feedback=createClickFeedback({canPlay:()=>allowed,contextFactory:()=>{created++;return a.ctx;}});assert.equal(await feedback.unlock(),false);assert.equal(await feedback.play(),false);assert.equal(created,0);allowed=true;assert.equal(await feedback.play(),true);assert.equal(created,1);
});
test('Global hiss preference survives reload without changing existing microphone and guitar preferences',()=>{
 const before=globalThis.localStorage,storage=memory();globalThis.localStorage=storage;try{const state=loadState();state.metronome.sound='shh';state.tuner.response='precise';state.library.autoPlay=true;saveState(state);const restored=loadState();assert.equal(restored.metronome.sound,'shh');assert.equal(restored.tuner.response,'precise');assert.equal(restored.library.autoPlay,true);}finally{if(before===undefined)delete globalThis.localStorage;else globalThis.localStorage=before;}
});
