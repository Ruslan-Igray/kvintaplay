CREATE TABLE `telemetry_events` (
	`id` text PRIMARY KEY NOT NULL,
	`instance_id` text NOT NULL,
	`type` text NOT NULL,
	`day` text NOT NULL,
	`occurred_at` integer NOT NULL,
	FOREIGN KEY (`instance_id`) REFERENCES `telemetry_instances`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `telemetry_events_day_type` ON `telemetry_events` (`day`,`type`);--> statement-breakpoint
CREATE INDEX `telemetry_events_instance_day` ON `telemetry_events` (`instance_id`,`day`);--> statement-breakpoint
CREATE TABLE `telemetry_instances` (
	`id` text PRIMARY KEY NOT NULL,
	`source` text NOT NULL,
	`platform` text NOT NULL,
	`first_seen` integer NOT NULL,
	`last_seen` integer NOT NULL,
	`installed_at` integer
);
--> statement-breakpoint
CREATE INDEX `telemetry_instances_installed` ON `telemetry_instances` (`installed_at`);